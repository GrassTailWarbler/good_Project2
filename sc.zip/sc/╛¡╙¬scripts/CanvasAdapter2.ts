import { view, macro, ResolutionPolicy } from 'cc';
import { _decorator, Component, Node } from 'cc';
import { Iglobal } from './Iglobal';

const { ccclass, property } = _decorator;
const designSize = view.getDesignResolutionSize();
const ratio = 1.5;//Math.round(16 / 9 * 100) / 100;
@ccclass('CanvasAdapter2')
export class CanvasAdapter2 extends Component {
    @property(Node)
    target: Node = null;
    onLoad() {
        view.on('canvas-resize', this.setAdapter, this);
        this.setAdapter();
    }

    setAdapter() {
        let visibleSize = view.getVisibleSize();

        if (visibleSize.height > visibleSize.width) { // 竖屏

            const r = visibleSize.height / visibleSize.width;
            this.adjustGameContent(macro.ORIENTATION_PORTRAIT);
            if (r > ratio) {//普通手机
                if (visibleSize.width / visibleSize.height > 9 / 16) {
                    view.setDesignResolutionSize(designSize.width, designSize.height, ResolutionPolicy.FIXED_HEIGHT);//9/15
                } else {
                    view.setDesignResolutionSize(designSize.width, designSize.height, ResolutionPolicy.FIXED_WIDTH);
                }

            } else {//平板 
                view.setDesignResolutionSize(designSize.width, designSize.height, ResolutionPolicy.FIXED_HEIGHT);

            }



        } else { // 横屏

            const r = visibleSize.width / visibleSize.height;
            this.adjustGameContent(macro.ORIENTATION_LANDSCAPE);
            if (r < ratio) {//平板 
                view.setDesignResolutionSize(designSize.height, designSize.width, ResolutionPolicy.FIXED_WIDTH);

            } else {//普通手机

                if (visibleSize.width / visibleSize.height < 16 / 9) {
                    view.setDesignResolutionSize(designSize.height, designSize.width, ResolutionPolicy.FIXED_WIDTH);//15/9
                } else {
                    view.setDesignResolutionSize(designSize.height, designSize.width, ResolutionPolicy.FIXED_HEIGHT);
                }
                //view.setDesignResolutionSize(designSize.height, designSize.width, ResolutionPolicy.FIXED_HEIGHT);

            }


        }


    }

    adjustGameContent(orientation: number) {
        if (orientation === macro.ORIENTATION_PORTRAIT) {
            Iglobal.isPortail = true;
        } else {
            Iglobal.isPortail = false;
        }
    }
}


