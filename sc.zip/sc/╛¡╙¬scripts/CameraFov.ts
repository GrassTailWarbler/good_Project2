import { view, Camera, renderer } from 'cc';
import { _decorator, Component } from 'cc';
const { ccclass, property } = _decorator;

@ccclass('CameraFov')
export class CameraFov extends Component {

    start() {
        view.on("canvas-resize", this.setFov, this); //监听游戏尺寸变化
        this.setFov();
    }

    setFov() {
        //获取 3d场景下的相机
        let camera = this.node?.getComponent(Camera);
        const visibleSize = view.getVisibleSize();
        if (visibleSize.width / visibleSize.height < view.getDesignResolutionSize().width / view.getDesignResolutionSize().height) {
            camera.fovAxis = renderer.scene.CameraFOVAxis.HORIZONTAL;//竖屏
            camera.fov = 20;
        } else {
            camera.fovAxis = renderer.scene.CameraFOVAxis.VERTICAL;//横屏
            camera.fov = 20;//相机中设置 fovAxis 为 VERTICAL 后 调整fov参数合适的视角拿到的固定数值
        }
    }
}


