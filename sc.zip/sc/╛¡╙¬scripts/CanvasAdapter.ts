import { _decorator } from "cc";
import { Component, view, ResolutionPolicy } from "cc";

const { ccclass, property } = _decorator;

@ccclass('CanvasAdapter')
export class CanvasAdapter extends Component {


    protected onLoad() {
        view.on('canvas-resize', this.setAdapter, this);
        this.setAdapter();
    }

    protected setAdapter() {
        let visibleSize = view.getVisibleSize();
        let designSize = view.getDesignResolutionSize();
        if (visibleSize.height / visibleSize.width > designSize.height / designSize.width) { // 竖屏
            view.setDesignResolutionSize(designSize.width, designSize.height, ResolutionPolicy.FIXED_WIDTH);
        } else { // 横屏
            view.setDesignResolutionSize(designSize.width, designSize.height, ResolutionPolicy.FIXED_HEIGHT);
        }
    }

    protected onDestroy(): void {
        view.off('canvas-resize', this.setAdapter, this);
    }
}
