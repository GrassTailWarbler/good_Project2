import { BoxCollider, CCString, director, ITriggerEvent } from 'cc';
import { _decorator, Component, Node } from 'cc';
//import { playable, Playable } from 'mvplayable';
import { GuidManager } from './GuidManager';
const { ccclass, property } = _decorator;

@ccclass('WorkBox')
export class WorkBox extends Component {
    @property(BoxCollider)
    public boxC: BoxCollider = null;
    @property(CCString)
    public EName: string = "";
    @property(CCString)
    public ENamePath: string = "";
    @property(Node)
    public WorkModel: Node = null;
    @property(Node)
    public ArrowModel: Node = null;
    Working: boolean = false;
    @property(Node)
    public PathRoot: Node = null;
    @property(Node)
    public RotateRoot: Node = null;

    start() {
        this.boxC.on("onTriggerEnter", this.onTrigger, this);
        this.boxC.on("onTriggerExit", this.onTriggerExit, this);
        //playable.eventSystem.dispatch(Playable.PlayGameEvent, true, [this.ENamePath, this.PathRoot, this.RotateRoot]);
        director.emit('workEvent', true, [this.ENamePath, this.PathRoot, this.RotateRoot]);

    }

    protected onEnable(): void {

    }

    Unlock() {
        this.boxC.off("onTriggerEnter", this.onTrigger, this);
        this.boxC.off("onTriggerExit", this.onTriggerExit, this);
        this.boxC.enabled = false;
        this.Working = true;
        this.WorkModel.active = true;
        //playable.eventSystem.dispatch(Playable.PlayGameEvent, true, [this.EName]);
        director.emit('workEvent', true, [this.EName]);
    }

    private onTrigger(event: ITriggerEvent) {
        if (!event.otherCollider) {
            return;
        }
        if (event.otherCollider.node.name !== "roleRoot") {
            return;
        }
        this.Working = true;
        this.WorkModel.active = true;
        if (this.ArrowModel && this.ArrowModel.activeInHierarchy) {
            this.ArrowModel.active = false;
        }
        //playable.eventSystem.dispatch(Playable.PlayGameEvent, true, [this.EName]);
        director.emit('workEvent', true, [this.EName]);
        GuidManager.instance.finishedGuid(this.ArrowModel);
    }

    private onTriggerExit(event: ITriggerEvent) {
        if (!event.otherCollider) {
            return;
        }
        if (event.otherCollider.node.name !== "roleRoot") {
            return;
        }
        this.Working = false;
        this.WorkModel.active = false;
        //playable.eventSystem.dispatch(Playable.PlayGameEvent, false, [this.EName]);
        director.emit('workEvent', false, [this.EName]);
    }
}


