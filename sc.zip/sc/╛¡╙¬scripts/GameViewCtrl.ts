import { v3 } from 'cc';
import { v2 } from 'cc';
import { director } from 'cc';
import { Camera } from 'cc';
import { Vec2 } from 'cc';
import { Vec3 } from 'cc';
import { _decorator, Component, Node } from 'cc';
import { gameConfig } from './GameConfig';
//import { InstallType, OrbitFollowTarget, playable, Playable } from 'mvplayable';
import { input } from 'cc';
import { Input } from 'cc';
import { SkeletalAnimation } from 'cc';
import { Label } from 'cc';
import { misc } from 'cc';
import { UIOpacity } from 'cc';
import { view } from 'cc';
import { math } from 'cc';
import { XTween } from './xtween/XTween';
//import { GuidManager } from './GuidManager';
import { SDKManager } from './SDKManager';
import { AudioMgr } from './AudioMgr';
import { GuidManager } from './GuidManager';
import { Iglobal } from './Iglobal';
import { AudioSource } from 'cc';
import { EventTouch } from 'cc';
import { UITransform } from 'cc';
const { ccclass, property } = _decorator;

let tempVec3_0 = new Vec3();
let tempVec3_1 = new Vec3();
let tempVec3_2 = new Vec3();
let tempVec3_dir = new Vec3();
let tempVec2 = v2();

@ccclass('GameViewCtrl')
export class GameViewCtrl extends Component {
    @property(Label)
    MoneyText: Label = null;
    @property(Label)
    BtnText: Label = null;
    @property(Node)
    TipsNode: Node = null;
    @property(Node)
    TipsTextNode: Node = null;
    endPos: Vec3 = v3();
    startPos: Vec3 = v3();
    min_R: number = 10;
    dir: Vec2 = v2();
    max_R: number = 65;
    angle: number = 0;
    canMove: boolean = false;
    PlayingCamera: boolean = false;
    run: boolean = false;
    @property(Node)
    public joystickbg: Node = null;
    @property(Node)
    stick: Node = null;
    role: Node = null;
    anim: SkeletalAnimation = null;
    originPos: Vec3 = v3();
    uiCamera: Camera = null;
    startPos1: Vec2 = null;
    startPos2: Vec2 = null;;
    min_D: number = 0;
    //orbit: OrbitFollowTarget = null;
    FirstTouch: boolean = false;

    UserTouchTime: number = 0;
    UserTouchCount: number = 0;

    @property(AudioSource)
    bgAudio: AudioSource = null;

    @property(Node)
    public WaitingIcon: Node = null;
    public WaitingNode: Node = null;
    ShowWaiting: boolean = false;
    size: math.Size = null;
    WaitingPos: Vec3 = v3();
    WaitingDir: Vec3 = v3();
    WaitingDir2: Vec2 = v2();
    wCamera: Camera = null;

    protected onLoad(): void {

        director.on('setRole', this.SetRole, this);
        director.on('unlockEventPlayingCamera', this.UnlockEvent, this);
        director.on('updateMoneyEvent', this.UpdateMoneyEvent, this);
        director.on('waitingEvent', this.WaitingEvent, this);

    }

    start() {
        input.on(Input.EventType.TOUCH_START, this.OnScreenTouch, this);
        input.on(Input.EventType.TOUCH_MOVE, this.OnScreenTouchMove, this);
        input.on(Input.EventType.TOUCH_END, this.OnScreenTouchEnd, this);
        input.on(Input.EventType.TOUCH_CANCEL, this.OnScreenTouchEnd, this);



        this.uiCamera = this.node.parent.children[0].getComponent(Camera);
        this.originPos = this.stick.position.clone();// this.stick.getWorldPosition();
        //let w_pos = this.joystickbg.getWorldPosition();
        //this.uiCamera.worldToScreen(w_pos, this.startPos);

        director.emit('updateMoneyEvent', false, ["UpdateMoney"]);
        this.wCamera = director.getScene().getChildByName("Main Camera").getComponent(Camera);

        this.size = view.getVisibleSize();
        new XTween(this.TipsTextNode, Infinity).to(0.2, { scale: v3(1.1, 1.1, 1.1) }).to(0.2, { scale: v3(1, 1, 1) }).play();

    }

    protected onEnable(): void {

        //playable.eventSystem.on(Playable.PlayGameEvent, this.SetRole.bind(this));
        //playable.eventSystem.on(Playable.PlayGameEvent, this.UnlockEvent.bind(this));
        //playable.eventSystem.on(Playable.PlayGameEvent, this.UpdateMoneyEvent.bind(this));
        //playable.eventSystem.on(Playable.PlayGameEvent, this.WaitingEvent.bind(this));

    }

    protected onDisable(): void {
        //playable.eventSystem.off(Playable.PlayGameEvent, this.SetRole.bind(this));
        //playable.eventSystem.off(Playable.PlayGameEvent, this.UnlockEvent.bind(this));
        //playable.eventSystem.off(Playable.PlayGameEvent, this.UpdateMoneyEvent.bind(this));
        // playable.eventSystem.off(Playable.PlayGameEvent, this.WaitingEvent.bind(this));
        XTween.removeTagTweens(this.TipsTextNode)
    }

    DownloadBtn() {
        SDKManager.instance.clickDown();
        AudioMgr.inst.stop();
    }

    UpdateMoneyEvent(result, params) {
        if (params[0] == "UpdateMoney") {
            this.MoneyText.string = gameConfig.BaseMoney.toFixed(0);
        }
    }

    UnlockEvent(result, params) {
        if (params[0] == "PlayingCamera") {
            this.PlayingCamera = result;
            if (this.PlayingCamera) {
                this.canMove = false;
                this.run = false;
                this.dir.x = this.dir.y = 0; // 摇杆没有方向;
                //this.stick.setWorldPosition(this.originPos);
                this.stick.setPosition(this.originPos);
                this.joystickbg.active = false;
            }
        }
    }

    SetRole(result, params) {
        if (params[0] === "role") {
            this.role = params[1];

            this.anim = this.role.getComponentInChildren(SkeletalAnimation);
        }
    }

    WaitingEvent(result, params) {
        if (params[0] == "Waiting") {
            if (result) {
                this.WaitingNode = params[1];
                if (this.WaitingNode) {
                    this.ShowWaiting = true;

                }

            }
            else {
                if (this.WaitingNode != params[1]) {
                    return;
                }
                this.ShowWaiting = false;
                this.WaitingIcon.active = false;
            }
        }
    }

    public OnScreenTouch(e: EventTouch): void {
        director.emit('hideRoleArrow')
        this.HideTips();

        if (!this.FirstTouch) {
            this.FirstTouch = true;
            this.bgAudio.play();
        }
        if (this.PlayingCamera) {
            return;
        }
        let touches = e.getTouches();
        if (touches.length == 1) {
            let sp = e.getUILocation(); //e.getLocation();
            this.startPos = v3(sp.x, sp.y, 0);
            //let w_pos = v3();
            //this.uiCamera.screenToWorld(this.startPos, w_pos);
            this.joystickbg.active = true;
            //this.joystickbg.worldPosition = w_pos;
            //this.stick.worldPosition = w_pos;
            let parent = this.joystickbg.parent;
            
            parent.getComponent(UITransform).convertToNodeSpaceAR(this.startPos,tempVec3_2);
            this.joystickbg.setPosition(tempVec3_2)
            this.stick.setPosition(0,0)
            //this.originPos = this.stick.getWorldPosition();
            this.originPos = this.stick.getPosition().clone();
            this.canMove = true;

        }

    }

    public OnScreenTouchMove(e: EventTouch) {
        if (this.PlayingCamera) {
            return;
        }
        let touches = e.getTouches();
        if (touches.length == 1) {
            if (!this.canMove) {
                return;
            }
            if (!this.run) {
                this.run = true;
                this.anim.crossFade("run", 0.1)
            }

             e.getUILocation(tempVec2)//e.getLocation(); // 触摸的屏幕坐标，2D;
            this.endPos.x = tempVec2.x;
            this.endPos.y = tempVec2.y;

            //let dir = v3();
            Vec3.subtract(tempVec3_dir, this.endPos, this.startPos);
            let len = Vec3.len(tempVec3_dir);
            if (len < this.min_R) {
                return;
            }
            this.dir.x = tempVec3_dir.x / len;
            this.dir.y = tempVec3_dir.y / len;

            if (len > this.max_R) {
                tempVec3_dir.x = tempVec3_dir.x * this.max_R / len;
                tempVec3_dir.y = tempVec3_dir.y * this.max_R / len;
                this.endPos.x = this.startPos.x + tempVec3_dir.x;
                this.endPos.y = this.startPos.y + tempVec3_dir.y;
            }

            //var w_pos = v3();
            //this.uiCamera.screenToWorld(this.endPos, w_pos);
            //this.stick.setWorldPosition(w_pos);
            let parent = this.stick.parent;
            
            parent.getComponent(UITransform).convertToNodeSpaceAR(this.endPos,tempVec3_2);
            this.stick.setPosition(tempVec3_2)
            this.angle = this.vector_to_angle(this.dir) + 50;//this.orbit.azimuthAngle;
            this.dir = this.angle_to_vector(this.angle);
        }
    }

    public OnScreenTouchEnd(e: any): void {
        this.canMove = false;
        this.run = false;
        this.dir.x = this.dir.y = 0; // 摇杆没有方向;
        //this.stick.setWorldPosition(this.originPos);
        this.stick.setPosition(this.originPos)
        
        this.joystickbg.active = false;
        this.anim.crossFade("idle", 0.1)
        this.UserTouchTime = 0;
    }

    radian_to_angle(radian: number): number {
        // 弧度转角度公式
        // 180 / π * 弧度

        // 计算出角度
        let angle = 180 / Math.PI * radian;
        // 返回弧度
        return (angle);
    }

    vector_to_angle(vector: Vec2): number {
        // 将传入的向量归一化
        let dir = vector.normalize();
        // 计算出目标角度的弧度
        let radian = dir.signAngle(new Vec2(0, 1));
        let angle = -this.radian_to_angle(radian);
        // 返回角度
        return (angle);
    }

    angle_to_vector(angleAfterRotation: number) {
        let radian = misc.degreesToRadians(angleAfterRotation);
        let comvec = v2(0, 1);
        return comvec.rotate(radian);
    }

    ShowChe = null;
    ShowTips() {
        if (this.TipsNode.activeInHierarchy) {
            return;
        }
        this.TipsNode.active = true;
        let sp = this.TipsNode.getComponent(UIOpacity);
        this.ShowChe = () => {
            sp.opacity += 25
            if (sp.opacity >= 210) {
                sp.opacity = 255
            }
        }
        this.schedule(this.ShowChe, 0.03, 11);
        if (GuidManager.instance.readyGuid)
            GuidManager.instance.guidPlayer();
    }

    HideTips() {
        this.unschedule(this.ShowChe);
        let sp = this.TipsNode.getComponent(UIOpacity);
        this.schedule(() => {
            sp.opacity -= 25
            if (sp.opacity <= 50) {
                sp.opacity = 0
                this.TipsNode.active = false;
            }
        }, 0.03, 11);
    }

    update(deltaTime: number) {
        if (!this.canMove && !this.PlayingCamera) {
            this.UserTouchTime += deltaTime;
            if (this.UserTouchTime >= 3) {
                this.UserTouchTime = 0;
                this.ShowTips();
            }
        }
        if (this.PlayingCamera) {
            this.HideTips();
        }

        if (this.role) {
            if (this.PlayingCamera) {
                this.role.eulerAngles = new Vec3(0, this.role.eulerAngles.y, this.role.eulerAngles.z);
                return;
            }
            tempVec3_0.set(0, this.angle, 0);
            this.role.eulerAngles = tempVec3_0;
            tempVec3_1.set(this.role.position.x + this.dir.x * deltaTime * 4 * gameConfig.MoveSpeedMul,
                this.role.position.y,
                this.role.position.z - this.dir.y * deltaTime * 4 * gameConfig.MoveSpeedMul);

            this.role.position = tempVec3_1;
        }

        /* if (!Iglobal.isPortail) {
            this.WaitingIcon.active = false;
            return;
        }

        if (this.ShowWaiting && this.WaitingNode && this.WaitingIcon) {
            this.wCamera.worldToScreen(this.WaitingNode.getWorldPosition(), this.WaitingPos)
            this.WaitingDir = this.WaitingNode.parent.getWorldPosition().subtract(this.role.getWorldPosition())
            this.WaitingDir2.x = this.WaitingDir.x;
            this.WaitingDir2.y = this.WaitingDir.z;
            //this.WaitingIcon.children[0].eulerAngles.z = -this.vector_to_angle(this.WaitingDir2) ;//- this.orbit.azimuthAngle;
            this.WaitingIcon.children[0].angle = -this.vector_to_angle(this.WaitingDir2) - 30;
            if (this.WaitingPos.x < 0) {
                this.WaitingIcon.active = true;
                //this.WaitingIcon.positionX = (-this.size.width / 2) + 50
                //this.WaitingIcon.positionY = this.WaitingPos.y - (this.size.height / 2) + this.size.height * 0.3;
                this.WaitingIcon.setPosition(-this.size.width / 2 + 50, this.WaitingPos.y - (this.size.height / 2) + this.size.height * 0.3, 0);
            }
            else if (this.WaitingPos.x > this.size.width) {
                this.WaitingIcon.active = true;
                //this.WaitingIcon.positionX = (this.size.width / 2) - 50
                //this.WaitingIcon.positionY = this.WaitingPos.y - (this.size.height / 2) + this.size.height * 0.3;
                this.WaitingIcon.setPosition((this.size.width / 2) - 50, this.WaitingPos.y - (this.size.height / 2) + this.size.height * 0.3, 0);
            }
            else if (this.WaitingPos.y < 0) {
                this.WaitingIcon.active = true;
                //this.WaitingIcon.positionX = this.WaitingPos.x - (this.size.width / 2) + this.size.width * 0.3;
                //this.WaitingIcon.positionY = (-this.size.height / 2) + 50;
                this.WaitingIcon.setPosition(this.WaitingPos.x - (this.size.width / 2) + this.size.width * 0.3, (-this.size.height / 2) + 50, 0);
            }
            else if (this.WaitingPos.y > this.size.height) {
                this.WaitingIcon.active = true;
                // this.WaitingIcon.positionX = this.WaitingPos.x - (this.size.width / 2) + this.size.width * 0.3;
                // this.WaitingIcon.positionY = (this.size.height / 2) - 50;
                this.WaitingIcon.setPosition(this.WaitingPos.x - (this.size.width / 2) + this.size.width * 0.3, (this.size.height / 2) - 50, 0);
            }
            else {
                this.WaitingIcon.active = false;
            }
            //console.log(this.WaitingIcon.active,this.WaitingIcon.position)
        } */
    }
}


