import { _decorator, Component, Node } from 'cc';
const { ccclass, property } = _decorator;

@ccclass('GuoShanChePanel')
export class GuoShanChePanel extends Component {
    //过山车
    @property(Node)
    GuoShanChenSitPointRoot2: Node = null;//玩家将要走向的座位点数

    @property(Node)
    GuoShanCheSitRoot2: Node = null;//玩家上车后，将玩家设置到的父节点

    //过山车
    @property(Node)
    GuoShanChenSitPointRootArray2: Node[] = [];//玩家将要走向的座位点数

    @property(Node)
    GuoShanCheSitRootArray2: Node[] = [];//玩家上车后，将玩家设置到的父节点

    @property(Node)
    GuoShanChenPiHuaTing2: Node = null;

    @property(Node)
    waterEffect: Node = null;
}


