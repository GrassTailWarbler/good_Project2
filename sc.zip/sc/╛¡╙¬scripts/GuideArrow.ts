
import { _decorator, Component, director, Node, Vec3 } from 'cc';
//import { playable, Playable } from 'mvplayable';
const { ccclass, property } = _decorator;
let tempPos: Vec3 = new Vec3();
@ccclass('GuideArrow')
export class GuideArrow extends Component {
    @property(Node)
    Target: Node = null;
    EndGuide: boolean = false;
    protected start(): void {
        director.on('setTarget', this.SetTarget, this);
    }
    protected onEnable(): void {
        //playable.eventSystem.on(Playable.PlayGameEvent, this.SetTarget.bind(this));

    }

    protected onDisable(): void {
        //playable.eventSystem.off(Playable.PlayGameEvent, this.SetTarget.bind(this));
    }

    SetTarget(result, params) {
        if (params[0] == "GuideTarget") {
            if (!result) {
                this.Target = params[1];
                if (this.Target) {
                    this.Target.active = true;
                }
                this.EndGuide = false;
            }
            else {
                this.EndGuide = true;
                if (this.Target) {
                    this.Target.active = false;
                }
                this.Target = null;
            }
        }
    }

    reset() {
        if (this.Target) {
            this.node.lookAt(this.Target.getWorldPosition());
            tempPos.set(0, this.node.eulerAngles.y, 0);
            this.node.eulerAngles = tempPos;
            this.node.active = true;
        }
    }

    update(deltaTime: number) {
        if (!this.EndGuide) {
            if (this.Target) {
                if (this.node.getWorldPosition().subtract(this.Target.getWorldPosition()).length() <= 6) {
                    this.node.children[0].active = false;
                }
                else {
                    this.node.children[0].active = true;
                    this.node.lookAt(this.Target.getWorldPosition());
                    tempPos.set(0, this.node.eulerAngles.y, 0);
                    this.node.eulerAngles = tempPos;
                }
            }
        }
    }
}


