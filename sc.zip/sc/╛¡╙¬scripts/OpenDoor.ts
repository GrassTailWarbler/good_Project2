import { _decorator, Component, Node } from 'cc';
import { XTween } from './xtween/XTween';
const { ccclass, property } = _decorator;

@ccclass('OpenDoor')
export class OpenDoor extends Component {
    Opening: boolean = false;
    PlayOpenDoor() {
        if (this.Opening) {
            return;
        }
        this.Opening = true;
        new XTween(this.node).to(0.75, { eulerAngleZ: 120 })
            .to(0.75, { eulerAngleZ: 0 }).play();
        this.scheduleOnce(() => {
            this.Opening = false
        }, 1.5);
    }
}


