import { renderer } from 'cc';
import { view, Camera } from 'cc';
import { _decorator, Component } from 'cc';
import { Iglobal } from './Iglobal';

const { ccclass, property } = _decorator;
const ratio = 1.5;
@ccclass('CameraFov2')
export class CameraFov2 extends Component {

    protected onLoad() {
        view.on('canvas-resize', this.setFov, this); //监听游戏尺寸变化
        this.setFov();
    }

    protected setFov() {
        let camera = this.node?.getComponent(Camera);
        const visibleSize = view.getVisibleSize();

        if (visibleSize.height > visibleSize.width) { // 竖屏
            const r = visibleSize.height / visibleSize.width;
            camera.fovAxis = renderer.scene.CameraFOVAxis.HORIZONTAL;//竖屏
            if (r > ratio) {//普通手机

                camera.fov = 20;
                Iglobal.cameraFovTarget = 20;
            } else {//平板 ,iphoneSE
                camera.fov = 30;
                Iglobal.cameraFovTarget = 30;
            }
        } else { // 横屏
            const r = visibleSize.width / visibleSize.height;
            camera.fovAxis = renderer.scene.CameraFOVAxis.VERTICAL;//竖屏
            if (r < ratio) {//平板 ,iphoneSE
                camera.fov = 30;
                Iglobal.cameraFovTarget = 30;
            } else {
                camera.fov = 20;
                Iglobal.cameraFovTarget = 20;
            }
        }
    }

    protected onDestroy() {
        view.off('canvas-resize', this.setFov, this);
    }
}


