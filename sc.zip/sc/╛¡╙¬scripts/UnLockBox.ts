import { _decorator, Component, Node } from 'cc';
import { CCString } from 'cc';
import { BoxCollider } from 'cc';
import { ITriggerEvent } from 'cc';
//import { OrbitFollowTarget, Playable, playable } from 'mvplayable';
import { gameConfig } from './GameConfig';
import { XTween } from './xtween/XTween';
import { v3 } from 'cc';
import { Sprite } from 'cc';
import { Label } from 'cc';
import { WorkBox } from './WorkBox';
import { director } from 'cc';
import { Npc } from './Npc';
import { Vec3 } from 'cc';
import { resources } from 'cc';
import { Prefab, instantiate } from 'cc';
import { Camera } from 'cc';
import { Iglobal } from './Iglobal';
import { AudioMgr } from './AudioMgr';
import { GuidManager } from './GuidManager';
import { FollowCamera } from './FollowCamera';
import { PoolManager } from './PoolManager';
const { ccclass, property } = _decorator;

@ccclass('UnLockBox')
export class UnLockBox extends Component {
    @property(BoxCollider)
    public boxC: BoxCollider = null;
    @property(CCString)
    public EName: string = "";
    @property(Sprite)
    public UnlockProgress: Sprite = null;
    @property(Label)
    public UnlockProgressText: Label = null;
    @property(Node)
    public UnlockModel: Node = null;
    @property(Node)
    public ArrowModel: Node = null;
    @property(Node)
    public WalkNode: Node = null;
    @property(Node)
    public RotateRoot: Node = null;
    @property(Node)
    public EffectRoot: Node = null;
    @property(Node)
    public CameraNode: Node = null;
    @property(Node)
    public CameraNode2: Node = null;
    unlocking: boolean = false;
    sumCount: number = 0;
    orbit: Camera = null;

    Unlock: boolean = false;
    Guided: boolean = false;

    willUnlockGuoShanChe: boolean = false;

    start() {
        this.orbit = director.getScene().getChildByName('Main Camera').getComponent(Camera);

        this.boxC.on("onTriggerEnter", this.onTrigger, this);
        this.boxC.on("onTriggerExit", this.onTriggerExit, this);
        switch (this.EName) {
            case "UnlockFerriswheel":
                new XTween(this.node, Infinity, true).to(0.4, { scale: v3(1.1, 1.1, 1.1) }).call(() => { }).play();
                this.UpdateNum(gameConfig.UnlockFerriswheel, this.sumCount);
                break;
            case "UnlockCashier":
                new XTween(this.node, Infinity, true).to(0.4, { scale: v3(1.1, 1.1, 1.1) }).call(() => { }).play();
                this.UpdateNum(gameConfig.UnlockCashier, this.sumCount);
                break;
            case "UnlockPirateboat":
                new XTween(this.node, Infinity, true).to(0.4, { scale: v3(1.1, 1.1, 1.1) }).call(() => { }).play();
                this.UpdateNum(gameConfig.UnlockPirateboat, this.sumCount);
                break;
            case "UpgradeFerriswheel":
                new XTween(this.node, Infinity, true).to(0.4, { scale: v3(3.1, 3.1, 3.1) }).call(() => { }).play();
                this.UpdateNum(gameConfig.UpgradeFerriswheel, this.sumCount);
                break;
            case "UnlockCarousel":
                new XTween(this.node, Infinity, true).to(0.4, { scale: v3(1.1, 1.1, 1.1) }).call(() => { }).play();
                this.UpdateNum(gameConfig.UnlockCarousel, this.sumCount);
                break;
        }

    }

    private onTrigger(event: ITriggerEvent) {
        if (!event.otherCollider) {
            return;
        }
        if (event.otherCollider.node.name !== "roleRoot") {
            return;
        }
        this.unlocking = true;
    }

    private onTriggerExit(event: ITriggerEvent) {
        if (!event.otherCollider) {
            return;
        }
        if (event.otherCollider.node.name !== "roleRoot") {
            return;
        }
        let DelMoney = director.getScene().getChildByName("ParkRoot").getChildByName("roleRoot").getChildByName("DelMoney")
        DelMoney.active = false;
        this.unlocking = false;
    }

    UpdateNum(un: number, s: number) {
        if (s > un) return;
        this.UnlockProgress.fillRange = s / un;
        let numS: string = (un - s).toFixed(0)
        this.UnlockProgressText.string = numS;
    }

    reduceCoin() {
        //if (Iglobal.backCoinCount > 25) return;
        let goldRoot = Iglobal.ParkRootCtrl.node.getChildByPath("roleRoot/gold");
        // 每隔4次移除最后一个子元素
        if (this.sumCount > 0 && this.sumCount % 4 === 0) {
            if (goldRoot && goldRoot.children.length > 0) {
                //goldRoot.removeChild(goldRoot.children[goldRoot.children.length - 1]);
                let lastNode = goldRoot.children[goldRoot.children.length - 1];
                PoolManager.instance.putNode(lastNode);
                Iglobal.backCoinCount--;
                //console.log('count:', Iglobal.backCoinCount)
            }
        }
    }

    UpdataCount: number = 0;
    DispatchUnlockMsg() {
        if (this.Unlock) {
            return;
        }
        if (this.willUnlockGuoShanChe && !Iglobal.guoShanChePlaying) {
            this.willUnlockGuoShanChe = false;
            //this.reduceCoin();
            //console.log('ered')
            this.unlockGuoShanChe();
            return;
        } else if (this.willUnlockGuoShanChe) {
            //console.log('eredeeeee')
            return;
        }

        if (gameConfig.BaseMoney < 0.5) {
            let DelMoney = director.getScene().getChildByName("ParkRoot").getChildByName("roleRoot").getChildByName("DelMoney")
            DelMoney.active = false;
            return;
        }
        if (this.UpdataCount == 0) {
            //audioManager.playEffect("sm_zoom")
            AudioMgr.inst.playOneShot("common/audio/sm_zoom");

        }
        this.UpdataCount++;
        if (this.UpdataCount >= 10) {
            this.UpdataCount = 1;
            //audioManager.playEffect("sm_zoom")
            AudioMgr.inst.playOneShot("common/audio/sm_zoom");
        }

        let DelMoney = director.getScene().getChildByName("ParkRoot").getChildByName("roleRoot").getChildByName("DelMoney")
        DelMoney.active = true;

        gameConfig.BaseMoney--;
        this.sumCount++;
        /* if (Iglobal.backCoinCount > 25) {
            Iglobal.backCoinCount--;
        } else {
            if (Iglobal.backCoinCount <= 0) {
                Iglobal.backCoinCount = 0;
            } else {
                this.reduceCoin();
                Iglobal.backCoinCount--;
            }
        } */
        if (gameConfig.BaseMoney < Iglobal.backCoinTotal * 4) {
            this.reduceCoin();
        }




        //console.log('this.sumCount', this.sumCount)

        //playable.eventSystem.dispatch(Playable.PlayGameEvent, true, ["UpdateMoney", 1]);
        director.emit('updateMoneyEvent', true, ["UpdateMoney", 1]);
        switch (this.EName) {
            case "UnlockFerriswheel":
                if (this.sumCount >= gameConfig.UnlockFerriswheel && !this.Unlock) {

                    this.Unlock = true;
                    this.sumCount = gameConfig.UnlockFerriswheel
                    this.ArrowModel.active = false;

                    AudioMgr.inst.playOneShot("common/audio/sm_get");
                    this.boxC.enabled = false;
                    this.node.children[0].active = false;

                    director.emit('unlockEventPlayingCamera', true, ["PlayingCamera", 1])



                    //director.emit('unlockEvent', true, [this.EName, gameConfig.UnlockFerriswheel]);//解锁过山车

                    this.orbit.node.getComponent(FollowCamera).target = this.UnlockModel;//移动相机

                    let arrow = director.getScene().getChildByName("ParkRoot").getChildByName("CashierRoot").getChildByName("WorkBox").getChildByName("Arrow")
                    arrow.active = true;

                    director.emit('setTarget', false, ["GuideTarget", arrow]);

                    GuidManager.instance.isGuidToBuild = false;
                    let NPC1 = this.node.parent.parent.getChildByName("roleRoot").getComponent(Npc);

                    NPC1.SetAnim("run");

                    let endP: Vec3 = this.WalkNode.getWorldPosition();
                    let narr = [NPC1.node.getWorldPosition()]
                    narr.push(endP);
                    NPC1.InitMapNavAgent(6 * gameConfig.MoveSpeedMul);

                    NPC1.NavOnRoadWithFirst(narr, () => {

                        this.orbit.node.getComponent(FollowCamera).target = this.CameraNode;
                        director.emit('unlockEvent', true, [this.EName, gameConfig.UnlockFerriswheel]);//解锁过山车
                        
                        const targetFov = Iglobal.cameraFovTarget;
                        new XTween(this.orbit).to(0.6, { fov: targetFov + 8 }).call(() => {
                            //Iglobal.ParkRootCtrl.UnlockFerriswheel = true;
                            //director.emit('unlockEvent', true, [this.EName, gameConfig.UnlockFerriswheel]);//解锁过山车
                        }).play();

                        NPC1.SetAnim("idle");

                        this.UnlockModel.active = true;

                        //激活1级过山车节点
                        this.scheduleOnce(() => {
                            this.UnlockModel.getChildByPath('Ferris_wheel_01/guoshanche/body').active = true;
                        }, 0.1)
                        this.scheduleOnce(() => {
                            this.UnlockModel.getChildByPath('Ferris_wheel_01/guoshanche/shipNode').active = true;
                        }, 0.2)

                        this.scheduleOnce(() => {
                            this.UnlockModel.getChildByPath('Ferris_wheel_01/guoshanche/levelUp').active = true;
                        }, 0.3)

                        /* new XTween(this.UnlockModel).from(0.3, { scale: v3(0, 0, 0) }).play();
                        new XTween(this.UnlockModel).delay(0.1).to(0.3, { scale: v3(1.2, 1.2, 1.2) }).delay(0.1).call(() => {
                            new XTween(this.UnlockModel).to(0.1, { scale: v3(1, 1, 1) }).play();
                        }).play(); */

                        /* resources.load("Effect/eruption", Prefab, (err, eruptionPrefab) => {
                            const PirateboatNode = instantiate(eruptionPrefab);
                            PirateboatNode.setParent(this.EffectRoot.children[0]);
                            PirateboatNode.position = v3();
                            const Pirateboat2Node = instantiate(eruptionPrefab);
                            Pirateboat2Node.setParent(this.EffectRoot.children[1]);
                            Pirateboat2Node.position = v3();
                            this.scheduleOnce(() => {
                                PirateboatNode.destroy();
                                Pirateboat2Node.destroy();
                            }, 5)
                        }); */


                        AudioMgr.inst.playOneShot("common/audio/sm_erupt");

                        resources.load("Effect/star", Prefab, (err, starPrefab) => {
                            const star = instantiate(starPrefab);
                            star.setParent(this.EffectRoot, true);
                            star.position = v3();
                            this.scheduleOnce(() => {
                                star.destroy();
                            }, 5)
                        });

                        this.scheduleOnce(() => {
                            let camera = this.orbit.node.getComponent(FollowCamera);
                            camera.target = NPC1.node;//移动相机

                            //new XTween(this.orbit).to(0.6, { orthoHeight: 10 }).play()
                            const targetFov = Iglobal.cameraFovTarget;
                            new XTween(this.orbit).to(0.6, { fov: targetFov }).play()


                            director.emit('unlockEventPlayingCamera', false, ["PlayingCamera", 1]);
                            this.node.active = false;
                        }, 2);

                    });

                }
                else {
                    this.UpdateNum(gameConfig.UnlockFerriswheel, this.sumCount);
                    //playable.eventSystem.dispatch(Playable.PlayGameEvent, false, [this.EName, this.sumCount]);
                    director.emit('unlockEvent', false, [this.EName, this.sumCount]);
                }
                break;
            case "UpgradeFerriswheel":
                /* if (this.sumCount < gameConfig.UpgradeFerriswheel) {
                    if (gameConfig.BaseMoney > 0.5) {
                        gameConfig.BaseMoney--;
                        this.sumCount++;
                        //playable.eventSystem.dispatch(Playable.PlayGameEvent, true, ["UpdateMoney", 1]);
                        director.emit('updateMoneyEvent', true, ["UpdateMoney", 1]);
                    }
                } */
                if (this.sumCount >= gameConfig.UpgradeFerriswheel && !this.Unlock) {
                    this.willUnlockGuoShanChe = true;
                    let DelMoney = director.getScene().getChildByName("ParkRoot").getChildByName("roleRoot").getChildByName("DelMoney")
                    DelMoney.active = false;
                }

                if (this.sumCount >= gameConfig.UpgradeFerriswheel && !this.Unlock && !Iglobal.guoShanChePlaying) {
                    //在升级前,如果位置上已经有玩家坐在那里了,则将玩家移动到升级后的座位上
                    let tempNpcArray: Node[] = [];
                    for (let i = 0; i < gameConfig.FerriswheelQueueCount; i++) {
                        let NPCRoot = Iglobal.ParkRootCtrl.GuoShanCheSitRootArray[i].children[0];
                        if (NPCRoot) {
                            NPCRoot.removeFromParent();
                            tempNpcArray.push(NPCRoot);

                        }
                    }

                    gameConfig.FerriswheelQueueCount = 4;//升級後可玩玩家數量變爲6
                    Iglobal.ParkRootCtrl.updateGuoShanCheNodes();
                    Iglobal.ParkRootCtrl.GuoshancheSitRootCount = 0;
                    for (let i = 0; i < tempNpcArray.length; i++) {
                        //console.log(tempNpcArray[i])

                        let NPCRoot = tempNpcArray[i];
                        NPCRoot.setParent(Iglobal.ParkRootCtrl.GuoShanCheSitRootArray[Iglobal.ParkRootCtrl.GuoshancheSitRootCount]);
                        Iglobal.ParkRootCtrl.GuoshancheSitRootCount++;
                    }


                    this.Unlock = true;
                    this.sumCount = gameConfig.UpgradeFerriswheel


                    AudioMgr.inst.playOneShot("common/audio/sm_get");
                    this.boxC.enabled = false;
                    this.node.children[0].active = false;
                    //playable.eventSystem.dispatch(Playable.PlayGameEvent, true, ["PlayingCamera", 1]);
                    director.emit('unlockEventPlayingCamera', true, ["PlayingCamera", 1])
                    //playable.eventSystem.dispatch(Playable.PlayGameEvent, true, [this.EName, this.UnlockModel.children[1]]);
                    director.emit('workEvent', true, [this.EName, this.UnlockModel.children[1]]);
                    this.ArrowModel.active = false;
                    //playable.eventSystem.dispatch(Playable.PlayGameEvent, true, ["GuideTarget", this.ArrowModel]);
                    director.emit('setTarget', true, ["GuideTarget", this.ArrowModel]);
                    GuidManager.instance.isGuidToBuild = false;
                    this.orbit.node.getComponent(FollowCamera).target = this.CameraNode;
                    //new XTween(this.orbit).to(0.3, { orthoHeight: 12 }, { easing: XTween.Easing.sinusoidalOut }).play();
                    const targetFov = Iglobal.cameraFovTarget;
                    new XTween(this.orbit).to(0.9, { fov: targetFov + 10 }).play();
                    this.UnlockModel.active = true;
                    //激活2级过山车节点
                    this.UnlockModel.parent.getChildByName('Ferris_wheel_01').active = false;
                    this.UnlockModel.getChildByPath('guoshanche02/levelUp').active = true;
                    /* new XTween(this.UnlockModel).from(0.1, { scale: v3(0, 0, 0) }).play();
                    new XTween(this.UnlockModel).delay(0.1).to(0.1, { scale: v3(1.2, 1.2, 1.2) }).play();
                    new XTween(this.UnlockModel).delay(0.2).to(0.1, { scale: v3(1, 1, 1) }).call(() => {

                    }).play(); */

                    this.scheduleOnce(() => {
                        this.scheduleOnce(() => {
                            let w = this.node.parent.getChildByName("WorkBox").getChildByName("waiter")
                            w.active = true;
                            //new XTween(w).from(0.1, { scale: v3() }).to(0.1, { scale: v3(1.6, 1.6, 1.6) }).play();
                            this.node.parent.getComponentInChildren(WorkBox).Unlock();

                            resources.load("Effect/appear", Prefab, (err, appearPrefab) => {

                                const appear = instantiate(appearPrefab);
                                appear.setParent(w.parent, true);
                                const ascale = appear.scale;
                                appear.scale = v3(ascale.x * 1.3, ascale.y * 1.3, ascale.z * 1.3)
                                appear.setWorldPosition(w.getWorldPosition());
                                this.scheduleOnce(() => {
                                    appear.destroy();
                                }, 5)

                            });
                            resources.load("Effect/aperture_1", Prefab, (err, appearPrefab) => {
                                const appear = instantiate(appearPrefab);
                                appear.setParent(w.parent, true);
                                const ascale = appear.scale;
                                appear.scale = v3(ascale.x * 1.3, ascale.y * 1.3, ascale.z * 1.3)
                                appear.setWorldPosition(w.getWorldPosition());
                                this.scheduleOnce(() => {
                                    appear.destroy();
                                }, 5)
                            });
                        }, 0.3)

                        let NPC1 = director.getScene().getChildByName("ParkRoot").getChildByName("roleRoot")
                        this.orbit.node.getComponent(FollowCamera).target = NPC1;
                        //new XTween(this.orbit).to(0.3, { orthoHeight: 10 }).play();
                        const targetFov = Iglobal.cameraFovTarget;
                        new XTween(this.orbit).to(0.3, { fov: targetFov }).play();
                        this.scheduleOnce(() => {
                            resources.load("prefabs/CarouselPre", Prefab, (err, CarouselPrefab) => {
                                let CarouselRoot = director.getScene().getChildByName("ParkRoot").getChildByName("CarouselRoot")
                                const Carousel = instantiate(CarouselPrefab);
                                Carousel.setParent(CarouselRoot);
                                Carousel.position = v3(0, 0, 0);

                                new XTween(Carousel).from(0.2, { scale: v3(0, 0, 0) }).call(() => { }).play();
                                this.scheduleOnce(() => {
                                    let NPC1 = director.getScene().getChildByName("ParkRoot").getChildByName("roleRoot");
                                    this.orbit.node.getComponent(FollowCamera).target = NPC1;
                                    //playable.eventSystem.dispatch(Playable.PlayGameEvent, false, ["PlayingCamera", 1]);
                                    director.emit('unlockEventPlayingCamera', false, ["PlayingCamera", 1]);
                                }, 1.5)
                            });
                        }, 1.2)
                    }, 1.6)

                    AudioMgr.inst.playOneShot("common/audio/sm_erupt");


                    /* resources.load("Effect/eruption", Prefab, (err, eruptionPrefab) => {
                        const Pirateboat = instantiate(eruptionPrefab);
                        Pirateboat.setParent(this.EffectRoot.children[0], true);
                        Pirateboat.position = v3();
                        const Pirateboat2 = instantiate(eruptionPrefab);
                        Pirateboat2.setParent(this.EffectRoot.children[1], true);
                        Pirateboat2.position = v3();
                    }); */

                    resources.load("Effect/star", Prefab, (err, starPrefab) => {
                        const star = instantiate(starPrefab);
                        star.setParent(this.EffectRoot, true);
                        star.position = v3();
                    });

                    this.scheduleOnce(() => {
                        this.node.active = false;
                    }, 10)

                }
                else {
                    this.UpdateNum(gameConfig.UpgradeFerriswheel, this.sumCount);
                    //playable.eventSystem.dispatch(Playable.PlayGameEvent, false, [this.EName, this.sumCount]);
                    director.emit('unlockEvent', false, [this.EName, this.sumCount]);

                }
                break;
            case "UnlockCashier":
                if (this.sumCount >= gameConfig.UnlockCashier && !this.Unlock) {
                    this.Unlock = true;
                    this.sumCount = gameConfig.UnlockCashier;

                    AudioMgr.inst.playOneShot("common/audio/sm_get");
                    this.boxC.enabled = false;
                    this.node.children[0].active = false;
                    this.UnlockModel.active = true;
                    this.ArrowModel.active = false;
                    //playable.eventSystem.dispatch(Playable.PlayGameEvent, true, ["GuideTarget", this.ArrowModel]);
                    director.emit('setTarget', true, ["GuideTarget", this.ArrowModel]);
                    GuidManager.instance.isGuidToBuild = false;
                    //playable.eventSystem.dispatch(Playable.PlayGameEvent, true, ["PlayingCamera", 1]);
                    director.emit('unlockEventPlayingCamera', true, ["PlayingCamera", 1])
                    new XTween(this.UnlockModel).from(0.1, { scale: v3(0, 0, 0) }).to(0.1, { scale: v3(1.6, 1.6, 1.6) }).play();
                    //playable.eventSystem.dispatch(Playable.PlayGameEvent, true, [this.EName, gameConfig.UnlockCashier]);
                    director.emit('unlockEvent', true, [this.EName, gameConfig.UnlockCashier]);
                    this.node.parent.getComponentInChildren(WorkBox).Unlock();

                    resources.load("Effect/appear", Prefab, (err, appearPrefab) => {

                        const appear = instantiate(appearPrefab);
                        appear.setParent(this.UnlockModel.parent, true);
                        const ascale = appear.scale;
                        appear.scale = v3(ascale.x * 1.3, ascale.y * 1.3, ascale.z * 1.3)
                        appear.setWorldPosition(this.UnlockModel.getWorldPosition());
                        this.scheduleOnce(() => {
                            appear.destroy();
                        }, 5)

                    });
                    this.scheduleOnce(() => {
                        resources.load("Effect/aperture_1", Prefab, (err, appearPrefab) => {
                            const appear = instantiate(appearPrefab);
                            appear.setParent(this.UnlockModel.parent, true);
                            const ascale = appear.scale;
                            appear.scale = v3(ascale.x * 1.3, ascale.y * 1.3, ascale.z * 1.3)
                            appear.setWorldPosition(this.UnlockModel.getWorldPosition());
                            this.scheduleOnce(() => {
                                appear.destroy();
                            }, 5)
                        });
                    }, 0.3)

                    this.orbit.node.getComponent(FollowCamera).target = this.UnlockModel;
                    //playable.eventSystem.dispatch(Playable.PlayGameEvent, true, [this.EName, gameConfig.UnlockCashier]);
                    //director.emit('unlockEvent', true, [this.EName, gameConfig.UnlockCashier]);
                    this.scheduleOnce(() => {
                        resources.load("prefabs/Pirateboat", Prefab, (err, PirateboatPrefab) => {
                            let PirateboatRoot = director.getScene().getChildByName("ParkRoot").getChildByName("PirateboatRoot")
                            const Pirateboat = instantiate(PirateboatPrefab);
                            Pirateboat.setParent(PirateboatRoot, true);
                            Pirateboat.position = v3(0, 0, 0);
                            new XTween(Pirateboat).from(0.2, { scale: v3(0, 0, 0) }).call(() => { }).play();
                            this.orbit.node.getComponent(FollowCamera).target = Pirateboat;
                            this.scheduleOnce(() => {
                                //playable.eventSystem.dispatch(Playable.PlayGameEvent, false, ["PlayingCamera", 1]);
                                let NPC1 = director.getScene().getChildByName("ParkRoot").getChildByName("roleRoot")
                                this.orbit.node.getComponent(FollowCamera).target = NPC1;
                                director.emit('unlockEventPlayingCamera', false, ["PlayingCamera", 1]);
                            }, 2)
                        });
                    }, 1);
                }
                else {
                    this.UpdateNum(gameConfig.UnlockCashier, this.sumCount);
                    //playable.eventSystem.dispatch(Playable.PlayGameEvent, false, [this.EName, this.sumCount]);
                    director.emit('unlockEvent', false, [this.EName, this.sumCount]);
                }
                break;
            case "UnlockPirateboat":
                if (this.sumCount >= gameConfig.UnlockPirateboat && !this.Unlock) {
                    this.Unlock = true;
                    this.sumCount = gameConfig.UnlockPirateboat

                    AudioMgr.inst.playOneShot("common/audio/sm_get");
                    this.boxC.enabled = false;
                    this.node.children[0].active = false;
                    this.ArrowModel.active = false;
                    //playable.eventSystem.dispatch(Playable.PlayGameEvent, true, ["PlayingCamera", 1]);
                    director.emit('unlockEventPlayingCamera', true, ["PlayingCamera", 1])
                    //playable.eventSystem.dispatch(Playable.PlayGameEvent, true, ["GuideTarget", this.ArrowModel]);
                    director.emit('setTarget', true, ["GuideTarget", this.ArrowModel]);
                    GuidManager.instance.isGuidToBuild = false;

                    //playable.eventSystem.dispatch(Playable.PlayGameEvent, true, [this.EName, gameConfig.UnlockPirateboat]);
                    director.emit('unlockEvent', true, [this.EName, gameConfig.UnlockPirateboat]);
                    this.orbit.node.getComponent(FollowCamera).target = this.UnlockModel;
                    let NPC1 = director.getScene().getChildByName("ParkRoot").getChildByName("roleRoot").getComponent(Npc)
                    //NPC1.SetAnim("walk")
                    NPC1.SetAnim("run");
                    let endP: Vec3 = this.WalkNode.getWorldPosition();
                    let narr = [NPC1.node.getWorldPosition()]
                    narr.push(endP);
                    NPC1.InitMapNavAgent(8 * gameConfig.MoveSpeedMul);
                    NPC1.NavOnRoadWithFirst(narr, () => {
                        this.orbit.node.getComponent(FollowCamera).target = this.CameraNode;
                        //new XTween(this.orbit).to(0.6, { orthoHeight: 20 }).play()
                        const targetFov = Iglobal.cameraFovTarget;
                        new XTween(this.orbit).to(0.9, { fov: targetFov }).play()
                        NPC1.SetAnim("idle");
                        this.UnlockModel.active = true;
                        /*  new XTween(this.UnlockModel)
                             .from(0.1, { scale: v3(0, 0, 0) })
                             .delay(0.2)
                             .to(0.3, { scale: v3(0.566, 0.566, 0.566) }).call(() => {
                                 this.node.parent.getChildByName("WorkBox").active = true;
                             })
                             .play(); */
                        new XTween(this.UnlockModel)
                            .from(0.1, { scale: v3(0, 0, 0) }).play();
                        new XTween(this.UnlockModel).delay(0.1).to(0.1, { scale: v3(0.6, 0.6, 0.6) }).play();
                        new XTween(this.UnlockModel).delay(0.2).to(0.1, { scale: v3(0.566, 0.566, 0.566) }).call(() => {
                            this.node.parent.getChildByName("WorkBox").active = true;
                        }).play();

                        let pirboatRoot = director.getScene().getChildByName("ParkRoot").getChildByName("PirateboatRoot");
                        const Plan = pirboatRoot.getChildByName("Plan")
                        Plan.active = false;

                        const levelUp = pirboatRoot.getChildByName("levelUp");
                        levelUp.active = true;

                        this.scheduleOnce(() => {
                            const UpgradeBox = director.getScene().getChildByName("ParkRoot").getChildByName("FerriswheelRoot").getChildByName("UpgradeBox")
                            UpgradeBox.active = true;
                            this.orbit.node.getComponent(FollowCamera).target = UpgradeBox;
                            //new XTween(this.orbit).to(0.3, { orthoHeight: 10 }).play();
                            const targetFov = Iglobal.cameraFovTarget;
                            new XTween(this.orbit).to(0.3, { fov: targetFov }).play();
                            this.scheduleOnce(() => {
                                this.orbit.node.getComponent(FollowCamera).target = NPC1.node;
                                //playable.eventSystem.dispatch(Playable.PlayGameEvent, false, ["PlayingCamera", 1]);
                                director.emit('unlockEventPlayingCamera', false, ["PlayingCamera", 1])
                            }, 1.5);
                        }, 2)

                        AudioMgr.inst.playOneShot("common/audio/sm_erupt");

                        /* resources.load("Effect/eruption", Prefab, (err, eruptionPrefab) => {
                            let Pirateboat1 = instantiate(eruptionPrefab);
                            Pirateboat1.setParent(this.EffectRoot.children[0], true);
                            Pirateboat1.position = v3();
                            let Pirateboat2 = instantiate(eruptionPrefab);
                            Pirateboat2.setParent(this.EffectRoot.children[1], true);
                            Pirateboat2.position = v3();
                            this.scheduleOnce(() => {
                                Pirateboat1.destroy();
                                Pirateboat2.destroy();
                            }, 5)
                        });

                        resources.load("Effect/star", Prefab, (err, starPrefab) => {
                            const star = instantiate(starPrefab);
                            star.setParent(this.EffectRoot, true);
                            star.position = v3();
                            this.scheduleOnce(() => {
                                star.destroy();
                            }, 5)
                        }); */

                        this.scheduleOnce(() => {
                            this.node.active = false;
                        }, 10)
                    });
                }
                else {
                    this.UpdateNum(gameConfig.UnlockPirateboat, this.sumCount);
                    //playable.eventSystem.dispatch(Playable.PlayGameEvent, false, [this.EName, this.sumCount]);
                    director.emit('unlockEvent', false, [this.EName, this.sumCount]);
                }
                break;
            case "UnlockCarousel":
                /* if (gameConfig.BaseMoney > 0.5) {
                    if (this.sumCount < gameConfig.UnlockCarousel) {
                        gameConfig.BaseMoney--;
                        this.sumCount++;
                        //playable.eventSystem.dispatch(Playable.PlayGameEvent, true, ["UpdateMoney", 1]);
                        director.emit('updateMoneyEvent', true, ["UpdateMoney", 1]);
                    }
                } */
                if (this.sumCount >= gameConfig.UnlockCarousel && !this.Unlock) {
                    this.Unlock = true;
                    this.sumCount = gameConfig.UnlockCarousel

                    Iglobal.GameOver = true;
                    //audioManager.playEffect("sm_get");
                    AudioMgr.inst.playOneShot("common/audio/sm_get");
                    this.boxC.enabled = false;
                    this.node.children[0].active = false;
                    this.ArrowModel.active = false;
                    //playable.eventSystem.dispatch(Playable.PlayGameEvent, true, ["GameEnd", 0]);
                    director.emit('endEvent', true, ["GameEnd", 0]);
                    //playable.eventSystem.dispatch(Playable.PlayGameEvent, true, ["GuideTarget", this.ArrowModel]);
                    director.emit('setTarget', true, ["GuideTarget", this.ArrowModel]);
                    GuidManager.instance.isGuidToBuild = false;

                    //弹出下载界面
                    const gameview = director.getScene().getChildByName("Canvas").getChildByName("gameView");

                    //gameview.removeFromParent();
                    gameview.active = false;
                    //setTimeout(() => gameview.destroy(), 2000);
                    // 在此显示ending 页面
                    resources.load("prefabs/endingView", Prefab, (err, eruptionPrefab) => {
                        AudioMgr.inst.playOneShot("common/audio/sm_smile");
                        const ending = instantiate(eruptionPrefab);
                        director.getScene().getChildByName("Canvas").addChild(ending);
                    });
                    return;



                    this.orbit.node.getComponent(FollowCamera).target = this.UnlockModel;

                    director.emit('unlockEvent', true, [this.EName, gameConfig.UnlockCarousel]);

                    director.emit('unlockEventPlayingCamera', true, ["PlayingCamera", 1])
                    resources.load("Effect/balloon", Prefab, (err, balloonPrefab) => {
                        const balloon = instantiate(balloonPrefab);
                        balloon.setParent(this.EffectRoot.children[2], true);
                        balloon.position = v3();
                    });
                    let NPC1 = director.getScene().getChildByName("ParkRoot").getChildByName("roleRoot").getComponent(Npc)
                    //NPC1.SetAnim("walk")
                    NPC1.SetAnim("run");
                    let endP: Vec3 = this.WalkNode.getWorldPosition();
                    let narr = [NPC1.node.getWorldPosition()]
                    narr.push(endP);
                    NPC1.InitMapNavAgent(6 * gameConfig.MoveSpeedMul);
                    NPC1.NavOnRoadWithFirst(narr, () => {
                        this.orbit.node.getComponent(FollowCamera).target = this.CameraNode;
                        new XTween(this.orbit).to(0.2, { orthoHeight: 12 }).play()
                        NPC1.SetAnim("idle");
                        this.UnlockModel.active = true;
                        new XTween(this.UnlockModel).from(0.1, { scale: v3(0, 0, 0) }).play();
                        new XTween(this.UnlockModel).delay(0.1).to(0.1, { scale: v3(1.2, 1.2, 1.2) }).play();
                        new XTween(this.UnlockModel).delay(0.2).to(0.1, { scale: v3(1, 1, 1) }).call(() => {
                            new XTween(this.RotateRoot, Infinity).to(4, { eulerAngles: new Vec3(0, -360, 0) }).call(() => { this.RotateRoot.eulerAngles = new Vec3(0, 0, 0) }).play();
                        }).play();
                        this.scheduleOnce(() => {

                            //弹出下载界面
                            const gameview = director.getScene().getChildByName("Canvas").getChildByName("gameView");

                            //gameview.removeFromParent();
                            gameview.active = false;
                            //setTimeout(() => gameview.destroy(), 2000);
                            // 在此显示ending 页面
                            resources.load("prefabs/endingView", Prefab, (err, eruptionPrefab) => {
                                const ending = instantiate(eruptionPrefab);
                                director.getScene().getChildByName("Canvas").addChild(ending);
                            });


                        }, 3.5)
                        //audioManager.playEffect("sm_erupt");
                        AudioMgr.inst.playOneShot("common/audio/sm_erupt");
                        this.scheduleOnce(() => {
                            this.orbit.node.getComponent(FollowCamera).target = NPC1.node;
                            new XTween(this.orbit.node.getComponent(Camera)).to(0.3, { orthoHeight: 10 }).play();
                            director.emit('unlockEventPlayingCamera', false, ["PlayingCamera", 1])
                        }, 2.5);

                        AudioMgr.inst.playOneShot("common/audio/sm_smile");


                        resources.load("Effect/eruption", Prefab, (err, eruptionPrefab) => {
                            const Pirateboat = instantiate(eruptionPrefab);
                            Pirateboat.setParent(this.EffectRoot.children[0], true);
                            Pirateboat.position = v3();
                            const Pirateboat2 = instantiate(eruptionPrefab);
                            Pirateboat2.setParent(this.EffectRoot.children[1], true);
                            Pirateboat2.position = v3();
                            this.scheduleOnce(() => {
                                Pirateboat.destroy();
                                Pirateboat2.destroy();
                            }, 5)
                        });

                        resources.load("Effect/star", Prefab, (err, starPrefab) => {
                            const star = instantiate(starPrefab);
                            star.setParent(this.EffectRoot, true);
                            star.position = v3();
                            this.scheduleOnce(() => {
                                star.destroy();
                            }, 5)
                        });

                        this.scheduleOnce(() => {
                            this.node.active = false;
                        }, 10)
                    });
                }
                else {
                    this.UpdateNum(gameConfig.UnlockCarousel, this.sumCount);
                    //playable.eventSystem.dispatch(Playable.PlayGameEvent, false, [this.EName, this.sumCount]);
                    director.emit('unlockEvent', false, [this.EName, this.sumCount]);
                }
                break;
        }

    }

    unlockGuoShanChe() {
        if (this.sumCount >= gameConfig.UpgradeFerriswheel && !this.Unlock && !Iglobal.guoShanChePlaying) {
            //在升级前,如果位置上已经有玩家坐在那里了,则将玩家移动到升级后的座位上
            /* let tempNpcArray: Node[] = [];
            for (let i = 0; i < gameConfig.FerriswheelQueueCount; i++) {
                let NPCRoot = Iglobal.ParkRootCtrl.GuoShanCheSitRootArray[i].children[0];
                if (NPCRoot) {
                    tempNpcArray.push(NPCRoot);

                }
            } */



            gameConfig.FerriswheelQueueCount = 4;//升級後可玩玩家數量變爲6
            Iglobal.ParkRootCtrl.updateGuoShanCheNodes();
            /* for (let i = 0; i < tempNpcArray.length; i++) {
                console.log('----', i)
                let NPCRoot = tempNpcArray[i];
                NPCRoot.setParent(Iglobal.ParkRootCtrl.GuoShanCheSitRootArray[Iglobal.ParkRootCtrl.GuoshancheSitRootCount]);
                Iglobal.ParkRootCtrl.GuoshancheSitRootCount++;
            } */

            this.Unlock = true;
            this.sumCount = gameConfig.UpgradeFerriswheel

            AudioMgr.inst.playOneShot("common/audio/sm_get");
            this.boxC.enabled = false;
            this.node.children[0].active = false;
            //playable.eventSystem.dispatch(Playable.PlayGameEvent, true, ["PlayingCamera", 1]);
            director.emit('unlockEventPlayingCamera', true, ["PlayingCamera", 1])
            //playable.eventSystem.dispatch(Playable.PlayGameEvent, true, [this.EName, this.UnlockModel.children[1]]);
            director.emit('workEvent', true, [this.EName, this.UnlockModel.children[1]]);
            this.orbit.node.getComponent(FollowCamera).target = this.CameraNode;
            //new XTween(this.orbit).to(0.9, { orthoHeight: 20 }).play()
            const targetFov = Iglobal.cameraFovTarget;
            new XTween(this.orbit).to(0.9, { fov: targetFov + 10 }).play();
            this.UnlockModel.active = true;
            //激活2级过山车节点
            this.UnlockModel.parent.getChildByName('Ferris_wheel_01').active = false;
            //this.UnlockModel.getChildByPath('GuoShanChe_upgrade/guoshanche02').active = true;
            /*  new XTween(this.UnlockModel).from(0.1, { scale: v3(0, 0, 0) }).play();
             new XTween(this.UnlockModel).delay(0.1).to(0.1, { scale: v3(1.2, 1.2, 1.2) }).play();
             new XTween(this.UnlockModel).delay(0.2).to(0.1, { scale: v3(1, 1, 1) }).call(() => {
                 //new XTween(this.UnlockModel.children[1], Infinity).to(6, { eulerAngleZ: -360 }).call(() => { this.UnlockModel.children[1].eulerAngleZ = 0 }).play();
             }).play(); */

            this.scheduleOnce(() => {
                this.scheduleOnce(() => {
                    let w = this.node.parent.getChildByName("WorkBox").getChildByName("waiter")
                    w.active = true;
                    //new XTween(w).from(0.1, { scale: v3() }).to(0.1, { scale: v3(1.6, 1.6, 1.6) }).play();
                    this.node.parent.getComponentInChildren(WorkBox).Unlock();

                    resources.load("Effect/appear", Prefab, (err, appearPrefab) => {

                        const appear = instantiate(appearPrefab);
                        appear.setParent(w.parent, true);
                        const ascale = appear.scale;
                        appear.scale = v3(ascale.x * 1.3, ascale.y * 1.3, ascale.z * 1.3)
                        appear.setWorldPosition(w.getWorldPosition());
                        this.scheduleOnce(() => {
                            appear.destroy();
                        }, 5)

                    });
                    resources.load("Effect/aperture_1", Prefab, (err, appearPrefab) => {
                        const appear = instantiate(appearPrefab);
                        appear.setParent(w.parent, true);
                        const ascale = appear.scale;
                        appear.scale = v3(ascale.x * 1.3, ascale.y * 1.3, ascale.z * 1.3)
                        appear.setWorldPosition(w.getWorldPosition());
                        this.scheduleOnce(() => {
                            appear.destroy();
                        }, 5)
                    });
                }, 0.3)

                //let NPC1 = director.getScene().getChildByName("ParkRoot").getChildByName("roleRoot")
                let NPC1 = director.getScene().getChildByName("ParkRoot").getChildByName("roleRoot")
                this.orbit.node.getComponent(FollowCamera).target = NPC1;
                //new XTween(this.orbit).to(0.3, { orthoHeight: 10 }).play()
                const targetFov = Iglobal.cameraFovTarget;
                new XTween(this.orbit).to(0.3, { fov: targetFov }).play()
                this.scheduleOnce(() => {
                    resources.load("prefabs/CarouselPre", Prefab, (err, CarouselPrefab) => {
                        let CarouselRoot = director.getScene().getChildByName("ParkRoot").getChildByName("CarouselRoot")
                        const Carousel = instantiate(CarouselPrefab);
                        Carousel.setParent(CarouselRoot);
                        Carousel.position = v3(0, 0, 0);
                        this.orbit.node.getComponent(FollowCamera).target = Carousel;
                        new XTween(Carousel).from(0.2, { scale: v3(0, 0, 0) }).call(() => { }).play();
                        this.scheduleOnce(() => {
                            let NPC1 = director.getScene().getChildByName("ParkRoot").getChildByName("roleRoot")
                            this.orbit.node.getComponent(FollowCamera).target = NPC1;
                            director.emit('unlockEventPlayingCamera', false, ["PlayingCamera", 1])
                            //playable.eventSystem.dispatch(Playable.PlayGameEvent, false, ["PlayingCamera", 1]);
                        }, 1.5)
                    });
                }, 1.2)
            }, 1.6)
            //audioManager.playEffect("sm_erupt");
            AudioMgr.inst.playOneShot("common/audio/sm_erupt");

            /* resources.load("Effect/eruption", Prefab, (err, eruptionPrefab) => {
                const Pirateboat = instantiate(eruptionPrefab);
                Pirateboat.setParent(this.EffectRoot.children[0], true);
                Pirateboat.position = v3();
                const Pirateboat2 = instantiate(eruptionPrefab);
                Pirateboat2.setParent(this.EffectRoot.children[1], true);
                Pirateboat2.position = v3();
            }); */

            resources.load("Effect/star", Prefab, (err, starPrefab) => {
                const star = instantiate(starPrefab);
                star.setParent(this.EffectRoot, true);
                star.position = v3();
            });

            this.scheduleOnce(() => {
                this.node.active = false;
            }, 10)

        }
    }

    sumtime: number = 0;
    update(deltaTime: number) {
        if (this.Unlock) {
            return;
        }
        if (this.unlocking) {
            // this.sumtime += deltaTime;
            // if (this.sumtime >= 0.1) {
            //     this.sumtime = 0;
            this.DispatchUnlockMsg();
            // }
        }
        if (this.Guided) {
            return;
        }
        if (this.EName == "UnlockPirateboat") {
            if (gameConfig.BaseMoney >= gameConfig.UnlockPirateboat) {
                this.Guided = true;
                GuidManager.instance.isGuidToBuild = true;
                GuidManager.instance.resetGuid();
                //playable.eventSystem.dispatch(Playable.PlayGameEvent, false, ["GuideTarget", this.ArrowModel]);
                director.emit('setTarget', false, ["GuideTarget", this.ArrowModel]);
            }
        }
        else if (this.EName == "UnlockCarousel") {
            if (gameConfig.BaseMoney >= gameConfig.UnlockCarousel) {
                this.Guided = true;
                GuidManager.instance.isGuidToBuild = true;
                GuidManager.instance.resetGuid();
                //playable.eventSystem.dispatch(Playable.PlayGameEvent, false, ["GuideTarget", this.ArrowModel]);
                director.emit('setTarget', false, ["GuideTarget", this.ArrowModel]);
            }
        } else if (this.EName == "UnlockCashier") {
            if (gameConfig.BaseMoney >= gameConfig.UnlockCashier) {
                this.Guided = true;
                GuidManager.instance.isGuidToBuild = true;
                GuidManager.instance.resetGuid();
                //playable.eventSystem.dispatch(Playable.PlayGameEvent, false, ["GuideTarget", this.ArrowModel]);
                director.emit('setTarget', false, ["GuideTarget", this.ArrowModel]);
            }
        } else if (this.EName == "UpgradeFerriswheel") {
            if (gameConfig.BaseMoney >= gameConfig.UpgradeFerriswheel) {
                this.Guided = true;
                GuidManager.instance.isGuidToBuild = true;
                GuidManager.instance.resetGuid();
                //playable.eventSystem.dispatch(Playable.PlayGameEvent, false, ["GuideTarget", this.ArrowModel]);
                director.emit('setTarget', false, ["GuideTarget", this.ArrowModel]);
            }
        }
    }
}


