import { v3 } from 'cc';
import { CCInteger } from 'cc';
import { director } from 'cc';
import { _decorator, Component, Node } from 'cc';
//import { OrbitFollowTarget, Playable, playable } from 'mvplayable';
const { ccclass, property } = _decorator;

@ccclass('WaitingTips')
export class WaitingTips extends Component {
    @property(CCInteger)
    NeedShow: number = 0;
    shce = null;
    isShow: boolean = false;
    angle1: number = 0;
    angle2: number = 0;

    protected onLoad(): void {
        this.shce = () => {
            //playable.eventSystem.dispatch(Playable.PlayGameEvent, true, ["Waiting", this.node]);
            director.emit('waitingEvent', true, ["Waiting", this.node]);
            this.isShow = true;
        }
    }

    start() {
        this.angle1 = 60;
        this.angle2 = 50;
    }

    protected onEnable(): void {
        if (this.NeedShow > 0.5) {
            this.scheduleOnce(this.shce, 1)
        }
    }

    protected onDisable(): void {
        if (this.NeedShow > 0.5) {
            if (this.isShow) {
                //playable.eventSystem.dispatch(Playable.PlayGameEvent, false, ["Waiting", this.node]);
                director.emit('waitingEvent', false, ["Waiting", this.node]);
            }
            else {
                this.unschedule(this.shce);
            }
        }
    }

    update(deltaTime: number) {
        if (this.node.isValid) {
            this.node.setWorldRotationFromEuler(this.angle1 - 90, this.angle2, 0)
        }
    }
}


