import { ParkRootCtrl } from "./ParkRootCtrl";

export class Iglobal {
    static guoShanChePlaying = false;

    static ParkRootCtrl: ParkRootCtrl = null;
    static Guided: boolean = false;
    static GameOver: boolean = false;
    static isPortail: boolean = false;//竖版
    static backCoinCount: number = 0;
    static backCoinTotal: number = 5;
    static cameraFov: number = 20;
    static cameraFovTarget: number = 20;

}


