import { CCInteger } from 'cc';
import { _decorator, Component, Node } from 'cc';
const { ccclass, property } = _decorator;

@ccclass('UpdateAngle')
export class UpdateAngle extends Component {
    @property(CCInteger)
    public angleX: number = 0;
    @property(CCInteger)
    public angley: number = 0;
    @property(CCInteger)
    public angleZ: number = 0;

    start() {

    }

    SetAngle(x:number,y:number,z:number){
        this.angleX=x;this.angley=y;this.angleZ=z;
    }

    update(deltaTime: number) {
        this.node.setWorldRotationFromEuler(this.angleX,this.angley,this.angleZ)
    }
}


