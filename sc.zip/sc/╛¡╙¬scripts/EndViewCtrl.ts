import { _decorator, Component, Node } from 'cc';
import { SDKManager } from './SDKManager';
import { view } from 'cc';
import { AudioMgr } from './AudioMgr';
const { ccclass, property } = _decorator;

@ccclass('EndViewCtrl')
export class EndViewCtrl extends Component {

    /* @property(Node)
    logo: Node = null; */
    @property(Node)
    plane: Node = null;
    /* @property(Node)
    btn: Node = null; */
    @property(Node)
    xiaodao: Node = null;


    protected onLoad(): void {
        view.on('canvas-resize', this.setAdapter, this);
        this.setAdapter();
    }



    setAdapter() {
        let visibleSize = view.getVisibleSize();

        if (visibleSize.height > visibleSize.width) { // 竖屏
            //this.logo.setPosition(0, 482.407);

            this.plane.setPosition(0, 0);
            this.plane.setScale(1, 1);
            //this.btn.setPosition(0, -499.024);
            this.xiaodao.setPosition(0, 0);
            this.xiaodao.setScale(0.7, 0.7);
        } else {
            //this.logo.setPosition(0, 222.754);

            this.plane.setPosition(-222.203, 165.765);
            this.plane.setScale(0.8, 0.8);
            //this.btn.setPosition(0, -249.358);
            this.xiaodao.setPosition(369.406, 0);
            this.xiaodao.setScale(0.55, 0.55);
        }
    }


    PlayNowBtn() {

        SDKManager.instance.clickDown();
        AudioMgr.inst.stop();

    }


}


