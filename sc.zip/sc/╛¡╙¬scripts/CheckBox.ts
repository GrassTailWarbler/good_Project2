import { BoxCollider, CCString, ITriggerEvent } from 'cc';
import { _decorator, Component, Node } from 'cc';
//import { playable, Playable } from 'mvplayable';
const { ccclass, property } = _decorator;

@ccclass('CheckBox')
export class CheckBox extends Component {
    @property(BoxCollider)
    public boxC: BoxCollider = null;
    @property(CCString)
    public EName: string = "";

    start() {
        this.boxC.on("onTriggerEnter", this.onTrigger, this);
        this.boxC.on("onTriggerExit", this.onTriggerExit, this);
    }

    private onTrigger(event: ITriggerEvent) {
        if (!event.otherCollider) {
            return;
        }
        if (!event.otherCollider.node.name.startsWith("cabin")) {
            return;
        }
        if (event.otherCollider.node.children.length >= 4) {
            if(this.EName=="CheckCabin"){
                //playable.eventSystem.dispatch(Playable.PlayGameEvent, true, [this.EName, true, event.otherCollider.node]);
            }
        }
        else {
            
        }
        if(this.EName=="CheckCabin2"){
            //playable.eventSystem.dispatch(Playable.PlayGameEvent, true, [this.EName, false, event.otherCollider.node]);
        }
    }

    private onTriggerExit(event: ITriggerEvent) {
        if (!event.otherCollider) {
            return;
        }
        if (!event.otherCollider.node.name.startsWith("cabin")) {
            return;
        }
        if (event.otherCollider.node.children.length >= 4) {

        }
        else {

        }
        if(this.EName=="CheckCabin2"){
            //playable.eventSystem.dispatch(Playable.PlayGameEvent, false, [this.EName, false, event.otherCollider.node]);
        }
    }
}

