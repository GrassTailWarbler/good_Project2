import { _decorator, Component, director, Node } from 'cc';
import { Iglobal } from './Iglobal';
import { WorkBox } from './WorkBox';
//import { Playable, playable } from 'mvplayable';
import { CoinBox } from './CoinBox';

const { ccclass, property } = _decorator;

@ccclass('GuidManager')
export class GuidManager extends Component {
    //单例
    static instance: GuidManager = null;

    @property([Node])
    coinNode: Node[] = [];

    @property([Node])
    workBoxs: Node[] = [];

    readyGuid = false;

    callFunc: Function = null;

    isGuidToBuild = false;
    guidTarget: Node = null;

    protected start(): void {
        GuidManager.instance = this;
    }


    needToWork() {
        if (Iglobal.Guided) {
            return;
        }
        for (let i = 0; i < this.workBoxs.length; i++) {
            if (this.workBoxs[i].active) {
                let workCom = this.workBoxs[i].getComponent(WorkBox);
                if (!workCom.Working) {
                    Iglobal.Guided = true;
                    workCom.ArrowModel.active = true;
                    //playable.eventSystem.dispatch(Playable.PlayGameEvent, false, ["GuideTarget", workCom.ArrowModel]);
                    director.emit('setTarget', false, ["GuideTarget", workCom.ArrowModel]);
                    this.guidTarget = workCom.ArrowModel;
                    this.callFunc = () => {
                        //playable.eventSystem.dispatch(Playable.PlayGameEvent, true, ["GuideTarget", workCom.ArrowModel]);
                        director.emit('setTarget', true, ["GuideTarget", workCom.ArrowModel]);
                    }
                    break;
                }
            }
        }
    }

    needToCoin() {
        if (Iglobal.Guided) {
            return;
        }

        for (let i = 0; i < this.coinNode.length; i++) {
            if (this.coinNode[i].active) {
                let coinCom = this.coinNode[i].getComponent(CoinBox);
                if (coinCom.CoinCount > 0) {
                    Iglobal.Guided = true;
                    coinCom.ArrowModel.active = true;
                    //playable.eventSystem.dispatch(Playable.PlayGameEvent, false, ["GuideTarget", coinCom.ArrowModel]);
                    director.emit('setTarget', false, ["GuideTarget", coinCom.ArrowModel]);
                    this.guidTarget = coinCom.ArrowModel;
                    this.callFunc = () => {

                        //playable.eventSystem.dispatch(Playable.PlayGameEvent, true, ["GuideTarget", coinCom.ArrowModel]);
                        director.emit('setTarget', true, ["GuideTarget", coinCom.ArrowModel]);
                    }
                    break;
                }
            }
        }

    }

    guidPlayer() {
        if (this.isGuidToBuild) return;
        this.needToCoin();
        this.needToWork();
    }

    finishedGuid(target: Node) {
        if (this.guidTarget !== target) return;
        Iglobal.Guided = false;
        this.callFunc && this.callFunc();
        this.callFunc = null;
        this.guidTarget = null;
    }

    resetGuid() {
        //playable.eventSystem.dispatch(Playable.PlayGameEvent, true, ["GuideTarget", this.guidTarget]);
        director.emit('setTarget', true, ["GuideTarget", this.guidTarget]);
        this.callFunc = null;
        this.guidTarget = null;
        Iglobal.Guided = false;
    }
}


