import { director, randomRangeInt } from 'cc';
import { resources, Prefab, instantiate } from 'cc';
import { v3 } from 'cc';
import { _decorator, Component, Node } from 'cc';
//import { CameraConfigManager, OrbitFollowTarget, playable, Playable } from 'mvplayable';
import { Npc } from './Npc';
import { gameConfig } from './GameConfig';
import { Vec3 } from 'cc';
import { XTween } from './xtween/XTween';
import { OpenDoor } from './OpenDoor';
import { AnimationComponent } from 'cc';
import { Iglobal } from './Iglobal';
import { GuoShanChePanel } from './GuoShanChePanel';
import { AudioMgr } from './AudioMgr';
import { sys } from 'cc';
import * as i18n from '../../extensions/i18n/assets/LanguageData';
import { GuideArrow } from './GuideArrow';
import { PoolManager } from './PoolManager';
import { CoinBox } from './CoinBox';
const { ccclass, property } = _decorator;

@ccclass('ParkRootCtrl')
export class ParkRootCtrl extends Component {
    @property(Node)
    role: Node = null;
    @property(Node)
    FerriswheelRoot: Node = null;
    @property(Node)
    PirateboatRoot: Node = null;
    @property(Node)
    CarouselRoot: Node = null;
    @property(Node)
    CWaitRoot: Node = null;
    @property(Node)
    CCoinRoot: Node = null;
    @property(Node)
    FWaitRoot: Node = null;
    @property(Node)
    PWaitRoot: Node = null;
    @property(Node)
    GoRoot: Node = null;
    @property(Node)
    NPCPathRoot: Node = null;

    @property(Prefab)
    goldPrefab: Prefab = null;

    @property(Node)
    roleArrow: Node = null;


    @property([Prefab])
    npcPrefab: Prefab[] = [];



    //过山车
    @property([Node])
    GuoShanChenSitPointRootArray: Node[] = [];//玩家将要走向的座位点数

    @property([Node])
    GuoShanCheSitRootArray: Node[] = [];//玩家上车后，将玩家设置到的父节点

    @property(Node)
    GuoShanChenPiHuaTing: Node = null;

    FerriswheelRotateRoot: Node = null;
    FerriswheelPathRoot: Node = null;
    FerriswheelSitPointRoot: Node = null;
    PirateboatRotateRoot: Node = null;
    PirateboatPathRoot: Node = null;
    PirateboatSitRoot: Node = null;
    PirateboatSitPointRoot: Node = null;
    PirateboatSitRootCount: number = 0;
    GuoshancheSitRootCount: number = 0;

    PlayPirateboatCount: number = 0;
    GuoShanCheCount: number = 0;

    lastName: string = "";
    UnlockFerriswheel: boolean = false;
    UpgradeFerriswheel: boolean = false;
    UnlockCashier: boolean = false;
    UnlockPirateboat: boolean = false;
    UnlockCarousel: boolean = false;
    CashierWork: boolean = false;
    FerriswheelWork: boolean = false;
    PirateboatWork: boolean = false;
    PirateboatPlaying: boolean = false;
    GuoShanChePlaying = false;
    NextQueue: boolean = false;
    GameEnd: boolean = false;
    EnterCabin: Node[] = [];


    protected onLoad(): void {

        //多语言初始化
        const language = this.chooseLanguage();
        console.log(language);
        i18n.init(language);




    }

    public chooseLanguage() {
        const language = sys.languageCode;//navigator.language;
        let lan = '';
        if (language.indexOf("zh-cn") != -1) {
            lan = 'zh';
        }
        else if (language.indexOf("zh-tw") != -1 || language.indexOf("zh-hk") != -1) {
            lan = 'tw';
        }
        else if (language.indexOf("ko") != -1) {
            lan = 'ko';
        }
        else if (language.indexOf("ja") != -1) {
            lan = 'ja';
        }
        else if (language.indexOf("de") != -1) {
            lan = 'de';
        }
        else if (language.indexOf("fr") != -1) {
            lan = 'fr';
        }
        else if (language.indexOf("es") != -1) {
            lan = 'es';
        }
        else if (language.indexOf("pt") != -1) {
            lan = 'pt';
        } else if (language.indexOf("it") != -1) {
            lan = 'it';
        }
        else {
            lan = 'en';
        }
        return lan;
    }


    protected onEnable(): void {
        director.on('unlockEvent', this.UnlockEvent, this);
        director.on('workEvent', this.WorkEvent, this);
        director.on('checkEvent', this.CheckEvent, this);
        director.on('endEvent', this.EndEvent, this);
        director.on('hideRoleArrow', this.hideRoleArrow, this);

        //playable.eventSystem.on(Playable.PlayGameEvent, this.UnlockEvent.bind(this));
        //playable.eventSystem.on(Playable.PlayGameEvent, this.WorkEvent.bind(this));
        //playable.eventSystem.on(Playable.PlayGameEvent, this.CheckEvent.bind(this));
        //playable.eventSystem.on(Playable.PlayGameEvent, this.EndEvent.bind(this));

    }

    protected onDisable(): void {
        //playable.eventSystem.off(Playable.PlayGameEvent, this.UnlockEvent.bind(this));
        //playable.eventSystem.off(Playable.PlayGameEvent, this.WorkEvent.bind(this));
        //playable.eventSystem.off(Playable.PlayGameEvent, this.CheckEvent.bind(this));
        //playable.eventSystem.off(Playable.PlayGameEvent, this.EndEvent.bind(this));
    }

    hideRoleArrow() {
        this.roleArrow.active = false;
        this.scheduleOnce(() => {
            this.roleArrow.getComponent(GuideArrow).reset()
        }, 0.15)
    }

    showRoleArrow() {
        this.roleArrow.active = true;
    }

    start() {

        //director.emit('setRole', true, ["role", this.role]);
        this.GuoShanChenPiHuaTing.getComponent(AnimationComponent).on(AnimationComponent.EventType.FINISHED, (event) => {
            this.onPlayGuoShanCheFinished()
        })
        Iglobal.ParkRootCtrl = this;
        this.loadCoin();
        this.npcPrefab.forEach(prefab => {
            PoolManager.instance.prePool(prefab, 3);
        });

        resources.preload("prefabs/Pirateboat");
        resources.preload("prefabs/CarouselPre");
        resources.preload("prefabs/endingView");
        resources.preload("Effect/appear");
        this.role.active = true;
        director.emit('setRole', true, ["role", this.role]);
        /*  resources.load("Effect/appear", Prefab, (err, appearPrefab) => {
 
             const appear = instantiate(appearPrefab);
             appear.setParent(this.role, true);
             const ascale = appear.scale;
             appear.scale = v3(ascale.x * 1.3, ascale.y * 1.3, ascale.z * 1.3)
             let foot = this.role.getChildByName("move");
             appear.setWorldPosition(foot.getWorldPosition());
             this.role.active = true;
             director.emit('setRole', true, ["role", this.role]);
             this.scheduleOnce(() => {
                 appear.destroy();
             }, 3)
 
         }); */


    }

    //加载玩家身后金币
    loadCoin() {
        let parent = this.node.getChildByPath("roleRoot/gold");
        for (let i = 0; i < Iglobal.backCoinTotal; i++) {
            this.scheduleOnce(() => {
                let money1 = instantiate(this.goldPrefab);
                money1.setParent(parent);
                money1.active = true;
                money1.position = v3(0, -0.15 + 0.15 * i, 0);
            }, i * 0.05)
            Iglobal.backCoinCount++;
        }
        //console.log('count:', Iglobal.backCoinCount)
    }

    EndEvent(result, params) {
        if (params[0] == "GameEnd") {
            this.GameEnd = true;
        }
    }

    UnlockEvent(result, params) {
        if (params[0] == "UnlockFerriswheel") {
            this.UnlockFerriswheel = result;
        }
        else if (params[0] == "UnlockCashier") {
            if (result) {
                this.UnlockCashier = result;

            }
        }
        else if (params[0] == "UnlockPirateboat") {
            if (result) {
                this.UnlockPirateboat = result;

            }
        }
        else if (params[0] == "UpgradeFerriswheel") {
            if (result) {
                this.UpgradeFerriswheel = result;

            }
        }
        else if (params[0] == "UnlockCarousel") {
            if (result) {
                this.UnlockCarousel = result;
                this.CarouselRoot.getChildByName("Plan").active = false;
                this.CarouselRoot.getChildByName("CarouselPre").getChildByName("PlanBig").active = true;
            }
        }
    }

    WorkEvent(result, params) {
        if (params[0] == "CashierWorkBox") {
            this.CashierWork = result;
        }
        else if (params[0] == "FerriswheelWorkBox") {
            this.FerriswheelWork = result;
        }
        else if (params[0] == "PirateboatWorkBox") {
            this.PirateboatWork = result;
        }
        else if (params[0] == "PirateboatPath") {
            this.PirateboatPathRoot = params[1];
            this.PirateboatRotateRoot = params[2];
            this.PirateboatSitRoot = this.PirateboatRotateRoot.getChildByName("SitRoot");
            this.PirateboatSitPointRoot = this.PirateboatRotateRoot.getChildByName("SitPoint");
        }
        else if (params[0] == "FerriswheelPath") {
            this.FerriswheelPathRoot = params[1];
            this.FerriswheelRotateRoot = params[2];
            //this.FerriswheelSitPointRoot = this.FerriswheelRotateRoot.getChildByName("SitPoint");
        }
    }

    CheckEvent(result, params) {
        if (params[0] == "CheckCabin") {
            if (result) {
                if (params[1]) {
                    let Door = params[2].children[1];
                    if (Door) {
                        let OD = Door.getComponent(OpenDoor)
                        OD.PlayOpenDoor()
                    }
                    this.scheduleOnce(() => {
                        if (params[2] && params[2].children.length >= 4) {
                            let NPCRoot = params[2].children[3];
                            if (NPCRoot) {
                                NPCRoot.setParent(this.GoRoot, true);
                                let NPC1 = NPCRoot.getComponent(Npc)
                                this.scheduleOnce(() => {
                                    NPC1?.ShowEmoji2();
                                }, 0.2)
                                let narr = this.GetFPaths(1)
                                let narr2 = this.GetNPCPaths(2)
                                let narr3 = [...narr, ...narr2];
                                NPCRoot.children[0].scale = v3(1.3, 1.3, 1.3)
                                NPC1?.InitMapNavAgent(4 * gameConfig.WorkerMoveSpeedMul);
                                NPC1?.NavOnRoad(narr3, () => {
                                    NPCRoot.active = false;
                                    NPCRoot.destroy();
                                    //PoolManager.instance.putNode(NPCRoot);
                                })
                            }
                        }
                    }, 0.4)
                }
                // this.EnterCabin.push(params[2]);
            }
            else {
                // if (this.EnterCabin && this.EnterCabin.length > 0) {
                //     let i = this.EnterCabin.lastIndexOf(params[2]);
                //     if (i >= 0) {
                //         this.EnterCabin.removeAt(i)
                //     }
                // }
            }
        }
        else if (params[0] == "CheckCabin2") {
            if (result) {
                this.EnterCabin.push(params[2]);
            }
            else {
                if (this.EnterCabin && this.EnterCabin.length > 0) {
                    let i = this.EnterCabin.lastIndexOf(params[2]);
                    if (i >= 0) {
                        //this.EnterCabin.removeAt(i)
                    }
                }
            }
        }
    }

    FirstNPC: boolean = false;
    SecondNPC: boolean = false;
    CreateNPC() {
        if (!this.UnlockFerriswheel) {
            return;
        }

        if (this.CWaitRoot.children.length < 5) {
            //console.log('df',this.CWaitRoot.children.length)

            const index = randomRangeInt(0, 4);
            let npcPrefab = this.npcPrefab[index];
            const NPCRoot = PoolManager.instance.getNode(npcPrefab, this.CWaitRoot);
            NPCRoot.setParent(this.CWaitRoot, true);
            NPCRoot.position = this.CWaitRoot.getWorldPosition().add(v3(0, 0, 1.5 * this.CWaitRoot.children.length));
            const NPC1 = NPCRoot.getComponent(Npc);
            NPC1.SetAnim("idle");

        }
        for (let i = 0; i < this.CWaitRoot.children.length; i++) {
            if (this.CWaitRoot.children[i] && !this.CWaitRoot.children[i].getComponent(Npc).isWalking) {
                let WaitNPC = this.CWaitRoot.children[i];
                if (WaitNPC?.getWorldPosition().z == this.CWaitRoot.getWorldPosition().z + 1.5 * i) {
                    continue;
                }

                const WNPC1 = WaitNPC.getComponent(Npc);
                if (WNPC1.targetIndex === i) continue;
                console.log('create npc')
                WNPC1.targetIndex = i;
                WNPC1.InitMapNavAgent(4 * gameConfig.WorkerMoveSpeedMul);
                WNPC1.NavOnRoadWithFirst([WaitNPC?.getWorldPosition(), this.CWaitRoot.getWorldPosition().add(v3(0, 0, 1.5 * i))], () => {
                    WNPC1.SetAnim("idle");
                });
            }
        }
    }

    CheckOrder() {


        if (this.CashierWork) {
            if (this.NextQueue) {
                if (this.UnlockPirateboat) {
                    if (this.PWaitRoot.children.length < gameConfig.PirateboatQueueCount) {
                        let NPCRoot: Node = null;
                        for (let i = 0; i < this.CWaitRoot.children.length; i++) {
                            if (this.CWaitRoot.children.length > 0 && this.CWaitRoot.children[0] && this.CWaitRoot.children[0]?.getComponent(Npc).isEnd) {
                                NPCRoot = this.CWaitRoot.children[0];
                                break;
                            }
                        }
                        if (NPCRoot) {
                            NPCRoot.setParent(this.PWaitRoot, true);
                            let NPC1 = NPCRoot.getComponent(Npc);
                            NPC1.InitMapNavAgent(4 * gameConfig.WorkerMoveSpeedMul);
                            let endP: Vec3 = this.PWaitRoot.getWorldPosition();
                            let i = NPCRoot.getSiblingIndex()
                            endP.add(v3(0, 0, 1.5 * i));
                            let narr = this.GetNPCPaths(1)
                            narr.push(endP);
                            NPC1.targetIndex = i;
                            NPC1.NavOnRoadWithFirst(narr, () => {
                                NPC1.SetAnim("idle");
                            });
                            //playable.eventSystem.dispatch(Playable.PlayGameEvent, true, ["EnterParkCoin", gameConfig.PlayParkCost]);
                            director.emit('addCoin', true, ["EnterParkCoin", gameConfig.PlayParkCost]);
                        }
                    }
                    if (this.FWaitRoot.children.length < gameConfig.FerriswheelQueueCount) {
                        this.NextQueue = false;
                    }
                }
                else {
                    this.NextQueue = false;
                }
            }
            else {
                if (this.FWaitRoot.children.length < gameConfig.FerriswheelQueueCount) {

                    let NPCRoot: Node = null;
                    for (let i = 0; i < this.CWaitRoot.children.length; i++) {
                        if (this.CWaitRoot.children.length > 0 && this.CWaitRoot.children[0] && this.CWaitRoot.children[0]?.getComponent(Npc).isEnd) {
                            NPCRoot = this.CWaitRoot.children[0];
                            break;
                        }
                    }
                    if (NPCRoot) {
                        if (!this.FirstNPC) {
                            this.FirstNPC = true;
                            //playable.sendAction(3);
                        }

                        NPCRoot.setParent(this.FWaitRoot, true);
                        //console.log(NPCRoot.name)
                        let NPC1 = NPCRoot.getComponent(Npc);
                        NPC1.InitMapNavAgent(4 * gameConfig.WorkerMoveSpeedMul);
                        let endP: Vec3 = this.FWaitRoot.getWorldPosition();
                        //let i = this.FWaitRoot.children.length - 1;
                        let i = NPCRoot.getSiblingIndex()
                        endP.add(v3(0, 0, 1.5 * i));
                        let narr = this.GetNPCPaths(0)
                        narr.push(endP);
                        NPC1.targetIndex = i;
                        NPC1.NavOnRoadWithFirst(narr, () => {
                            NPC1.SetAnim("idle");
                        });
                        //playable.eventSystem.dispatch(Playable.PlayGameEvent, true, ["EnterParkCoin", gameConfig.PlayParkCost]);
                        director.emit('addCoin', true, ["EnterParkCoin", gameConfig.PlayParkCost]);
                    }
                    if (this.UnlockPirateboat && this.PWaitRoot.children.length < gameConfig.PirateboatQueueCount) {
                        this.NextQueue = true;
                    }
                }
                else {
                    if (this.UnlockPirateboat && this.PWaitRoot.children.length < gameConfig.PirateboatQueueCount) {
                        this.NextQueue = true;
                    }
                }
            }
        }


        if (this.UnlockFerriswheel && this.FerriswheelWork && !this.GuoShanChePlaying) {
            let NPCRoot: Node = null;

            for (let i = 0; i < this.FWaitRoot.children.length; i++) {
                if (this.FWaitRoot.children.length > 0 && this.FWaitRoot.children[0] && this.FWaitRoot.children[0]?.getComponent(Npc).isEnd) {
                    NPCRoot = this.FWaitRoot.children[0];
                    break;
                }
            }



            if (NPCRoot) {

                let NPC1 = NPCRoot.getComponent(Npc);


                let gscPoint = this.GuoShanChenSitPointRootArray[this.GuoshancheSitRootCount];

                //let endP: Vec3 = this.GuoShanChenSitPointRoot.children[this.GuoShanCheSitRoot.children.length]?.getWorldPosition();
                let endP: Vec3 = gscPoint?.getWorldPosition();
                let narr = this.GetFPaths(0)


                //NPCRoot.setParent(this.GuoShanCheSitRoot, true);
                NPCRoot.setParent(this.GuoShanCheSitRootArray[this.GuoshancheSitRootCount], true);

                this.GuoshancheSitRootCount++;
                if (this.GuoshancheSitRootCount >= gameConfig.FerriswheelQueueCount) {
                    this.GuoShanChePlaying = true;
                    Iglobal.guoShanChePlaying = true;
                }

                NPCRoot.setWorldScale(v3(1, 1, 1))
                NPC1.InitMapNavAgent(4 * gameConfig.WorkerMoveSpeedMul);
                NPC1.NavOnRoadWithFirst(narr, () => {


                    NPCRoot.eulerAngles = new Vec3(NPCRoot.eulerAngles.x, -180, NPCRoot.eulerAngles.z);
                    NPCRoot.setWorldPosition(endP)
                    NPC1.SetAnim("slide", 0.5);
                    this.GuoShanCheCount++;
                    if (this.GuoShanCheCount >= gameConfig.FerriswheelQueueCount) {
                        this.GuoShanCheCount = 0;
                        //playable.eventSystem.dispatch(Playable.PlayGameEvent, true, ["PlayFerriswheelCoin", gameConfig.FerriswheelCost]);
                        director.emit('addCoin', true, ["PlayFerriswheelCoin", gameConfig.FerriswheelCost]);
                        this.playGuoShanChe()
                    }

                })

            }
        }

        if (this.UnlockFerriswheel) {
            for (let i = 0; i < this.FWaitRoot.children.length; i++) {
                if (this.FWaitRoot.children[i]) {
                    let WaitNPC = this.FWaitRoot.children[i];
                    if (WaitNPC.worldPosition.z < (this.FWaitRoot.worldPositionZ + 1.5 * 5)) {
                        const WNPC1 = WaitNPC?.getComponent(Npc);
                        //console.log(WNPC1.targetIndex, i)
                        if (WNPC1.targetIndex === i) continue;
                        WNPC1.InitMapNavAgent(4 * gameConfig.WorkerMoveSpeedMul);
                        WNPC1.targetIndex = i;
                        WNPC1.NavOnRoadWithFirst([WaitNPC?.getWorldPosition(), this.FWaitRoot.getWorldPosition().add(v3(0, 0, 1.5 * i))], () => {
                            //WaitNPC.eulerAngleY = -90;
                            WaitNPC.eulerAngles = new Vec3(WaitNPC.eulerAngles.x, -90, WaitNPC.eulerAngles.z);
                            WNPC1.SetAnim("idle");
                        });
                    }
                }
            }
        }


        if (this.UnlockPirateboat && this.PirateboatWork && !this.PirateboatPlaying) {
            let NPCRoot: Node = null;
            for (let i = 0; i < this.PWaitRoot.children.length; i++) {
                if (this.PWaitRoot.children.length > 0 && this.PWaitRoot.children[0] && this.PWaitRoot.children[0]?.getComponent(Npc).isEnd) {
                    NPCRoot = this.PWaitRoot.children[0];
                    break;
                }
            }
            if (NPCRoot) {
                let NPC1 = NPCRoot.getComponent(Npc);
                let endP: Vec3 = this.PirateboatSitPointRoot.children[this.PirateboatSitRoot.children.length]?.getWorldPosition();
                let narr = this.GetPPaths(0)
                //narr.push(endP);
                this.PirateboatSitRootCount++;
                if (this.PirateboatSitRootCount >= 6) {
                    this.PirateboatPlaying = true;
                }
                NPCRoot.setParent(this.PirateboatSitRoot, true);

                NPCRoot.setWorldScale(v3(1, 1, 1))
                NPC1.InitMapNavAgent(4 * gameConfig.WorkerMoveSpeedMul);
                NPC1.NavOnRoadWithFirst(narr, () => {
                    //这个回调是npc先到先执行的,所以路径节点要注意设置远近
                    if (this.PlayPirateboatCount == 0) {
                        //NPCRoot.eulerAngleY = -150;
                        NPCRoot.eulerAngles = new Vec3(0, -150, 0);
                    }
                    else if (this.PlayPirateboatCount == 1) {
                        //NPCRoot.eulerAngleY = 150;
                        NPCRoot.eulerAngles = new Vec3(0, 150, 0);
                    }
                    else if (this.PlayPirateboatCount == 2) {
                        //NPCRoot.eulerAngleY = -90;
                        NPCRoot.eulerAngles = new Vec3(0, -90, 0);
                    }
                    else if (this.PlayPirateboatCount == 3) {
                        //NPCRoot.eulerAngleY = 90
                        NPCRoot.eulerAngles = new Vec3(0, 90, 0);
                    }
                    else if (this.PlayPirateboatCount == 4) {
                        //NPCRoot.eulerAngleY = -30;
                        NPCRoot.eulerAngles = new Vec3(0, -30, 0);
                    }
                    else if (this.PlayPirateboatCount == 5) {
                        //NPCRoot.eulerAngleY = 60
                        NPCRoot.eulerAngles = new Vec3(0, 60, 0);
                    }
                    //NPCRoot.eulerAngleY = -150 + this.PlayPirateboatCount * 60;
                    NPC1.SetAnim("slide", 0.5);
                    NPCRoot.setWorldPosition(endP);
                    this.PlayPirateboatCount++;
                    if (this.PlayPirateboatCount >= 6) {
                        this.PlayPirateboatCount = 0;
                        //playable.eventSystem.dispatch(Playable.PlayGameEvent, true, ["PlayPirateboatCoin", gameConfig.PirateboatCost * 6]);
                        director.emit('addCoin', true, ["PlayPirateboatCoin", gameConfig.PirateboatCost * 6]);
                        this.PlayPirateboat();
                        AudioMgr.inst.playOneShot("common/audio/sm_dabaichui", 1.0)
                    }
                })
            }

        }

        if (this.UnlockPirateboat) {

            for (let i = 0; i < this.PWaitRoot.children.length; i++) {
                if (this.PWaitRoot.children[i] /*&& !this.PWaitRoot.children[i]?.getComponent(Npc).isWalking*/) {
                    let WaitNPC = this.PWaitRoot.children[i];
                    /* if (WaitNPC?.getWorldPosition().z == this.PWaitRoot.getWorldPosition().z + 1.5 * i) {
                        continue;
                    } */
                    if (WaitNPC.worldPositionZ < this.PWaitRoot.worldPositionZ + 1.5 * 6) {
                        const WNPC1 = WaitNPC?.getComponent(Npc);
                        if (WNPC1.targetIndex === i) continue;
                        WNPC1.targetIndex = i;
                        WNPC1.InitMapNavAgent(4 * gameConfig.WorkerMoveSpeedMul);
                        WNPC1.NavOnRoadWithFirst([WaitNPC?.getWorldPosition(), this.PWaitRoot.getWorldPosition().add(v3(0, 0, 1.5 * i))], () => {
                            //WaitNPC.eulerAngleY = 0;
                            WaitNPC.eulerAngles = new Vec3(0, 0, 0);
                            WNPC1?.SetAnim("idle");
                        });
                    }
                }
            }
        }



        if (this.CWaitRoot.children.length > 0) {
            if (this.CWaitRoot.children[0] && !this.CWaitRoot.children[0]?.getComponent(Npc).isWalking) {
                let WaitNPC = this.CWaitRoot.children[0];
                const WNPC1 = WaitNPC?.getComponent(Npc);
                WNPC1?.ShowEmoji1();
            }
        }

        if (this.FWaitRoot.children.length > 0) {
            if (this.FWaitRoot.children[0] && !this.FWaitRoot.children[0]?.getComponent(Npc).isWalking) {
                let WaitNPC = this.FWaitRoot.children[0];
                const WNPC1 = WaitNPC?.getComponent(Npc);
                WNPC1?.ShowEmoji1();
            }

        }

        if (this.PWaitRoot.children.length > 0) {
            if (this.PWaitRoot.children[0] && !this.PWaitRoot.children[0]?.getComponent(Npc).isWalking) {
                let WaitNPC = this.PWaitRoot.children[0];
                const WNPC1 = WaitNPC?.getComponent(Npc);
                WNPC1?.ShowEmoji1();
            }

        }
    }

    PlayFerriswheel(NPCRoot: Node, Cabin: Node) {
        NPCRoot.setParent(Cabin, true);
        NPCRoot.setWorldPosition(Cabin.children[2]?.getWorldPosition())
        NPCRoot.children[0].scale = v3(1, 1, 1)
        NPCRoot.eulerAngles = v3(90, 0, 90);
        let NPC1 = NPCRoot.getComponent(Npc);
        NPC1?.SetAnim("slide");
    }

    PlayPirateboat() {
        this.PirateboatSitRootCount = 0;

        new XTween(this.PirateboatRotateRoot)
            .to(0.7, { eulerAngles: new Vec3(0, 0, -45) }, { easing: XTween.Easing.quadraticOut })
            .to(1.4, { eulerAngles: new Vec3(0, 0, 45) }, { easing: XTween.Easing.quadraticInOut })
            .to(1.4, { eulerAngles: new Vec3(0, 0, -45) }, { easing: XTween.Easing.quadraticInOut })
            .to(1.4, { eulerAngles: new Vec3(0, 0, 45) }, { easing: XTween.Easing.quadraticInOut })
            .to(1.4, { eulerAngles: new Vec3(0, 0, -45) }, { easing: XTween.Easing.quadraticInOut })
            .to(1.4, { eulerAngles: new Vec3(0, 0, 45) }, { easing: XTween.Easing.quadraticInOut })
            .to(0.7, { eulerAngles: new Vec3(0, 0, 0) }, { easing: XTween.Easing.quadraticInOut })
            .play();

        this.scheduleOnce(() => {

            for (let i = 0; i < 6; i++) {
                let NPCRoot = this.PirateboatSitRoot.children[this.PirateboatSitRoot.children.length - 1];
                if (NPCRoot) {
                    NPCRoot.setParent(this.GoRoot, true);
                    NPCRoot.setWorldScale(v3(1, 1, 1))
                    let NPC1 = NPCRoot.getComponent(Npc);
                    NPC1.ShowEmoji2();
                    let narr = this.GetPPaths(1)
                    let narr2 = this.GetNPCPaths(3)
                    let narr3 = [...narr, ...narr2];
                    this.scheduleOnce(() => {
                        if (Iglobal.GameOver) return;
                        NPCRoot.setWorldPosition(narr[0]);
                        NPC1.InitMapNavAgent(4 * gameConfig.WorkerMoveSpeedMul);
                        NPC1.NavOnRoadWithFirst(narr3, () => {
                            NPCRoot.active = false;
                            //NPCRoot.destroy();
                            NPC1.recycleReset();
                            PoolManager.instance.putNode(NPCRoot);
                        })
                    }, 0.3 * i)
                }
            }
        }, 8.4);
        this.scheduleOnce(() => {
            this.PirateboatPlaying = false
        }, 11);
    }

    playGuoShanChe() {
        AudioMgr.inst.playOneShot("common/audio/sm_guoshanche", 0.5)
        this.GuoshancheSitRootCount = 0;
        this.GuoShanChenPiHuaTing.getComponent(AnimationComponent).play();
        /* this.scheduleOnce(() => {
            const panel = this.node.getComponent(GuoShanChePanel);
            panel.waterEffect.getComponentsInChildren(ParticleSystem).forEach((ps) => {
                ps?.stop();
                ps?.clear();
                ps?.play();
            })
        }, 1.6) */
    }

    onPlayGuoShanCheFinished() {

        for (let i = 0; i < gameConfig.FerriswheelQueueCount; i++) {
            //let NPCRoot = this.GuoShanCheSitRoot.children[this.GuoShanCheSitRoot.children.length - 1];
            let NPCRoot = this.GuoShanCheSitRootArray[i].children[0];
            if (NPCRoot) {
                NPCRoot.setParent(this.GoRoot, true);
                NPCRoot.setWorldScale(v3(1, 1, 1))
                let NPC1 = NPCRoot.getComponent(Npc);
                NPC1.ShowEmoji2();
                let narr = this.GetFPaths(1)
                let narr2 = this.GetNPCPaths(2)

                //...[NPCRoot?.getWorldPosition()],离开的时候不需要添加进去数组
                let narr3 = [...narr, ...narr2];
                this.scheduleOnce(() => {
                    if (Iglobal.GameOver) return;
                    NPCRoot.setWorldPosition(narr[0])
                    NPC1.InitMapNavAgent(4 * gameConfig.WorkerMoveSpeedMul);
                    NPC1.NavOnRoadWithFirst(narr3, () => {
                        NPCRoot.active = false;
                        //NPCRoot.destroy();
                        NPC1.recycleReset();
                        PoolManager.instance.putNode(NPCRoot);
                    })
                }, 0.3 * i)
            }
        }


        this.scheduleOnce(() => {
            this.GuoShanChePlaying = false;
            Iglobal.guoShanChePlaying = false;
        }, 0.6);
    }

    GetNPCPaths(pindex: number): Vec3[] {
        let path: Vec3[] = [];
        for (let i = 0; i < this.NPCPathRoot.children[pindex].children.length; i++) {
            path.push(this.NPCPathRoot.children[pindex].children[i]?.getWorldPosition())
        }
        return path;
    }

    GetFPaths(pindex: number): Vec3[] {
        let path: Vec3[] = [];
        for (let i = 0; i < this.FerriswheelPathRoot.children[pindex].children.length; i++) {
            path.push(this.FerriswheelPathRoot.children[pindex].children[i]?.getWorldPosition())
        }
        return path;
    }

    GetPPaths(pindex: number): Vec3[] {
        let path: Vec3[] = [];
        for (let i = 0; i < this.PirateboatPathRoot.children[pindex].children.length; i++) {
            path.push(this.PirateboatPathRoot.children[pindex].children[i]?.getWorldPosition())
        }
        return path;
    }

    updateGuoShanCheNodes() {
        const panel = this.node.getComponent(GuoShanChePanel);
        //this.GuoShanCheSitRoot = panel.GuoShanCheSitRoot2;
        //this.GuoShanChenSitPointRoot = panel.GuoShanChenSitPointRoot2;
        this.GuoShanCheSitRootArray = panel.GuoShanCheSitRootArray2;
        this.GuoShanChenSitPointRootArray = panel.GuoShanChenSitPointRootArray2;
        this.GuoShanChenPiHuaTing = panel.GuoShanChenPiHuaTing2;
        this.GuoShanChenPiHuaTing.getComponent(AnimationComponent).on(AnimationComponent.EventType.FINISHED, (event) => {
            this.onPlayGuoShanCheFinished()
        })
    }

    sumTime: number = 0;

    update(deltaTime: number) {
        if (this.GameEnd) {
            return;
        }
        this.sumTime += deltaTime;
        if (this.sumTime >= 0.1) {
            this.sumTime = 0;

            this.CreateNPC();
            this.CheckOrder();

        }
    }
}


