import { Vec3, director, v3 } from 'cc';
import { SkeletalAnimation } from 'cc';
import { CCInteger } from 'cc';
import { Quat } from 'cc';
import { _decorator, Component, Node } from 'cc';
//import { playable, Playable } from 'mvplayable';
const { ccclass, property } = _decorator;

@ccclass('Npc')
export class Npc extends Component {
    @property(SkeletalAnimation)
    anim: SkeletalAnimation = null;
    @property(Node)
    emoji1: Node = null;
    @property(Node)
    emoji2: Node = null;
    @property(CCInteger)
    NeedStop: number = 0;
    private speed: number = 1.0;
    private roadData: Array<any> = null;
    private nextStep: number = 1;
    private vx: number;
    private vy: number;
    private vz: number;
    private walkTime: number = 0.0;
    private passedTime: number = 0.0;
    public isWalking: boolean = false;
    public totalTime: number = 0;
    public isEnd: boolean = false;
    lastanim: string = "";
    private dstRot: Quat = new Quat();
    private now: Quat = new Quat();
    private endFunc: Function = null;
    GameEnd: boolean = false;
    //目标位置索引
    public targetIndex: number = -1;



    /* protected onEnable(): void {
        if (this.NeedStop < 0.5) {
            //playable.eventSystem.on(Playable.PlayGameEvent, this.NPCEndEvent.bind(this));
            director.on('NPCEndEvent', this.NPCEndEvent, this);
        }
    }

    protected onDisable(): void {
        if (this.NeedStop < 0.5) {
            //playable.eventSystem.off(Playable.PlayGameEvent, this.NPCEndEvent.bind(this));
            director.off('NPCEndEvent', this.NPCEndEvent, this);
        }
    } */

    recycleReset() {
        this.NeedStop = 0;
        this.roadData = [];
        this.nextStep = 1;
        this.walkTime = 0.0;
        this.passedTime = 0.0;
        this.isWalking = false;
        this.isEnd = false;
        this.totalTime = 0;
        this.lastanim = "";
        this.dstRot.set(0, 0, 0, 0);
        this.now.set(0, 0, 0, 0);
        this.endFunc = null;
        this.GameEnd = false;
        this.emoji1.active = false;
        this.emoji2.active = false;
    }


    NPCEndEvent(result, params) {
        if (params[0] == "GameEnd") {
            this.anim?.crossFade("idle", 0.1);
            this.GameEnd = true;
        }
    }

    public InitMapNavAgent(speed: number) {
        this.speed = speed;
        this.isEnd = false;
        this.isWalking = true;
        //this.SetAnim("run");
        this.SetAnim("walk");
        this.HideEmoji1();
    }

    public ResetSpeedDir() {
        if (this.nextStep >= this.roadData.length) {
            return;
        }
        var src: Vec3 = this.node.getWorldPosition();
        var dst: Vec3 = v3(this.roadData[this.nextStep].x, this.roadData[this.nextStep].y, this.roadData[this.nextStep].z);

        var dir: Vec3 = v3(0, 0, 0);
        Vec3.subtract(dir, dst, src);
        var len = Vec3.len(dir);
        if (len <= 0) {
            return;
        }
        this.vx = this.speed * dir.x / len;
        this.vy = this.speed * dir.y / len;
        this.vz = this.speed * dir.z / len;

        this.walkTime = len / this.speed;
        this.totalTime += this.walkTime;
        this.passedTime = 0;
    }

    public NavOnRoad(roadData: Array<any>, endFunc: Function) {
        this.roadData = roadData;
        this.endFunc = endFunc;
        this.isWalking = false;
        if (this.roadData == null || this.roadData.length < 2) {
            return;
        }

        this.node.setWorldPosition(this.roadData[0].x, this.roadData[0].y, this.roadData[0].z);
        this.nextStep = 1;
        this.MoveToNext();
    }

    public NavOnRoadWithFirst(roadData: Array<any>, endFunc: Function) {
        this.roadData = roadData;
        this.endFunc = endFunc;
        this.isWalking = false;
        if (this.roadData == null || this.roadData.length < 1) {
            return;
        }

        this.nextStep = 0;
        this.MoveToNext();
    }

    private MoveToNext() {
        if (this.nextStep >= this.roadData.length) {

            this.isWalking = false;
            this.isEnd = true;
            if (this.endFunc) {
                this.endFunc();
                this.endFunc = null;
            }
            //this.anim.crossFade("idle",0.1);
            return;
        }
        var src: Vec3 = this.node.getWorldPosition();
        var dst: Vec3 = v3(this.roadData[this.nextStep].x, this.roadData[this.nextStep].y, this.roadData[this.nextStep].z);

        var dir: Vec3 = v3(0, 0, 0);
        Vec3.subtract(dir, dst, src);
        var len = Vec3.len(dir);
        if (len <= 0) {
            this.nextStep++;
            this.MoveToNext();
            return;
        }

        this.vx = this.speed * dir.x / len;
        this.vy = this.speed * dir.y / len;
        this.vz = this.speed * dir.z / len;

        this.walkTime = len / this.speed;
        this.totalTime += this.walkTime;
        this.passedTime = 0;

        this.isWalking = true;

        var old: Quat = this.node.getRotation();
        this.node.lookAt(dst);
        this.dstRot = this.node.getRotation();
        this.node.setRotation(old);
    }

    public PauseMove() {
        this.isWalking = false;
    }

    public ResumeMove() {
        this.isWalking = true;
    }

    public ShowEmoji1() {
        this.emoji1.active = true;
        this.emoji2.active = false;
    }

    public HideEmoji1() {
        if (this.emoji1) {
            this.emoji1.active = false;
        }
    }

    public ShowEmoji2() {
        this.emoji1.active = false;
        this.emoji2.active = true;
    }

    public SetAnim(animName: string, sp: number = 1) {
        if (animName == this.lastanim) {
            return;
        }
        this.anim.crossFade(animName, 0.3);
        if (this.anim.clips.length >= 3) {
            this.anim.clips[2].speed = sp;
        }
        this.lastanim = animName;
    }

    public update(dt: number) {
        if (!this.isWalking) {
            return;
        }
        if (this.GameEnd) {
            return;
        }



        this.passedTime += dt;
        if (this.passedTime > this.walkTime) {
            dt -= (this.passedTime - this.walkTime);
        }

        var pos = this.node.getWorldPosition();
        pos.x += (this.vx * dt);
        pos.y += (this.vy * dt);
        pos.z += (this.vz * dt);
        this.node.setWorldPosition(pos);

        Quat.slerp(this.now, this.node.getRotation(), this.dstRot, 10.0 * dt);
        this.node.setRotation(this.now);
        /*   this.node.eulerAngleX = 0;
          this.node.eulerAngleZ = 0; */
        this.node.eulerAngles = new Vec3(0, this.node.eulerAngles.y, 0);
        if (this.passedTime >= this.walkTime) {
            this.nextStep++;
            this.MoveToNext();
        }
    }
}


