import { Material } from 'cc';
import { MeshRenderer } from 'cc';
import { _decorator, Component, Node } from 'cc';
const { ccclass, property } = _decorator;

@ccclass('UpdateMat')
export class UpdateMat extends Component {
    @property(MeshRenderer)
    m1: MeshRenderer = null;
    @property(MeshRenderer)
    m2: MeshRenderer = null;
    @property(MeshRenderer)
    m3: MeshRenderer = null;
    @property(MeshRenderer)
    m4: MeshRenderer = null;

    @property(Material)
    mat1: Material = null;


    start() {

    }

    protected onEnable(): void {
        this.m1.material = this.mat1;
        this.m2.material = this.mat1;
        this.m3.material = this.mat1;
        this.m4.material = this.mat1;
    }

    update(deltaTime: number) {

    }
}


