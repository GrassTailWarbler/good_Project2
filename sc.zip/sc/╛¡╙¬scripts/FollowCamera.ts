import { _decorator, Component, Node, Camera, Vec3, v3 } from 'cc';
const { ccclass, property } = _decorator;

let tempPos: Vec3 = v3();

/**
 * 固定跟随相机
 */
@ccclass('FollowCamera')
export class FollowCamera extends Component {

    @property(Node)
    target: Node | null = null;

    @property(Camera)
    camera: Camera | null = null;

    // 在类属性中添加平滑参数
    @property({ tooltip: "跟随平滑系数(0-1),值越大越平滑" })
    smoothFactor: number = 0.1;


    initialDirection: Vec3 = v3();

    speed: number = 0.0;

    start() {
        Vec3.subtract(this.initialDirection, this.node.worldPosition, this.target!.worldPosition);
        this.camera.node.lookAt(this.target.worldPosition, Vec3.UP);
        //console.log(this.camera.fov)
    }

    update(deltaTime: number) {
        if (!this.target) return;

        // 计算目标位置
        Vec3.add(tempPos, this.target.worldPosition, this.initialDirection);

        // 使用平滑阻尼移动
        Vec3.lerp(
            this.node.worldPosition,
            this.node.worldPosition,
            tempPos,
            //deltaTime
            this.smoothFactor * deltaTime * 60  // 补偿帧率影响
        );

        // 或使用更精确的阻尼计算(二选一)
        // Vec3.smoothDamp(
        //     this.node.worldPosition,
        //     tempPos,
        //     this._currentVelocity,
        //     this.smoothTime
        // );

        this.node.setWorldPosition(this.node.worldPosition);
    }
}

