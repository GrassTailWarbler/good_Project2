import { BoxCollider, CCString, ITriggerEvent } from 'cc';
import { _decorator, Component, Node } from 'cc';
//import { OrbitFollowTarget, playable, Playable } from 'mvplayable';
import { gameConfig } from './GameConfig';
import { resources, Prefab, instantiate, v3 } from 'cc';
import { director } from 'cc';
import { ParticleSystem } from 'cc';
import { XTween } from './xtween/XTween';
import { BezierMoney } from './BezierMoney';
import { AudioMgr } from './AudioMgr';
import { GuidManager } from './GuidManager';
import { Iglobal } from './Iglobal';
import { PoolManager } from './PoolManager';
const { ccclass, property } = _decorator;

@ccclass('CoinBox')
export class CoinBox extends Component {
    @property(BoxCollider)
    public boxC: BoxCollider = null;
    @property(CCString)
    public EName: string = "";
    GetCoin: boolean = false;
    public CoinCount: number = 0;
    @property(Node)
    public ActiveBox: Node = null;
    @property(Node)
    public ArrowModel: Node = null;
    @property(Prefab)
    goldPrefab: Prefab = null;

    FirstGet: boolean = false;
    ShowArrow: boolean = false;
    goldCount: number = 0;
    goldSum: number = 0;

    EnterParkCoinNodeCount = 0;
    PlayFerriswheelCoinNodeCount = 0;
    PlayPirateboatCoinNodeCount = 0;

    start() {
        director.on('addCoin', this.AddCoin, this);
    }

    protected onEnable(): void {
        this.boxC.on("onTriggerEnter", this.onTrigger, this);
        this.boxC.on("onTriggerExit", this.onTriggerExit, this);
        ///playable.eventSystem.on(Playable.PlayGameEvent, this.AddCoin.bind(this));
    }

    protected onDisable(): void {
        this.boxC.off("onTriggerEnter", this.onTrigger, this);
        this.boxC.off("onTriggerExit", this.onTriggerExit, this);
        ///playable.eventSystem.off(Playable.PlayGameEvent, this.AddCoin.bind(this));
    }

    private onTrigger(event: ITriggerEvent) {
        if (!event.otherCollider) {
            return;
        }
        if (event.otherCollider.node.name !== "roleRoot") {
            return;
        }
        this.GetCoin = true;
        //计算背后金币数量
        let goldRoot = Iglobal.ParkRootCtrl.node.getChildByPath("roleRoot/gold");
        this.goldCount = 0;
        this.goldSum = goldRoot.children.length;

        if (!this.FirstGet) {
            if (this.CoinCount <= 0) {
                return;
            }
            this.FirstGet = true
            if (this.EName == "EnterParkCoin") {
                if (this.ActiveBox) {
                    this.ActiveBox.active = true;
                }
                //playable.eventSystem.dispatch(Playable.PlayGameEvent, false, ["GuideTarget", this.ActiveBox]);
                director.emit('setTarget', false, ["GuideTarget", this.ActiveBox]);
            }
            else if (this.EName == "PlayFerriswheelCoin") {
                if (this.ActiveBox) {
                    this.ActiveBox.active = true;
                    //playable.eventSystem.dispatch(Playable.PlayGameEvent, true, ["PlayingCamera", 1]);
                    /* let orbit = director.getScene().getChildByName("Main Camera").getComponent(OrbitFollowTarget)
                    let role = orbit.target;
                    orbit.target = this.ActiveBox;
                    this.scheduleOnce(() => {
                        playable.eventSystem.dispatch(Playable.PlayGameEvent, false, ["PlayingCamera", 1]);
                        orbit.target = role;
                    }, 2); */
                }
                //playable.eventSystem.dispatch(Playable.PlayGameEvent, true, ["GuideTarget", this.ActiveBox]);
                director.emit('setTarget', true, ["GuideTarget", this.ActiveBox]);
                //console.log('guidmander ready')
                GuidManager.instance.readyGuid = true;
            }
            if (this.ArrowModel) {
                this.ArrowModel.active = false;
            }

        }
        GuidManager.instance.finishedGuid(this.ArrowModel);

    }

    private onTriggerExit(event: ITriggerEvent) {
        if (!event.otherCollider) {
            return;
        }
        if (event.otherCollider.node.name !== "roleRoot") {
            return;
        }
        this.AddCount = 0;
        let ColMoney = director.getScene().getChildByName("ParkRoot")?.getChildByName("roleRoot")?.getChildByName("collect")
        ColMoney.active = false;
        this.GetCoin = false;

        if (this.ArrowModel && this.ArrowModel.active && !this.FirstGet && this.EName == "PlayFerriswheelCoin") {

            this.FirstGet = true

            if (this.ActiveBox) {
                this.ActiveBox.active = true;
            }

            director.emit('setTarget', true, ["GuideTarget", this.ActiveBox]);
            GuidManager.instance.readyGuid = true;

            this.ArrowModel.active = false;
            GuidManager.instance.finishedGuid(this.ArrowModel);
        }

    }

    AddCoin(result, params) {
        if (params[0] == this.EName) {
            if (this.ArrowModel && !this.ShowArrow) {
                this.ShowArrow = true;
                this.ArrowModel.active = true;
                //playable.eventSystem.dispatch(Playable.PlayGameEvent, false, ["GuideTarget", this.ArrowModel]);
                director.emit('setTarget', false, ["GuideTarget", this.ArrowModel]);
            }
            if (typeof params[1] == "number") {
                if (this.EName == "EnterParkCoin") {
                    //console.log('EnterParkCoin')
                    resources.load("prefabs/Money1", Prefab, (err, moneyPrefab) => {
                        if (this.EnterParkCoinNodeCount < 20) {//限制钱生成的数量
                            let money1 = instantiate(moneyPrefab);
                            money1.setParent(this.node, true);
                            let i = Math.ceil(this.node.children.length / 4);
                            money1.position = v3(0.5 - 0.4 * ((this.node.children.length % 4) == 0 ? 4 : (this.node.children.length % 4)), -0.15 + 0.15 * i, 0);
                            if (this.GetCoin) {

                            }
                            else {
                                new XTween(money1).from(0.2, { scale: v3() }).play();
                            }
                        }
                        this.EnterParkCoinNodeCount++;

                        this.CoinCount += params[1];
                        //console.log('get money', this.CoinCount)
                    });
                }
                else if (this.EName == "PlayPirateboatCoin") {
                    //console.log('PlayPirateboatCoin')
                    resources.load("prefabs/Money2", Prefab, (err, moneyPrefab) => {
                        for (let i = 0; i < 3; i++) {
                            if (this.PlayPirateboatCoinNodeCount < 8) {
                                let money2 = instantiate(moneyPrefab);
                                money2.setParent(this.node, true);
                                money2.position = v3(0, -0.15 + 0.15 * this.node.children.length, 0);
                                if (this.GetCoin) {

                                }
                                else {
                                    new XTween(money2).from(0.2, { scale: v3() }).play();
                                }
                            }
                            this.PlayPirateboatCoinNodeCount++;
                            this.CoinCount += params[1];
                        }
                    });


                }
                else if (this.EName == "PlayFerriswheelCoin") {
                    resources.load("prefabs/Money3", Prefab, (err, moneyPrefab) => {

                        if (this.PlayFerriswheelCoinNodeCount < 8) {
                            let money2 = instantiate(moneyPrefab);
                            money2.setParent(this.node, true);
                            money2.position = v3(0, -0.15 + 0.3 * this.node.children.length, 0);
                            if (this.GetCoin) {

                            }
                            else {
                                new XTween(money2).from(0.2, { scale: v3() }).play();
                            }
                        }

                        this.CoinCount += params[1];
                        this.PlayFerriswheelCoinNodeCount++;
                    });
                }
                else {
                    resources.load("prefabs/Money2", Prefab, (err, moneyPrefab) => {
                        let money2 = instantiate(moneyPrefab);
                        money2.setParent(this.node, true);
                        money2.position = v3(0, -0.15 + 0.15 * this.node.children.length, 0);
                        if (this.GetCoin) {

                        }
                        else {
                            new XTween(money2).from(0.2, { scale: v3() }).play();
                        }
                        this.CoinCount += params[1];
                    });
                }
            }
        }
    }

    DelCount: number = 0;
    AddCount: number = 0;
    DispatchGetCoinMsg() {

        if (this.CoinCount > 0.9) {

            if (this.EName == "EnterParkCoin") {
                this.CoinCount -= gameConfig.PlayParkCost;
                //console.log('get money--',this.CoinCount)
                if (this.CoinCount < 0) {
                    this.CoinCount = 0;
                }

                if (this.node.children.length > 0) {
                    let index = this.node.children.length - 1;

                    let money = this.node.children[index];
                    if (money) {
                        let PRoot = director.getScene().getChildByName("ParkRoot");
                        let Role = director.getScene().getChildByName("ParkRoot").getChildByName("roleRoot");

                        money.setParent(PRoot, true);
                        //console.log('money++', money.children.length)
                        for (let i = 0; i < money.children.length; i++) {

                            money.children[i].getComponent(BezierMoney).PlayBezier(Role.getWorldPosition(), gameConfig.MoneyTime, money.children[i].getWorldPosition().y)
                        }
                        this.scheduleOnce(() => {
                            money.active = false;
                            money.destroy();
                        }, 6);
                    }
                    //人物背后收集金币
                    this.loadCoin();
                    this.EnterParkCoinNodeCount--;
                }
                let howMuch = gameConfig.CoinToMoney * gameConfig.PlayParkCost;
                gameConfig.BaseMoney += howMuch;
                //playable.eventSystem.dispatch(Playable.PlayGameEvent, true, ["UpdateMoney", 1]);
                director.emit('updateMoneyEvent', true, ["UpdateMoney", 1]);
            }
            else if (this.EName == "PlayFerriswheelCoin") {
                this.CoinCount -= gameConfig.FerriswheelCost;
                if (this.CoinCount < 0) {
                    this.CoinCount = 0;
                }

                //console.log('PlayFerriswheelCoin,nodelength:', this.node.children.length)
                if (this.node.children.length > 0) {

                    let money = this.node.children[this.node.children.length - 1];
                    if (money) {
                        let PRoot = director.getScene().getChildByName("ParkRoot")
                        let Role = director.getScene().getChildByName("ParkRoot").getChildByName("roleRoot")
                        money.setParent(PRoot, true)
                        for (let i = 0; i < money.children.length; i++) {
                            this.scheduleOnce(() => {
                                money.children[i].getComponent(BezierMoney).PlayBezier(Role.getWorldPosition(), gameConfig.MoneyTime, money.children[i].getWorldPosition().y)
                            }, 0.01 * i)

                        }
                        this.scheduleOnce(() => {
                            money.active = false;
                            money.destroy();
                        }, 6);
                    }

                    //人物背后收集金币
                    for (let i = 0; i < 8; i++) {
                        this.loadCoin();
                    }
                    this.PlayFerriswheelCoinNodeCount--;

                }
                gameConfig.BaseMoney += gameConfig.CoinToMoney * gameConfig.FerriswheelCost;
                //playable.eventSystem.dispatch(Playable.PlayGameEvent, true, ["UpdateMoney", 1]);
                director.emit('updateMoneyEvent', true, ["UpdateMoney", 1]);
            }
            else if (this.EName == "PlayPirateboatCoin") {
                this.CoinCount -= gameConfig.PirateboatCost;
                if (this.CoinCount < 0) {
                    this.CoinCount = 0;
                }
                //console.log('PirateboatCoin,nodelength:', this.node.children.length)
                if (this.node.children.length > 0) {

                    let money = this.node.children[this.node.children.length - 1];
                    if (money) {
                        let PRoot = director.getScene().getChildByName("ParkRoot")
                        let Role = director.getScene().getChildByName("ParkRoot").getChildByName("roleRoot")
                        money.setParent(PRoot, true)
                        for (let i = 0; i < money.children.length; i++) {
                            this.scheduleOnce(() => {
                                money.children[i].getComponent(BezierMoney).PlayBezier(Role.getWorldPosition(), gameConfig.MoneyTime, money.children[i].getWorldPosition().y)
                            }, 0.01 * i)
                        }
                        this.scheduleOnce(() => {
                            money.active = false;
                            money.destroy();
                        }, 6);
                    }

                    this.PlayPirateboatCoinNodeCount--;

                }
                //人物背后收集金币
                for (let i = 0; i < 2; i++) {
                    this.loadCoin();
                }
                gameConfig.BaseMoney += gameConfig.CoinToMoney * gameConfig.PirateboatCost;
                //playable.eventSystem.dispatch(Playable.PlayGameEvent, true, ["UpdateMoney", 1]);
                director.emit('updateMoneyEvent', true, ["UpdateMoney", 1]);
            }
            if (this.AddCount == 0) {

                AudioMgr.inst.playOneShot("common/audio/sm_money", 0.8);
            }
            let ColMoney = director.getScene().getChildByName("ParkRoot").getChildByName("roleRoot").getChildByName("collect")
            ColMoney.active = true;
            //let col = ColMoney.getComponent(ParticleSystem)
            let col2 = ColMoney.children[0].getComponent(ParticleSystem);
            //let col3 = ColMoney.children[1].getComponent(ParticleSystem)

            //col.play();
            col2.play();
            //col3.play();
            this.AddCount++;
            if (this.AddCount >= 50) {
                this.AddCount = 0;
            }

        }
    }

    //加载金币
    loadCoin() {
        if (Iglobal.backCoinCount >= Iglobal.backCoinTotal) return;
        Iglobal.backCoinCount++;
        let parent = Iglobal.ParkRootCtrl.node.getChildByPath("roleRoot/gold");
        let index = this.goldSum + this.goldCount;
        //console.log('index', index)
        let money1 = PoolManager.instance.getNode(this.goldPrefab, parent)//instantiate(this.goldPrefab);
        money1.setParent(parent);
        money1.active = true;
        money1.position = v3(0, -0.15 + 0.15 * index, 0);
        /* this.scheduleOnce(() => {
            let money1 = instantiate(this.goldPrefab);
            money1.setParent(parent);
            money1.active = true;
            money1.position = v3(0, -0.15 + 0.15 * index, 0);
            //console.log(this.goldSum)
        }, 0.1 * index) */

        /* new XTween(money1).delay(0.3 * this.goldCount).call(() => {
            money1.active = true;
        }).from(0.2, { scale: v3() }).play(); */
        this.goldCount++;
        //console.log('count:', Iglobal.backCoinCount)

    }

    sumtime: number = 0;
    update(deltaTime: number) {
        if (this.GetCoin) {

            this.DispatchGetCoinMsg();

        }
    }
}


