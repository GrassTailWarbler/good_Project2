//此文件是自动生成，请不要修改哟！ 
//import { GameConfigManager } from "mvplayable"; 
export default interface GameConfig {
	/** default value: 0 */
	ClickGoStore: number;
	/** default value: 60 */
	UnlockCashier: number;
	/** default value: 250 */
	UpgradeFerriswheel: number;
	/** default value: 100 */
	UnlockFerriswheel: number;
	/** default value: 150 */
	UnlockPirateboat: number;
	/** default value: 400 */
	UnlockCarousel: number;
	/** default value: 2 */
	CoinToMoney: number;
	/** default value: 1.35 */
	MoveSpeedMul: number;
	/** default value: 1.1 */
	WorkerMoveSpeedMul: number;
	/** default value: 4 */
	FerriswheelQueueCount: number;
	/** default value: 6 */
	PirateboatQueueCount: number;
	/** default value: 2 */
	PlayParkCost: number;
	/** default value: 8 */
	FerriswheelCost: number;
	/** default value: 4 */
	PirateboatCost: number;
	/** default value: 100 */
	BaseMoney: number;
	/** default value: 0.2 */
	MoneyTime: number;

}
export const gameConfig = {

	"ClickGoStore": 0,
	"UnlockCashier": 60,
	"UpgradeFerriswheel": 280,
	"UnlockFerriswheel": 100,
	"UnlockPirateboat": 160,
	"UnlockCarousel": 400,
	"CoinToMoney": 2,
	"MoveSpeedMul": 2.35,//1.35,
	"WorkerMoveSpeedMul": 1.1,
	"FerriswheelQueueCount": 2,
	"PirateboatQueueCount": 6,
	"PlayParkCost": 2,
	"FerriswheelCost": 16,
	"PirateboatCost": 4,
	"BaseMoney": 100,
	"MoneyTime": 0.2

}
//export const gameFlatConfig = GameConfigManager.getFlatConfigValue<GameConfig>();
declare global {
	var CC_PROJECTNAME: string;
}
globalThis.CC_PROJECTNAME = "CarnivalTycoon_IdleGames_3D_207663";