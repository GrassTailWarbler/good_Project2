import { Vec3, _decorator } from "cc";
import TweenComponent, { TweenWay } from "./TweenComponent";

const { ccclass, menu, property, executeInEditMode } = _decorator;
@ccclass('TweenPosition')
@menu("Tween/TweenPosition")
@executeInEditMode
export class TweenPosition extends TweenComponent {
    @property({ visible: function (this: TweenComponent) { return this.tweenWay == TweenWay.From || this.tweenWay == TweenWay.FromTo; } })
    readonly startPosition: Vec3 = new Vec3(0, 0, 0)
    @property({ visible: function (this: TweenComponent) { return this.tweenWay != TweenWay.From; } })
    readonly endPosition: Vec3 = new Vec3(0, 0, 0)

    protected createStartProperties(): Object {
        return { position: this.startPosition };
    }

    protected createEndProperties(): Object {
        return { position: this.endPosition };
    }
}