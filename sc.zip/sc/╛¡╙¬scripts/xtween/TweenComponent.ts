import { Component, Enum, Vec2, _decorator } from "cc";
import { EDITOR_NOT_IN_PREVIEW } from "cc/env";
import { TweenEase, createEase } from "./CocosXTween";
import { XTween } from "./XTween";

const { ccclass, property, executeInEditMode, playOnFocus } = _decorator;

enum PlayMode {
    None,
    OnLoad,
    Start,
    OnEnable,
}

export enum TweenWay {
    FromTo,
    From,
    To,
    By,
}
@ccclass('TweenComponent')
@executeInEditMode
@playOnFocus
export default abstract class TweenComponent extends Component {
    private _preview: boolean = false;
    @property({ displayOrder: 10 })
    public get preview(): boolean { return this._preview; }
    public set preview(value: boolean) {
        this._preview = value;
        if (value) this.execute();
        else if (this.tween != null) this.tween.stop();
    }
    @property
    readonly duration: number = 1;
    @property({ group: "Start" })
    readonly startDelay: Vec2 = new Vec2();
    @property({ group: "Start", type: Enum(PlayMode) })
    readonly playMode: PlayMode = PlayMode.OnLoad;

    @property({ group: "Repeat", tooltip: "重复次数，-1为无限重复，0为不重复，>0为自定义重复次数" })
    readonly repeatCount: number = 1;
    @property({ group: "Repeat" })
    readonly repeatDelay: Vec2 = new Vec2();
    @property({ group: "Repeat" })
    readonly pingPong: boolean = false;

    @property({ type: Enum(TweenWay) })
    readonly tweenWay: TweenWay = TweenWay.FromTo;

    @property({ group: "Ease", type: Enum(TweenEase) })
    readonly easing: TweenEase = TweenEase.linear;
    @property({ group: "Ease", multiline: true, visible: function (this: TweenComponent) { return this.easing == TweenEase.svgPath; } })
    readonly customEaseData: string = "";

    private tween: XTween<any>;

    onLoad(): void {
        if (this.playMode == PlayMode.OnLoad) this.execute();
    }

    start(): void {
        if (this.playMode == PlayMode.Start) this.execute();
    }

    onEnable(): void {
        if (this.playMode == PlayMode.OnEnable || !XTween.containTweens(this)) this.execute();
    }

    onDisable(): void {
        if (this.playMode == PlayMode.OnEnable) XTween.removeTagTweens(this);
    }

    onDestroy(): void {
        if (this.playMode != PlayMode.OnEnable) XTween.removeTagTweens(this);
    }

    public execute(): void {
        if (EDITOR_NOT_IN_PREVIEW && !this.preview) return;
        let startDelay = this.startDelay.y == 0 ? this.startDelay.x : Math.randomRange(this.startDelay.x, this.startDelay.y);
        let repeatDelay = this.repeatDelay.y == 0 ? this.repeatDelay.x : Math.randomRange(this.repeatDelay.x, this.repeatDelay.y);

        let tween = new XTween(this.tweenTarget, this.repeatCount == -1 ? Infinity : this.repeatCount, this.pingPong);
        switch (this.tweenWay) {
            case TweenWay.FromTo:
                tween.fromTo(this.duration, this.createStartProperties(), this.createEndProperties(), { easing: createEase(this.easing, this.customEaseData) });
                break;
            case TweenWay.From:
                tween.from(this.duration, this.createStartProperties(), { easing: createEase(this.easing, this.customEaseData) });
                break;
            case TweenWay.To:
                tween.to(this.duration, this.createEndProperties(), { easing: createEase(this.easing, this.customEaseData) });
                break;
            case TweenWay.By:
                tween.by(this.duration, this.createEndProperties(), { easing: createEase(this.easing, this.customEaseData) });
                break;
        }
        if (repeatDelay > 0)
            tween.delay(repeatDelay);

        this.tween = new XTween(this).delay(startDelay).add(tween).play();
        if (EDITOR_NOT_IN_PREVIEW) this.tween.onFinally(() => this.preview = false);
    }

    public get tweenTarget(): any { return this.node; }

    protected abstract createStartProperties(): Object;
    protected abstract createEndProperties(): Object;
}