import { director, System } from "cc";
import { EasingFunction } from "./CustomEase/CustomEase";
import SvgPathEase from "./CustomEase/SvgPathEase";
import { XTween } from "./XTween";

// let oldUpdateActions = XTween.prototype._updateActions;
// XTween.prototype._updateActions = function updateActions(deltaTime: number): boolean {
//     if (this.target instanceof CCObject && !this.target.isValid) return true;
//     return oldUpdateActions.call(this, deltaTime);
// }

export enum TweenEase {
    linear,
    quadraticIn,
    quadraticOut,
    quadraticInOut,
    cubicIn,
    cubicOut,
    cubicInOut,
    quarticIn,
    quarticOut,
    quarticInOut,
    quinticIn,
    quinticOut,
    quinticInOut,
    sinusoidalIn,
    sinusoidalOut,
    sinusoidalInOut,
    exponentialIn,
    exponentialOut,
    exponentialInOut,
    circularIn,
    circularOut,
    circularInOut,
    elasticIn,
    elasticOut,
    elasticInOut,
    backIn,
    backOut,
    backInOut,
    bounceIn,
    bounceOut,
    bounceInOut,
    svgPath,
}

export function createEase(ease: TweenEase, customData?: string): EasingFunction {
    if (ease == TweenEase.svgPath)
        return SvgPathEase.create(customData);
    return XTween.Easing[TweenEase[ease]];
}

export class XTweenSystem extends System {
    static readonly ID = 'XTWEEN';
    update(dt: number) {
        XTween.updateTweens();
    }
}

// director.on(Director.EVENT_INIT, () => {
// cocos的取决于，在打playable后，此次不回调。
//     log("XTween Director.EVENT_INIT");
const xtweenSystem = new XTweenSystem();
director.registerSystem(XTweenSystem.ID, xtweenSystem, System.Priority.MEDIUM);
// });
// log("XTween Director.on");
