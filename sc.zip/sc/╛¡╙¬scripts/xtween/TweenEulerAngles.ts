import { Vec3, _decorator } from "cc";
import TweenComponent, { TweenWay } from "./TweenComponent";

const { ccclass, menu, property, executeInEditMode, playOnFocus } = _decorator;
@ccclass('TweenEulerAngles')
@menu("Tween/TweenEulerAngles")
@executeInEditMode
@playOnFocus
export class TweenEulerAngles extends TweenComponent {
    @property({ visible: function (this: TweenComponent) { return this.tweenWay == TweenWay.From || this.tweenWay == TweenWay.FromTo; } })
    readonly startEulerAngles: Vec3 = new Vec3(0, 0, 0);
    @property({ visible: function (this: TweenComponent) { return this.tweenWay != TweenWay.From; } })
    readonly endEulerAngles: Vec3 = new Vec3(0, 0, 0);

    protected createStartProperties(): Object {
        return { eulerAngles: this.startEulerAngles };
    }

    protected createEndProperties(): Object {
        return { eulerAngles: this.endEulerAngles };
    }
}