import { CCFloat, UIOpacity, UIRenderer, _decorator } from "cc";
import TweenComponent, { TweenWay } from "./TweenComponent";

const { ccclass, menu, property, executeInEditMode } = _decorator;
@ccclass('TweenAlpha')
@menu("Tween/TweenAlpha")
@executeInEditMode
export class TweenAlpha extends TweenComponent {
    @property({ type: CCFloat, min: 0, max: 1, slide: true, visible: function (this: TweenComponent) { return this.tweenWay == TweenWay.From || this.tweenWay == TweenWay.FromTo; } })
    readonly startAlpha: number = 0;
    @property({ type: CCFloat, min: 0, max: 1, slide: true, visible: function (this: TweenComponent) { return this.tweenWay != TweenWay.From; } })
    readonly endAlpha: number = 1;

    public get tweenTarget(): { alpha: number } {
        let uiRenderer = this.node.getComponent(UIRenderer);
        if (uiRenderer != null) return uiRenderer;
        let uiopacity = this.node.getOrAddComponent(UIOpacity);
        return uiopacity;
    }

    protected createStartProperties(): Object {
        return { alpha: this.startAlpha };
    }

    protected createEndProperties(): Object {
        return { alpha: this.endAlpha };
    }
}