import { _decorator, bezier, Component, Node, v3, Vec3 } from 'cc'
import { XTween } from './xtween/XTween'
const { ccclass, property } = _decorator

@ccclass('BezierMoney')
export class BezierMoney extends Component {

    start() {

    }

    PlayBezier(p1: Vec3, flytime: number,y:number) {
        // 三维空间的缓动
        const bezierCurve = (t: number, p1: Vec3, cp1: Vec3, cp2: Vec3, p2: Vec3, out: Vec3) => {
            out.x = bezier(p1.x, cp1.x, cp2.x, p2.x, t)
            out.y = bezier(p1.y, cp1.y, cp2.y, p2.y, t)
            out.z = bezier(p1.z, cp1.z, cp2.z, p2.z, t)
        }
        let ranx = Math.random() > 0.5 ? 1 : -1;
        let ranz = Math.random() > 0.5 ? 1 : -1;
        let rant = Math.random() > 0.5 ? 1 : -1;
        let xoffset = Math.random() * 2 * ranx;
        let zoffset = Math.random() * 2 * ranz;
        let toffset = Math.random() * flytime*0.5*rant;
        const startPos = this.node.getWorldPosition();
        startPos.x += xoffset*0.5;
        startPos.z += zoffset*0.5;
        const controlPos1 = v3(startPos.x + (p1.x - startPos.x) / 3, y>8?y+10:8, startPos.z + (p1.z - startPos.z) / 3)
        const controlPos2 = v3(startPos.x + (p1.x - startPos.x) / 2, 3, startPos.z + (p1.z - startPos.z) / 2)
        const endPos = p1;
        endPos.y=1
        const tempVec3 = v3()
        new XTween(this.node).to(flytime*1.5, { worldPosition: endPos }, {
            onUpdate: (target, ratio) => {
                bezierCurve(ratio, startPos, controlPos1, controlPos2, endPos, tempVec3)
                this.node.setWorldPosition(tempVec3)
            },
        }).call(() => {
            this.node.active = false;
        }).play();
        new XTween(this.node).to(flytime*1.5, { eulerAngles: v3(xoffset*360,zoffset*360,toffset*360) }).play();
        new XTween(this.node).to(flytime*1.5, { scale: v3(0.1,0.1,0.1) }).play();
    }
}