import { _decorator, Collider, Component, ICollisionEvent, ITriggerEvent } from 'cc';
import { IModelAnimationComponent } from './IModelAnimationComponent';
import { IMovementComponent } from './IMovementComponent';
import { IStateComponent } from './IStateComponent';
import { CharacterState } from './IIndex';
const { ccclass, property } = _decorator;

@ccclass('ICharacter')
export class ICharacter extends Component {

    @property({ type: IMovementComponent, displayName: '移动组件' })
    public movementComponent: IMovementComponent = null!;

    @property({ type: IModelAnimationComponent, displayName: '动画组件' })
    public animationComponent: IModelAnimationComponent = null!;

    @property({ type: IStateComponent, displayName: '状态组件' })
    public stateComponent: IStateComponent = null!;

    /** 碰撞器组件 */
    protected collider: Collider | null = null;

    onLoad() {
        this.setupStateCallbacks();
    }

    protected start(): void {
        this.initCollider();
        this.registerEvents();
    }

    /**
     * 设置状态回调
     */
    protected setupStateCallbacks() {
        this.stateComponent.setStateEnterCallback(CharacterState.Idle, this.onIdleEnter.bind(this));
        this.stateComponent.setStateUpdateCallback(CharacterState.Idle, this.onIdleUpdate.bind(this));

        this.stateComponent.setStateEnterCallback(CharacterState.Move, this.onMoveEnter.bind(this));
        this.stateComponent.setStateUpdateCallback(CharacterState.Move, this.onMoveUpdate.bind(this));
        this.stateComponent.setStateExitCallback(CharacterState.Move, this.onMoveExit.bind(this));
    }

    /**
     * 初始化碰撞器
     */
    protected initCollider() {
        this.collider = this.getComponent(Collider);
    }

    /**
     * 注册事件
     */
    protected registerEvents() {
        if (this.collider) {
            if (this.collider.isTrigger) {
                this.collider.on('onTriggerEnter', this.onTriggerEnter, this);
                this.collider.on('onTriggerExit', this.onTriggerExit, this);
                console.log('onTriggerEnter');
            }
            else {
                this.collider.on('onCollisionEnter', this.onCollisionEnter, this);
                this.collider.on('onCollisionExit', this.onCollisionExit, this);
            }
        }

        
    }


    /**
     * 注销事件
     */
    protected unregisterEvents() {
        if (this.collider) {
            if (this.collider.isTrigger) {
                this.collider.off('onTriggerEnter', this.onTriggerEnter, this);
                this.collider.off('onTriggerExit', this.onTriggerExit, this);
            }
            else {
                this.collider.off('onCollisionEnter', this.onCollisionEnter, this);
                this.collider.off('onCollisionExit', this.onCollisionExit, this);
            }
        }

        
    }

    /**
     * 空闲状态进入回调
     */
    protected onIdleEnter() {}

    /**
     * 空闲状态更新回调
     */
    protected onIdleUpdate(dt: number) {}

    /**
     * 移动状态进入回调
     */
    protected onMoveEnter() {}

    /**
     * 移动状态更新回调
     */
    protected onMoveUpdate(dt: number) {}

    /**
     * 移动状态退出回调
     */
    protected onMoveExit() {}

    /**
     * 移动状态改变回调
     */
    protected onMoveStateUpdate(isMoving: boolean) {}

    /**
     * 碰撞事件回调
     */
    protected onCollisionEnter(event: ICollisionEvent) {}
    protected onCollisionExit(event: ICollisionEvent) {}

    /**
     * 触发器事件回调
     */
    protected onTriggerEnter(event: ITriggerEvent) {}
    protected onTriggerExit(event: ITriggerEvent) {}


    onDestroy() {
        this.unregisterEvents();
    }
}


