/**
 * 游戏中使用的通用事件类型
 */
export enum CommonEvent{
    /** 相机移动事件 */
    CameraMove = 'camera-move',
    /** 摇杆输入事件 */
    joystickInput = 'joystick-input',
    /** 英雄移动事件 */
    HerMove = 'hero-move',
}

/**
 * 角色状态枚举
 */
export enum CharacterState {
    /** 空闲状态 */
    Idle = 'Idle',
    /** 移动状态 */
    Move = 'Move',
    /** 攻击状态 */
    Attack = 'Attack',
    /** 技能状态 */
    Skill = 'Skill',
    /** 死亡状态 */
    Dead = 'Dead'
}


