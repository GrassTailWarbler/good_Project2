import { _decorator, director, Vec3 } from 'cc';
import { ICharacter } from './ICharacter';
import { CharacterState, CommonEvent } from './IIndex';

const { ccclass, property } = _decorator;

@ccclass('IGirl')
export class IGirl extends ICharacter {
    onLoad() {
        super.onLoad();
    }

    /**
     * 空闲状态进入回调
     */
    protected onIdleEnter() {
        this.animationComponent.playIdle();
    }

    /**
     * 空闲状态更新回调
     */
    protected onIdleUpdate(dt: number) {
        // 子类可重写
        if (!this.animationComponent.isPlayingAnimation()) {
            this.animationComponent.playIdle();
        }

        if (this.movementComponent.isMoving) {
            this.stateComponent.changeState(CharacterState.Move);
        }
    }

    /**
     * 移动状态进入回调
     */
    protected onMoveEnter() {
        this.animationComponent.playMove();
    }

    /**
     * 移动状态更新回调
     */
    protected onMoveUpdate(dt: number) {
        // 子类可重写
        if (!this.animationComponent.isPlayingAnimation()) {
            this.animationComponent.playMove();
        }
    }

    /**
     * 移动状态退出回调
     */
    protected onMoveExit() {
        //console.log('move exit');
    }

    /**
     * 移动状态改变回调
     */
    protected onMoveStateUpdate(isMoving: boolean) {
        if (this.stateComponent.getCurrentState() === CharacterState.Dead) {
            return;
        }

        // Character基类中移动会打断攻击
        if (isMoving) {
            if (this.stateComponent.getCurrentState() != CharacterState.Move) {
                this.stateComponent.changeState(CharacterState.Move);
            }
        } else {
            if (this.stateComponent.getCurrentState() != CharacterState.Idle) {
                this.stateComponent.changeState(CharacterState.Idle);
            }
        }
    }

    /**
     * 移动角色
     * @param direction 移动方向
     */
    public move(direction: Vec3) {
        if (this.stateComponent.getCurrentState() === CharacterState.Dead) {
            return;
        }
        const hasInput = !Vec3.equals(direction, Vec3.ZERO);//摇杆有输入
        // 发送角色移动事件
        if (hasInput) {
            this.startMoving(direction);
        } else {
            this.stopMoving();
        }

        director.emit(CommonEvent.HerMove);
    }

    /* 开始移动 */
    public startMoving(direction: Vec3) {
        this.movementComponent.move(direction);
        this.onMoveStateUpdate(true);
    }

    /**
     * 停止移动
     */
    public stopMoving() {
        this.movementComponent.move(Vec3.ZERO);
        this.onMoveStateUpdate(false);
    }

    /**
     * 重置角色状态
     */
    public reset() {
        this.movementComponent.reset();
        this.stateComponent.reset();
        this.animationComponent.reset();
    }

    onDestroy() { }
}


