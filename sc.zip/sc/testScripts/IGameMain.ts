import { _decorator, Component, director, Node, Vec2, Vec3 } from 'cc';

import { IGirl } from './IGirl';
import { CommonEvent } from './IIndex';
const { ccclass, property } = _decorator;
const _tempVector3 = new Vec3();
const _tempVector2 = new Vec2();
@ccclass('IGameMain')
export class IGameMain extends Component {
    @property({
        type: IGirl,
        displayName: '英雄'
    })
    public hero: IGirl = null!;
    // 对应摄像头Y轴的旋转角度
    private rotationAngle: number = -35;

    protected onLoad(): void {
        director.on(CommonEvent.joystickInput, this.onJoystickInput, this);
    }
    private onJoystickInput(inputVector: Vec2): void {


        // 检查是否需要旋转向量
        let rotatedVector = _tempVector2.set(inputVector);//inputVector.clone();
        // 假设rotationAngle是类中的属性，单位为度，0表示不旋转
        if (this.rotationAngle && this.rotationAngle !== 0) {
            const angleRad = this.rotationAngle * Math.PI / 180; // 转换为弧度
            const cos = Math.cos(angleRad);
            const sin = Math.sin(angleRad);
            // 应用旋转公式
            const x = inputVector.x * cos - inputVector.y * sin;
            const y = inputVector.x * sin + inputVector.y * cos;
            rotatedVector.set(x, y);
        }

        // 将2D输入转换为3D移动方向，Y轴映射到Z轴
        const moveDirection = _tempVector3.set(rotatedVector.x, 0, -rotatedVector.y);//new Vec3(rotatedVector.x, 0, -rotatedVector.y);
        this.hero.move(moveDirection);
    }
}


