import { _decorator, CCBoolean, Component, director, Node, Vec3 } from 'cc';
import { CommonEvent } from './IIndex';

const { ccclass, property } = _decorator;

@ccclass('IMainCamera')
export class IMainCamera extends Component {

    @property(Node)
    offsetTargetNode: Node = null!;
    @property(CCBoolean)
    doNotFollow: boolean = false;

    private _cameraOffset: Vec3 = new Vec3();
    private _targetPos: Vec3 = new Vec3();
    onLoad() {
        director.on(CommonEvent.HerMove, this.onHeroMove, this);
        // 相机偏移
        this._cameraOffset = this.node.getWorldPosition().subtract(this.offsetTargetNode.getWorldPosition());
    }

    onDestroy() {
        director.off(CommonEvent.HerMove, this.onHeroMove, this);
    }

    private onHeroMove() {
        if (this.doNotFollow) return;
        this._targetPos.set(this.offsetTargetNode.worldPosition);
        let cameraPos = this._targetPos.add(this._cameraOffset);
        this.node.setWorldPosition(cameraPos);
    }

}


