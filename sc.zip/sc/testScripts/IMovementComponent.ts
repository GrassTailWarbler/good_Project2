import { _decorator, CCFloat, Collider, Component, game, RigidBody, Vec3, Node } from 'cc';
import { IRotation3DUtils } from './IRotation3DUtils';

const { ccclass, property } = _decorator;

@ccclass('IMovementComponent')
export class IMovementComponent extends Component {
    @property({
        type: CCFloat,
        displayName: '移动速度',
        range: [0, 20],
        tooltip: '角色的基础移动速度'
    })
    protected moveSpeed: number = 5;

    @property({
        type: CCFloat,
        displayName: '朝向平滑度',
        range: [0.1, 10.0],
        tooltip: '3D朝向旋转的平滑度,值越大旋转越快'
    })
    protected rotationSmoothness: number = 0.1;

    @property({ type: Node, displayName: '模型节点', tooltip: '需要控制颜色的模型节点' })
    protected modelNode: Node = null!;


    /** 移动时是否保持朝向 */
    protected isKeepFace: boolean = true;
    /** 移动方向 */
    protected readonly direction: Vec3 = new Vec3();
    /** 临时向量，用于存储位置 */
    private readonly currentPos: Vec3 = new Vec3();
    /* 临时向量，用于存储位移量 */
    private readonly displacement: Vec3 = new Vec3();
    /** 刚体组件 */
    protected rigidBody: RigidBody | null = null;




    onLoad() {
        this.initRigidBody();
        this.registerEvents();
    }

    onDestroy() {
        this.unregisterEvents();
    }

    /**
     * 注册事件监听
     */
    private registerEvents() {

    }

    /**
     * 注销事件监听
     */
    private unregisterEvents() {

    }


    /**
     * 获取刚体组件
     */
    public getRigidBody(): RigidBody | null {
        return this.rigidBody;
    }

    /**
     * 初始化刚体组件
     */
    protected initRigidBody() {
        this.rigidBody = this.getComponent(RigidBody);
    }

    update(dt: number) {
        this.updatePosition(dt);
    }

    /**
     * 根据当前方向和速度更新位置
     * @param dt 帧间隔时间
     */
    protected updatePosition(dt: number) {

        const isMoving = !Vec3.equals(this.direction, Vec3.ZERO);

        if (!isMoving) return;

        // 计算速度系数
        let speedMultiplier = 1.0;


        // 计算位移量 - 不改变Y轴方向，让物理系统控制
        this.displacement.set(
            this.direction.x * this.moveSpeed * dt * speedMultiplier,
            0, // Y轴位移设为0，让物理系统控制
            this.direction.z * this.moveSpeed * dt * speedMultiplier
        );

        // 获取当前位置
        this.node.getPosition(this.currentPos);

        // 保存原来的Y值
        const originalY = this.currentPos.y;

        // 更新位置
        Vec3.add(this.currentPos, this.currentPos, this.displacement);

        // 恢复Y值，让物理系统控制Y轴
        this.currentPos.y = originalY;

        this.node.setPosition(this.currentPos);
    }

    /**
     * 根据3D方向向量更新朝向
     */
    public updateFaceDirectionFrom3D(direction: Vec3, rotationSmoothness: number = -1) {
        if (Vec3.equals(direction, Vec3.ZERO)) return;

        // 使用3D旋转工具类来处理朝向，传入当前的帧时间
        const deltaTime = game.deltaTime;
        const horizontalDirection = IRotation3DUtils.toHorizontalDirection(direction);
        IRotation3DUtils.faceDirection(
            this.modelNode,
            horizontalDirection,
            rotationSmoothness > 0 ? rotationSmoothness : this.rotationSmoothness,
            deltaTime
        );

    }


    /* 设置刚体组件启用状态 */
    public setRigidBodyEnabled(enabled: boolean) {
        if (this.rigidBody) {
            this.rigidBody.enabled = enabled;
        }

        this.node.getComponents(Collider).forEach(collider => {
            collider.enabled = enabled;
        });
    }

    /**
     * 移动角色
     * @param direction 移动方向
     */
    public move(direction: Vec3 = Vec3.ZERO) {
        this.direction.set(direction);
        // 更新朝向
        if (this.isKeepFace) {
            // 使用3D方向向量更新朝向
            this.updateFaceDirectionFrom3D(direction);
        }
    }


    /**
     * 重置组件状态
     */
    public reset() {
        this.direction.set(Vec3.ZERO);
        this.setRigidBodyEnabled(true);
    }

    /**
     * 获取当前移动方向
     */
    public getDirection(): Vec3 {
        return this.direction;
    }

    /**
     * 是否正在移动
     */
    public get isMoving(): boolean {
        return !Vec3.equals(this.direction, Vec3.ZERO);
    }

    /**
     * 获取当前移动速度
     */
    public get speed(): number {
        return this.moveSpeed;
    }

    /**
     * 设置移动速度
     */
    public set speed(value: number) {
        this.moveSpeed = value;
    }

    /* 设置是否保持朝向 */
    set IsKeepFace(value: boolean) {
        this.isKeepFace = value;
    }
    /* 获取是否保持朝向 */
    get IsKeepFace(): boolean {
        return this.isKeepFace;
    }
}

