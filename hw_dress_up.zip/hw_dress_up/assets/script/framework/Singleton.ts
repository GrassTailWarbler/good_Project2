/***
 * 泛型单例模式接口
 */

import { _decorator } from 'cc';
export default class Singleton {
    private static _instance: any = null

    protected static getInstance<T>(): T {
        if (this._instance === null) {
            this._instance = new this();
        }
        return this._instance;
    }
}


/**
 * 注意：已把原脚本注释，由于脚本变动过大，转换的时候可能有遗落，需要自行手动转换
 */
// /***
//  * 泛型单例模式接口
//  */
// 
//  export default class Singleton {
//     private static _instance: any = null
//   
//     static getInstance<T>(): T {
//       if (this._instance === null) {
//         this._instance = new this();
//       }
//       return this._instance;
//     }
//   }
