// // Learn TypeScript:
// //  - https://docs.cocos.com/creator/manual/en/scripting/typescript.html
// // Learn Attribute:
// //  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// // Learn life-cycle callbacks:
// //  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html

import { _decorator } from 'cc';
const { ccclass, property } = _decorator;

import Singleton from "./Singleton";
interface IItem {
      func: Function;
      ctx: unknown;
}
/***
* 事件中心管理类（本质就是一张map，key是事件名称，value是对应事件的函数列表）
 */

@ccclass('EventManager')
export class EventManager extends Singleton {
      static get instance() {
            return super.getInstance<EventManager>();
      }
      eventDic: Map<string, Array<IItem>> = new Map();
      on(event: string, func: Function, ctx?: unknown) {
            if (this.eventDic.has(event)) {
                  this.eventDic.get(event).push({ func, ctx });
            } else {
                  this.eventDic.set(event, [{ func, ctx }]);
            }
      }
      off(event: string, func: Function) {
            if (this.eventDic.has(event)) {
                  const index = this.eventDic.get(event).findIndex(i => func === i.func);
                  index > -1 && this.eventDic.get(event).splice(index, 1);
            }
      }
      emit(event: string, ...params: unknown[]) {
            if (this.eventDic.has(event)) {
                  this.eventDic.get(event).forEach(({ func, ctx }) => {
                        ctx ? func.apply(ctx, params) : func(...params);
                  });
            }
      }
      clear() {
            this.eventDic.clear();
      }

      /**
   * 事件只触发一次，然后自动注销
   * @param event 事件名称
   * @param func 回调函数
   * @param ctx 回调函数的上下文
   */
      once(event: string, func: Function, ctx?: unknown) {
            const onceFunc = (...params: unknown[]) => {
                  func.apply(ctx, params);
                  this.off(event, onceFunc);
            };
            this.on(event, onceFunc, ctx);
      }
}


/**
 * 注意：已把原脚本注释，由于脚本变动过大，转换的时候可能有遗落，需要自行手动转换
 */
// // Learn TypeScript:
// //  - https://docs.cocos.com/creator/manual/en/scripting/typescript.html
// // Learn Attribute:
// //  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// // Learn life-cycle callbacks:
// //  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
// 
// import Singleton from "./Singleton";
// 
// const {ccclass, property} = cc._decorator;
// 
// 
// interface IItem {
//   func: Function;
//   ctx: unknown;
// }
// 
// /***
//  * 事件中心管理类（本质就是一张map，key是事件名称，value是对应事件的函数列表）
//  */
//  @ccclass
// export default class EventManager extends Singleton {
//   static get instance() {
//     return super.getInstance<EventManager>();
//   }
// 
//   eventDic: Map<string, Array<IItem>> = new Map();
// 
//   on(event: string, func: Function, ctx?: unknown) {
//     if (this.eventDic.has(event)) {
//       this.eventDic.get(event).push({ func, ctx });
//     } else {
//       this.eventDic.set(event, [{ func, ctx }]);
//     }
//   }
// 
//   off(event: string, func: Function) {
//     if (this.eventDic.has(event)) {
//       const index = this.eventDic.get(event).findIndex(i => func === i.func);
//       index > -1 && this.eventDic.get(event).splice(index, 1);
//     }
//   }
// 
//   emit(event: string, ...params: unknown[]) {
//     if (this.eventDic.has(event)) {
//       this.eventDic.get(event).forEach(({ func, ctx }) => {
//         ctx ? func.apply(ctx, params) : func(...params);
//       });
//     }
//   }
// 
//   clear() {
//     this.eventDic.clear();
//   }
// }
