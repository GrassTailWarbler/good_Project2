import { _decorator } from 'cc';
import { ItemBase } from "../item/ItemBase";
import { Item, ItemName } from '../api/GameInterface';
import { ItemManager } from './ItemManager';
import { SceneManager } from '../SceneManager';
import { HatItem } from '../itemCom/HatItem';
import { BagItem } from '../itemCom/BagItem';
import { BookItem } from '../itemCom/BookItem';
import { BoxItem } from '../itemCom/BoxItem';
import { PumpkinItem } from '../itemCom/PumpkinItem';
import { ClothRedItem } from '../itemCom/ClothRedItem';
import { ClothPurpleItem } from '../itemCom/ClothPurpleItem';
import { BroomItem } from '../itemCom/BroomItem';

const { ccclass } = _decorator;

@ccclass('ItemFactory')
export class ItemFactory {

    public static AllItemNodeAddCom() {
        ItemManager.instance.itemArray.forEach((_value: Item) => {
            this._switchMainFn(_value.itemName).init(_value);
        })
    }

    private static _addComponent<T extends ItemBase>(_itemName: ItemName, _class: { prototype: T; } & { new(): T }) {
        //找到名字相同的第一个元素节点
        const itemNode = SceneManager.instance.itemNodeArray.find((itemNd) => itemNd.name === _itemName);
        //初始化
        return itemNode.addComponent(_class);
    }

    private static _switchMainFn(_itemName: ItemName, isAddCom?: boolean, isRender?: boolean): ItemBase {

        let itemCom: ItemBase = null;

        switch (_itemName) {
            case ItemName.HAT:
                itemCom = this._addComponent(_itemName, HatItem);
                break;
            case ItemName.BAG:
                itemCom = this._addComponent(_itemName, BagItem);
                break;
            case ItemName.BOOK:
                itemCom = this._addComponent(_itemName, BookItem);
                break;
            case ItemName.BOX:
                itemCom = this._addComponent(_itemName, BoxItem);
                break;
            case ItemName.PUMPKIN:
                itemCom = this._addComponent(_itemName, PumpkinItem);
                break;
            case ItemName.CLOTH_RED:
                itemCom = this._addComponent(_itemName, ClothRedItem);
                break;
            case ItemName.CLOTH_PURPLE:
                itemCom = this._addComponent(_itemName, ClothPurpleItem);
                break;
            case ItemName.BROOM:
                itemCom = this._addComponent(_itemName, BroomItem);
                break;
            default:
                const _error: never = _itemName;
                break;
        }

        return itemCom;
    }
}
