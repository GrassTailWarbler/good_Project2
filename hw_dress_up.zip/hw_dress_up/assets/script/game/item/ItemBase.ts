
import { _decorator, Component, NodeEventType } from 'cc';
const { ccclass, property } = _decorator;

import { EventManager } from "../../framework/EventManager";
import { Item, ItemGroup, ItemName } from '../api/GameInterface';


@ccclass('ItemBase')
export class ItemBase extends Component {
    protected _itemName: ItemName;
    protected _itemTexture: string;
    protected _itemNumber: number;
    protected _itemInBag: boolean;
    protected _itemGroup: ItemGroup;
    //protected _IItemGObjGObj: fgui.GObject;
    onLoad() {
        //        //EventManager.instance.on('render', this.render, this);//注册了但没用上可以删除
    }
    onDestroy() {
        //        //EventManager.instance.off('render', this.render);
    }
    init(_IItemGObj: Item) {
        this._itemName = _IItemGObj.itemName;
        this._itemTexture = _IItemGObj.itemTexture;
        this._itemNumber = _IItemGObj.itemNumber;
        this._itemInBag = _IItemGObj.itemInBag;

        this.node.on(NodeEventType.TOUCH_START, this._click, this);

    }
    protected _textTip(_other?: string) {
        EventManager.instance.emit('renderText', this._itemName, _other);
    }
    protected _itemDragInBag() {
        /* const bagItems = this._IItemGObjGObj;
        bagItems.draggable = true;
        bagItems.on(fgui.Event.DRAG_START, this.__onDragStart, this);
        bagItems.on(fgui.Event.DROP, this._onDrop, this);
        bagItems.onClick(this._textTip, this); */
    }
    public render() {
        /*   (this._IItemGObjGObj as fgui.GButton).icon = this._itemTexture;
          (this._IItemGObjGObj as fgui.GButton).title = this._itemName; */
    }
    protected _click() {
        //EventManager.instance.emit('viewItemToBag', this._itemName)
        EventManager.instance.emit('stopClickTween')
        this._textTip();

    }
    protected __onDragStart(evt: any): void {
        /*  const btn: fgui.GObject = fgui.GObject.cast(evt.currentTarget);
         btn.stopDrag();//取消对原目标的拖动，换成一个替代
         fgui.DragDropManager.inst.startDrag(btn, btn.icon, btn); */
    }
    protected _onDrop(target: any, data: any): void {
        /* if (data.title === target.title) return;//同一个物体不能合成
        EventManager.instance.emit('combinations', target.title, data.title) */
    }
}


/**
 * 注意：已把原脚本注释，由于脚本变动过大，转换的时候可能有遗落，需要自行手动转换
 */
// // Learn TypeScript:
// //  - https://docs.cocos.com/creator/manual/en/scripting/typescript.html
// // Learn Attribute:
// //  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// // Learn life-cycle callbacks:
// //  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
//
// import EventManager from "../../framework/EventManager";
// import { Item, ItemGroup, ItemName } from "../../index/Index";
//
// const { ccclass, property } = cc._decorator;
//
// @ccclass
// export default class ItemBase extends cc.Component {
//     protected _itemName: ItemName;
//     protected _itemTexture: string;
//     protected _itemNumber: number;
//     protected _itemInBag: boolean;
//     protected _itemGroup: ItemGroup;
//     protected _IItemGObjGObj: fairygui.GObject = null;
//
//     onLoad() {
//         //EventManager.instance.on('render', this.render, this);//注册了但没用上可以删除
//     }
//
//     onDestroy() {
//         //EventManager.instance.off('render', this.render);
//     }
//
//     init(_IItemGObj: Item) {
//         this._itemName = _IItemGObj.itemName;
//         this._itemTexture = _IItemGObj.itemTexture;
//         this._itemNumber = _IItemGObj.itemNumber;
//         this._itemInBag = _IItemGObj.itemInBag;
//         this._IItemGObjGObj = fgui.GObject.cast(this.node);
//         this._itemInBag ? this._itemDragInBag() : this._IItemGObjGObj.onceClick(this._click, this);
//     }
//
//     protected _textTip(_other?:string) {
//         EventManager.instance.emit('textTip', this._itemName,_other);
//     }
//
//     protected _itemDragInBag() {
//         const bagItems = this._IItemGObjGObj.asButton;
//         bagItems.draggable = true;
//         bagItems.on(fgui.Event.DRAG_START, this.__onDragStart, this);
//         bagItems.on(fgui.Event.DROP, this._onDrop, this);
//         bagItems.onClick(this._textTip, this);
//     }
//
//     public render() {
//         this._IItemGObjGObj.asButton.icon = this._itemTexture;
//         this._IItemGObjGObj.asButton.title = this._itemName;
//     }
//
//     protected _click() {
//         EventManager.instance.emit('viewItemToBag', this._itemName)
//         this._textTip();
//     }
//
//     protected __onDragStart(evt: fgui.Event): void {
//         const btn: fgui.GObject = fgui.GObject.cast(evt.currentTarget);
//         btn.stopDrag();//取消对原目标的拖动，换成一个替代
//         fgui.DragDropManager.inst.startDrag(btn, btn.icon, btn);
//     }
//
//     protected _onDrop(target: fgui.GButton, data: fgui.GButton): void {
//         if (data.title === target.title) return;//同一个物体不能合成
//         EventManager.instance.emit('combinations', target.title, data.title)
//     }
//
// }
