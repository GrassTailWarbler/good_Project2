import { _decorator } from 'cc';
import { Item, ItemName } from '../api/GameInterface';

class Base implements Item {
    itemName: ItemName;
    itemNumber: number;
    itemTexture: string;
    itemInBag: boolean;
    constructor(_itemData: Item) {
        this.itemName = _itemData.itemName;
        this.itemNumber = _itemData.itemNumber;
        this.itemTexture = _itemData.itemTexture;
        this.itemInBag = _itemData.itemInBag;
    }
}

export class Hat extends Base { }
export class Bag extends Base { }
export class Book extends Base { }
export class Box extends Base { }
export class Broom extends Base { }
export class ClothPurple extends Base { }
export class ClothRed extends Base { }
export class Pumpkin extends Base { }




