import { _decorator } from 'cc';
import Singleton from "../../framework/Singleton";
import { Item, ItemName } from '../api/GameInterface';
const { ccclass, property } = _decorator;

@ccclass('ItemManager')
export class ItemManager extends Singleton {
    static get instance() {
        return super.getInstance<ItemManager>();
    }
    private _itemArray: Item[] = []
    public get itemArray() {
        return this._itemArray;
    }

    public AddItem(item: Item): void {
        this._itemArray.push(item);
    }
    /**
     * 根据名字找到符合的第一个元素并从数组里删除
     * @param itemName 
     * @returns item
     */
    public SpliceItem(itemName: ItemName): Item {
        let item: Item = null;
        let index = this._itemArray.findIndex((_item) => _item.itemName === itemName);
        if (index > -1) {
            item = this._itemArray.splice(index, 1)[0];
        }
        return item;
    }

}

