import { Item, ItemName } from "../api/GameInterface"

const HATDataConfig: Item = {
    itemName: ItemName.HAT,
    itemTexture: 'ui://wamg48sbnlxs4',//fgui.UIPackage.getItemURL("SceneGame", 'bottle'),
    itemNumber: 0,
    itemInBag: false,
}

const BoxDataConfig: Item = {
    itemName: ItemName.BOX,
    itemTexture: 'ui://wamg48sbnlxs4',//fgui.UIPackage.getItemURL("SceneGame", 'bottle'),
    itemNumber: 0,
    itemInBag: false,
}

const BagDataConfig: Item = {
    itemName: ItemName.BAG,
    itemTexture: 'ui://wamg48sbnlxs4',//fgui.UIPackage.getItemURL("SceneGame", 'bottle'),
    itemNumber: 0,
    itemInBag: false,
}


const BookDataConfig: Item = {
    itemName: ItemName.BOOK,
    itemTexture: 'ui://wamg48sbnlxs4',//fgui.UIPackage.getItemURL("SceneGame", 'bottle'),
    itemNumber: 0,
    itemInBag: false,
}

const BroomDataConfig: Item = {
    itemName: ItemName.BROOM,
    itemTexture: 'ui://wamg48sbnlxs4',//fgui.UIPackage.getItemURL("SceneGame", 'bottle'),
    itemNumber: 0,
    itemInBag: false,
}


const ClothRedDataConfig: Item = {
    itemName: ItemName.CLOTH_RED,
    itemTexture: 'ui://wamg48sbnlxs4',//fgui.UIPackage.getItemURL("SceneGame", 'bottle'),
    itemNumber: 0,
    itemInBag: false,
}

const ClothPurpleDataConfig: Item = {
    itemName: ItemName.CLOTH_PURPLE,
    itemTexture: 'ui://wamg48sbnlxs4',//fgui.UIPackage.getItemURL("SceneGame", 'bottle'),
    itemNumber: 0,
    itemInBag: false,
}

const PumpkinDataConfig: Item = {
    itemName: ItemName.PUMPKIN,
    itemTexture: 'ui://wamg48sbnlxs4',//fgui.UIPackage.getItemURL("SceneGame", 'bottle'),
    itemNumber: 0,
    itemInBag: false,
}


export const IData = {
    'hat': HATDataConfig,
    'box': BoxDataConfig,
    'bag': BagDataConfig,
    'book': BookDataConfig,
    'broom': BroomDataConfig,
    'clothRed': ClothRedDataConfig,
    'clothPurple': ClothPurpleDataConfig,
    'pumpkin': PumpkinDataConfig,

}
export const combinationsGroupIndex = {
    'bottle': 0,
    'bone': 1,
    'letter': 0,
    'shovel': 0,
    'card': 0,
    'stone': 1,
    'bone_needle': 0,
    'sour_bottle': 0,
    'honey': 2,
    'bell': 0,
    'key': 0,
    'glasses': 0,
    'cullet': 2,
    'cullet_honey': 0,
}

export const textClickTip = {
    'hat': { default: '这是帽子......' },
    'box': { default: '这是箱子......' },
    'bag':{ default: '这是背包......' },
    'book':{ default: '这是书......' },
    'broom':{ default: '这是扫把......' },
    'clothRed': { default: '这是红衣......' },
    'clothPurple': { default: '这是紫衣......' },
    'pumpkin': { default: '这是南瓜......' },
    'bottle': {
        default: '这是一个空瓶子'
    },
    'bone': { default: '爱丽丝的骨头......' },
    'letter': { default: '杀死兔子？' },
    'door': { default: '一扇蓝色的门' },
    'hair': {
        default: '就看一次吧,爱丽丝不想让你看到的',
        hair: '不要再打扰她了,爱丽丝再也不会微笑了...'
    },
    'shovel': { default: '一个铲子' },
    'card': { default: '残缺的扑克牌,或许有什么用处' },
    'stone': { default: '又黑又硬' },
    'bone_needle': { default: '尖锐的,可以刺进某些孔里？' },
    //'box': { default: '好大的箱子，里面发出些声音' },
    'keyhole': {
        default: '好像能通往哪里?但是锁住了',
        bottle: '玻璃弄到门孔里?你在想什么啊?',
        bone: '打磨一下 说不定能行',
        letter: '你是否清醒?',
        shovel: '太粗了',
        stone: '你是否清醒?',
        card: '你是否清醒?',
        bone_needle: '好像打开了什么!',
    },
    'stump': { default: '一个树桩,上面有冒气泡的液体' },
    'sour_bottle': { default: '硫酸瓶里装硫酸' },
    'suitcase': { default: '一个手提箱' },
    'wooden_hole': {
        default: '先开门还是先刷卡,这是个问题',
        key: '还差点就能打开了',
    },
    'pos_machine': {
        default: '刷卡机,或许要门禁卡？',
        card: '阿里巴巴,芝麻开门!',
        pos_machine: '先开门还是先刷卡,这是个问题',
    },
    'web': {
        default: '一张大网拦住了',
        letter: '你是否清醒?',
        card: '你是否清醒?',
        key: '你是否清醒?',
        bell: '你是否清醒?',

    },
    'bug': { default: '蓝色的虫子,它身上有什么东西' },
    'honey': {
        default: '蜂蜜,但怎么取下它呢?',
        honey: '黏糊糊的,很浓稠但不伤手'

    },
    'bell': { default: '铃铛,不知道有什么用' },
    'key': { default: '一个钥匙' },
    'glasses': { default: '神秘的眼镜,可以用来查看隐藏的东西吧' },
    'cullet': { default: '碎玻璃渣' },
    'cullet_honey': { default: '击杀虫子吧' },
    'dead_bug': { default: '可怜的虫子' },
    'mask': { default: '箱子里面传出了鸟叫声,但是打不开这个箱子' },
}
