import { _decorator, Component, Node } from 'cc';
const { ccclass, property } = _decorator;

@ccclass('GameConst')
export class GameConst {
    public static GAME_EVENT_NAME = {

    }
}


