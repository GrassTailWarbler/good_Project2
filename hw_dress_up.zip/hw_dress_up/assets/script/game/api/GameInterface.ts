export enum ItemName {
    BAG = 'bag',
    BOOK = 'book',
    BOX = 'box',
    PUMPKIN = 'pumpkin',
    CLOTH_RED = 'clothRed',
    CLOTH_PURPLE = 'clothPurple',
    HAT = 'hat',
    BROOM = 'broom'
}

export enum ItemGroup {
    NONE,
    BONE_NEEDLE,
    CULLET_HONEY
}

export interface Item {
    itemName: ItemName;
    itemNumber: number;
    itemTexture: string;
    itemInBag: boolean;
}

export type dict = Map<string, Array<Item>>
export interface IData {
    viewItemData: Map<string, dict>;
    bagItemData: Array<Item>
}

interface SceneName {
    s1: 's1',
    s2: 's2'
}

export type SceneNameType = keyof SceneName;


