import { _decorator, Component, Node } from 'cc';
import Singleton from '../framework/Singleton';
const { ccclass, property } = _decorator;

@ccclass('SceneManager')
export class SceneManager extends Singleton {
    static get instance() {
        return super.getInstance<SceneManager>();
    }

    private _currentScene: Node = null;
    public get currentScene() { return this._currentScene };
    public set currentScene(_s: Node) {
        this.currentScene = _s;
    }

    private _itemNodeArray: Node[] = [];
    public get itemNodeArray() { return this._itemNodeArray };
    public set itemNodeArray(_s: Node[]) {
        this._itemNodeArray = _s;
    }
}


