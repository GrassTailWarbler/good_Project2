import { _decorator, Component, Node, Sprite, SpriteFrame, tween, v2, v3 } from 'cc';
const { ccclass, property } = _decorator;

const MONTHS = {"happy":"happy", "sad":"sad", "astonished":"astonished"};

const LEFTLEGPOS = {
    LEFT_POS1: v3(-40.639,-241.045,0),
    LEFT_POS2: v3(-15.143,-241.045,0)
}
@ccclass('GirlDecorate')
export class GirlDecorate extends Component {
    
    @property(Node)
    closeEye:Node = null;

    @property(Node)
    faceNode:Node;
    @property(SpriteFrame)
    astonishedFace:SpriteFrame;

    @property(SpriteFrame)
    normalFace:SpriteFrame;

    @property(SpriteFrame)
    happyFace:SpriteFrame;

    @property(Node)
    clothNode:Node;

    @property(Node)
    monthNode:Node;

    @property(Node)
    rightLeg:Node;

    @property(Node)
    leftHandUp:Node;

    @property(Node)
    leftHandDown:Node;

    @property(Node)
    leftHandDecorate:Node;

    @property(Node)
    rightHandDecorate:Node;
    start() {

    }

    public doHandUp() {
        this.leftHandUp.active = true;
        this.leftHandDown.active = false;
    }

    public doHandDown() {
        this.leftHandDown.active = true;
        this.leftHandUp.active = false;
    }

    public doAstonishedFace() {
        for(let i = 0; i < this.monthNode.children.length; i++) {
            let month = this.monthNode.children[i];
            month.active = false;
        }
        this.monthNode.getChildByName(MONTHS.astonished).active = true;
    }

    public doNormalFace() {
        for(let i = 0; i < this.monthNode.children.length; i++) {
            let month = this.monthNode.children[i];
            month.active = false;
        }
        this.monthNode.getChildByName(MONTHS.happy).active = true;
    }

    public doSadFace() {
        for(let i = 0; i < this.monthNode.children.length; i++) {
            let month = this.monthNode.children[i];
            month.active = false;
        }
        this.monthNode.getChildByName(MONTHS.sad).active = true;
    }

    public DressClothByIndex(index:number) {
        let cloth = this.findCloseByIndex(index);
        if(cloth) {
            for(let i = 0; i < this.clothNode.children.length; i++) {
                let child = this.clothNode.children[i];
                child.active = false;
            }
            cloth.active = true;

            if(index == 2) {
                this.rightHandDecorate.active = true;
                this.leftHandDecorate.active = true;
                this.rightLeg.setPosition(LEFTLEGPOS.LEFT_POS2);
                this.doHandUp();
            } 
            else {
                this.rightHandDecorate.active = false;
                this.leftHandDecorate.active = false;
                this.rightLeg.setPosition(LEFTLEGPOS.LEFT_POS1);
            }
        } else {
            console.log("========= 穿入的参数不对");
        }
    }

    private findCloseByIndex(index:number) {
        let name = "actor_cloth_" + index;
        let cloth = this.clothNode.getChildByName(name);
        if(cloth) {
            return cloth;
        } else {
            return null;
        }
    }

    public doBlink(times:number, gapTime:number, betweenTime:number):void{
        tween(this.node).repeat(times,tween(this.node).delay(betweenTime).call(()=>{
            this.closeEye.active = true;
        }).delay(gapTime).call(()=>{
            this.closeEye.active = false;
        })).call(()=>{
            this.closeEye.active=  false;
        }).start();
    }

    update(deltaTime: number) {
        
    }


}


