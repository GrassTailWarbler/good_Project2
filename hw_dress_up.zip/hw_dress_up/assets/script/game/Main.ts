import { _decorator, Component, Node, view } from 'cc';
import * as ItemSet from './item/ItemSet';
import { IData } from './data/GameData';
import { SceneManager } from './SceneManager';
import { ItemManager } from './item/ItemManager';
import { ItemFactory } from './item/ItemFactory';
import { TextManager } from './TextManager';
import { Util } from '../framework/Util';
import { TouchManager } from './TouchManager';
import { GuidController } from './GuidController';
const { ccclass, property } = _decorator;

@ccclass('Main')
export class Main extends Component {

    @property({ type: [Node], tooltip: '物品节点' })
    itemNdArray: Node[] = [];

    @property({ type: Node, tooltip: '女主对话框' })
    girlTextTip: Node = null;

    @property(Node)
    touchNode: Node = null;

    private clearGuid = false;

    start() {

        //创建物品的数据
        this.createItemByData();
        console.log(ItemManager.instance.itemArray)
        //给物品节点挂载脚本
        SceneManager.instance.itemNodeArray = this.itemNdArray;
        ItemFactory.AllItemNodeAddCom();
        //引用对话框
        TextManager.instance.content = this.girlTextTip;
        //竖屏开启节点滑动
        this.touchNode.active = false;
        let orientation = Util.getOrientation();
        if (orientation === 'portrait') {
            this.touchNode.active = true;
            this.touchNode.addComponent(TouchManager);
            GuidController.instance.startGuid();
        }else {
            GuidController.instance.stopGuid();
        }

    }

    createItemByData() {
        let hat = new ItemSet.Hat(IData.hat);
        let clothPurple = new ItemSet.ClothPurple(IData.clothPurple);
        let clothRed = new ItemSet.ClothRed(IData.clothRed);
        let box = new ItemSet.Box(IData.box);
        let broom = new ItemSet.Broom(IData.broom);
        let pumpkin = new ItemSet.Pumpkin(IData.pumpkin);
        let book = new ItemSet.Book(IData.book);
        let bag = new ItemSet.Bag(IData.bag);
        let itemArray = [hat, clothPurple, clothRed, box, broom, pumpkin, book, bag];
        ItemManager.instance.itemArray.push(...itemArray);
    }

    protected update(dt: number): void {
        const size = view.getVisibleSize();
        if (size.width > size.height) {
            if (!this.clearGuid) {
                GuidController.instance.stopGuid();
                this.clearGuid = true;
            }

        }
    }


}


