import { _decorator, Component, Node, Tween, tween, v3, Vec3, view } from 'cc';
import { EventManager } from '../framework/EventManager';
const { ccclass, property } = _decorator;

@ccclass('GuidController')
export class GuidController extends Component {

    private static _instance: GuidController = null;
    public static get instance() { return this._instance; };


    @property(Node)
    camera: Node = null;

    @property(Node)
    actorBoy: Node = null;

    @property(Node)
    actorGirl: Node = null;

    @property(Node)
    tip: Node = null;

    @property(Node)
    mask: Node = null;

    protected onLoad(): void {
        if (!GuidController._instance) {
            GuidController._instance = this;
        } else {
            this.destroy();
        }
        EventManager.instance.once('stopClickTween', this.stopClickTween, this)
    }


    startGuid() {
        let width = view.getVisibleSize().width / 2;

        //镜头右移
        let pos0 = v3(width, 0, 1000).add(this.camera.position);
        let pos1 = v3(-width, 0, 1000).add(pos0);
        pos1.z = 1000;
        let t_rh = tween(this.camera).to(1, { position: pos0 });
        let t_lh = tween(this.camera).to(1, { position: pos1 });

        //boy action
        let delay0 = tween(this.camera).delay(3.0);
        let callBoyAction = tween(this.camera).call(() => { this.boyAction() });

        let parallel0 = tween(this.camera).parallel(delay0, callBoyAction);

        //镜头左移
        let pos2 = v3(-width, 0, 1000).add(this.camera.position);
        let pos3 = v3(width, 0, 1000).add(pos2);
        pos3.z = 1000;
        let tt_rh = tween(this.camera).to(1, { position: pos2 });
        let tt_lh = tween(this.camera).to(1, { position: pos3 });

        let delay1 = tween(this.camera).delay(1.0);


        //girl action
        let delay2 = tween(this.camera).delay(1.0);
        let callGirlAction = tween(this.camera).call(() => { this.girlAction() });

        let parallel1 = tween(this.camera).parallel(delay2, callGirlAction);

        let callClick = tween(this.camera).call(() => {
            this.clickItemTip();

        });

        tween(this.camera).sequence(t_rh, parallel0, t_lh, delay1, tt_rh, parallel1, tt_lh, callClick).start();

    }

    boyAction() {
        let hand = this.actorBoy.getChildByName('hand');
        let speak = this.actorBoy.getChildByName('speak');
        speak.active = true;
        //敲门
        let t_rh = tween(hand).to(0.5, { eulerAngles: v3(0, 0, 10) });
        let t_lh = tween(hand).to(0.5, { eulerAngles: v3(0, 0, 0) });
        //说话
        let t_s_show = tween(speak).show();
        let delay = tween(speak).delay(1.0);
        let t_s_hide = tween(speak).hide();
        tween(hand).sequence(t_rh, t_lh).repeat(3).start();
        tween(speak).sequence(t_s_show, delay, t_s_hide).start();
    }

    girlAction() {
        let speak = this.actorGirl.getChildByName('speak');
        speak.active = true;
        let t_s_show = tween(speak).show();
        tween(speak).sequence(t_s_show).start();
    }

    clickItemTip() {
        this.tip.active = true;
        let hand = this.tip.getChildByName('hand');
        //hand.active = true;
        let circle = this.tip.getChildByName('circle');
        circle.active = false;
        //点击
        let t_rh = tween(hand).to(0.3, { eulerAngles: v3(0, 0, 10) });
        let delay = tween(hand).call(() => {
            circle.active = true;
        }).delay(0.1).call(() => {
            circle.active = false;
        })
        let t_lh = tween(hand).to(0.3, { eulerAngles: v3(0, 0, 0) });
        //圆圈
        /* let delay0 = tween(circle).delay(0.5);
        let t_s_show = tween(circle).show();
        let delay1 = tween(circle).delay(0.1);
        let t_s_hide = tween(circle).hide(); */
        tween(hand).sequence(t_rh, delay, t_lh).repeat(3).call(() => { this.mask.destroy(); }).start();

    }

    stopClickTween() {
        let hand = this.tip.getChildByName('hand');
        let circle = this.tip.getChildByName('circle');
        Tween.stopAllByTarget(hand);
        Tween.stopAllByTarget(circle);
        //this.tip.destroy();
        this.tip.active = false;
    }

    stopGuid() {
        //停止引导给个最终结果即可
        Tween.stopAllByTarget(this.camera);
        this.camera.setPosition(v3(0, 0, 1000));
        this.mask.destroy();

    }
}


