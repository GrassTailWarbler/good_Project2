import { _decorator, Component, Label, Node } from 'cc';
import Singleton from '../framework/Singleton';
import { textClickTip } from './data/GameData';
import { ItemName } from './api/GameInterface';
import { EventManager } from '../framework/EventManager';
const { ccclass, property } = _decorator;

@ccclass('TextManager')
export class TextManager extends Component {

    private static _instance: TextManager = null;
    public static get instance() { return this._instance; };

    private _content: Node = null;
    public get content() { return this._content };
    public set content(c: Node) { this._content = c };

    protected onLoad(): void {
        
        if (!TextManager._instance) {
            TextManager._instance = this;
        } else {
            this.destroy();
        }

        EventManager.instance.on('renderText', this.renderText, this)
    }

    public renderText(_itemName: ItemName, _other: string = 'default') {
        let content = !textClickTip[_itemName][_other] ? textClickTip[_itemName]['default'] : textClickTip[_itemName][_other];
        this._content.getComponent(Label).string = content;
    }

    protected onDestroy(): void {
        EventManager.instance.off('renderText', this.renderText)
    }
}


