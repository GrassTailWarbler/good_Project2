import { _decorator, Component, EventTouch, find, Node, NodeEventType, UITransform, v3, view } from 'cc';
const { ccclass, property } = _decorator;

@ccclass('TouchManager')
export class TouchManager extends Component {
    private _targetNode: Node = null;
    private _tempPos = v3();
    private _width = 0;
    private _minX = 0;
    private _maxX = 0;
    protected onLoad(): void {
        this._targetNode = find('Canvas/bgRoot/left');
    }
    start() {
        this._width = view.getVisibleSize().width / 2;
        this._minX = this._targetNode.position.x;
        this._maxX = this._targetNode.position.x + this._width + this.node.getComponent(UITransform).contentSize.width / 2;

        this.node.on(NodeEventType.TOUCH_START, this.touchStart, this)
        this.node.on(NodeEventType.TOUCH_MOVE, this.touchMove, this)

    }

    touchStart(event: EventTouch) {
        //console.log(event.getUILocation())
        //console.log(event.getUIDelta().x)
        //let x = this._targetNode.position.x + event.getUIDelta().x;
        this._tempPos.set(this._targetNode.position)
        //this._tempPos.add(this._targetNode.position);
        // this._targetNode.setPosition(this._tempPos);
    }

    touchMove(event: EventTouch) {
        //console.log(event.getUILocation())
        //console.log(event.getUIDelta().x)
        let x = this._targetNode.position.x + event.getUIDelta().x;
        this._tempPos.x = x;
        this._targetNode.setPosition(this._tempPos);
        if (this._targetNode.position.x < this._minX) {
            this._tempPos.x = this._minX;
            this._targetNode.setPosition(this._tempPos);
        } else if (this._targetNode.position.x > this._maxX) {
            this._tempPos.x = this._maxX;
            this._targetNode.setPosition(this._tempPos);
        }
    }


}


