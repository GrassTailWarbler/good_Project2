import { _decorator } from 'cc';
import {EventManager} from "../../framework/EventManager";
import { ItemBase } from '../item/ItemBase';
const { ccclass, property } = _decorator;

@ccclass('HatItem')
export class HatItem extends ItemBase {
    
   
}

