import { _decorator, Component, Node } from 'cc';
import { ItemBase } from '../item/ItemBase';
const { ccclass, property } = _decorator;

@ccclass('BagItem')
export class BagItem extends ItemBase {
    
}


