import { _decorator, Component, Node, Vec3 } from 'cc';
import { tween } from 'cc';

const { ccclass, property } = _decorator;

@ccclass('FloatTween')
export class FloatTween extends Component {

    @property({
        tooltip: '浮动幅度(Y轴移动距离)'
    })
    floatHeight: number = 20;

    @property({
        tooltip: '浮动一次所需时间（秒）'
    })
    floatDuration: number = 1;

    @property({
        tooltip: '动画延迟开始时间（秒）'
    })
    startDelay: number = 0;

    @property({
        tooltip: '是否相对于初始位置进行浮动'
    })


    private originalPosition: Vec3 = new Vec3();
    private floatTween: any = null;

    onLoad() {
        // 记录初始位置
        this.node.getPosition(this.originalPosition);
    }

    start() {
        this.startFloatAnimation();
    }

    // 开始浮动动画
    private startFloatAnimation() {
        // 停止之前的动画
        this.stopFloatAnimation();



        // 计算上浮和下浮的位置
        const upPosition = new Vec3(
            this.originalPosition.x,
            this.originalPosition.y + this.floatHeight,
            this.originalPosition.z
        );

        const downPosition = new Vec3(
            this.originalPosition.x,
            this.originalPosition.y - this.floatHeight,
            this.originalPosition.z
        );

        // 创建浮动动画
        this.floatTween = tween(this.node)
            .delay(this.startDelay)
            .repeatForever(
                tween(this.node)
                    .to(this.floatDuration / 2, { position: upPosition })
                    .to(this.floatDuration / 2, { position: downPosition })
            )
            .start();
    }

    // 停止浮动动画
    private stopFloatAnimation() {
        if (this.floatTween) {
            this.floatTween.stop();
            this.floatTween = null;
        }
    }

    // 重新开始动画（可用于参数更改后刷新动画）
    refreshAnimation() {
        this.startFloatAnimation();
    }

    // 暂停动画
    pauseAnimation() {
        if (this.floatTween) {
            this.floatTween.pause();
        }
    }

    // 恢复动画
    resumeAnimation() {
        if (this.floatTween) {
            this.floatTween.resume();
        }
    }

    // 重置到原始位置
    resetToOriginalPosition() {

        this.node.setPosition(this.originalPosition);

    }

    onDestroy() {
        this.stopFloatAnimation();
    }
}