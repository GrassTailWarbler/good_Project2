import { _decorator, Component, Node, Vec3, tween, Tween, EventHandler, Enum } from 'cc';
const { ccclass, property } = _decorator;

// 缓动类型枚举
enum EasingType {
    LINEAR = 0,
    SINE_IN = 1,
    SINE_OUT = 2,
    SINE_IN_OUT = 3,
    QUAD_IN = 4,
    QUAD_OUT = 5,
    QUAD_IN_OUT = 6,
    CUBIC_IN = 7,
    CUBIC_OUT = 8,
    CUBIC_IN_OUT = 9,
}

@ccclass('BezierTweenComponent')
export class BezierTweenComponent extends Component {
    // 基础属性
    @property({ type: [Vec3], tooltip: "贝塞尔曲线控制点(1-3个)" })
    controlPoints: Vec3[] = [];

    @property({ tooltip: "终点位置" })
    endPosition: Vec3 = new Vec3(300, 0, 0);

    @property({ tooltip: "起点位置(为空则使用节点当前位置)" })
    startPosition: Vec3 | null = null;

    @property({ tooltip: "运动持续时间(秒)" })
    duration: number = 2;

    @property({ tooltip: "是否在组件启动时自动播放" })
    playOnStart: boolean = true;

    // 进阶属性
    @property({
        type: Enum(EasingType),
        tooltip: "缓动函数类型"
    })
    easingType: EasingType = EasingType.LINEAR;

    @property({ tooltip: "是否循环播放" })
    loop: boolean = false;

    @property({ tooltip: "循环时是否往返运动" })
    pingPong: boolean = false;

    @property({ tooltip: "延迟开始时间(秒)" })
    delay: number = 0;

    @property({ type: EventHandler, tooltip: "动画开始时调用" })
    startEvents: EventHandler[] = [];

    @property({ type: EventHandler, tooltip: "动画完成时调用" })
    finishEvents: EventHandler[] = [];

    private _tween: Tween<Node> | null = null;
    private _isPlaying: boolean = false;
    private _forward: boolean = true;

    start() {
        if (this.playOnStart) {
            this.play();
        }
    }

    onDestroy() {
        this.stop();
    }

    /**
     * 播放贝塞尔缓动动画
     */
    play() {
        if (this._isPlaying) return;
        
        this.stop();
        this._isPlaying = true;

        const startPos = this.startPosition ? this.startPosition.clone() : this.node.position.clone();
        const endPos = this.endPosition.clone();
        const controlPoints = this.controlPoints.map(p => p.clone());

        // 初始化tween
        let tweenAction = tween(this.node)
            .delay(this.delay)
            .call(() => {
                EventHandler.emitEvents(this.startEvents);
            })
            .to(this.duration, { position: endPos }, {
                onUpdate: (target: Node, ratio: number) => {
                    const t = this.applyEasing(ratio);
                    const points = this._forward ? 
                        { start: startPos, end: endPos, controls: controlPoints } : 
                        { start: endPos, end: startPos, controls: controlPoints.map(p => p.clone()) };
                    
                    const position = this.calculateBezierPoint(t, points.start, points.controls, points.end);
                    target.position = position;
                },
                //easing: this.getEasingFunction()
            })
            .call(() => {
                EventHandler.emitEvents(this.finishEvents);
                this._isPlaying = false;
                
                if (this.loop) {
                    if (this.pingPong) {
                        this._forward = !this._forward;
                    }
                    this.play();
                }
            });

        // 处理循环
        if (this.loop && !this.pingPong) {
           /*  tweenAction = tweenAction.union(
               tween(this.node)
                    .to(this.duration, { position: startPos }, {
                        onUpdate: (target: Node, ratio: number) => {
                            const t = this.applyEasing(ratio);
                            const position = this.calculateBezierPoint(
                                t, endPos, 
                                controlPoints.map(p => p.clone()).reverse(), 
                                startPos
                            );
                            target.position = position;
                        },
                        //easing: this.getEasingFunction()
                    })
                    .call(() => {
                        this._isPlaying = false;
                        this.play();
                    })
            ); */
        }

        this._tween = tweenAction.start();
    }

    /**
     * 停止当前动画
     */
    stop() {
        if (this._tween) {
            this._tween.stop();
            this._tween = null;
        }
        this._isPlaying = false;
    }

    /**
     * 重置节点位置到起点
     */
    reset() {
        this.stop();
        if (this.startPosition) {
            this.node.position = this.startPosition.clone();
        }
        this._forward = true;
    }

    /**
     * 计算贝塞尔曲线上的点
     */
    private calculateBezierPoint(t: number, start: Vec3, controls: Vec3[], end: Vec3): Vec3 {
        let x = 0, y = 0;
        
        // 根据控制点数量选择不同的贝塞尔曲线
        switch(controls.length) {
            case 1: // 二次贝塞尔
                x = Math.pow(1-t, 2) * start.x + 
                    2 * (1-t) * t * controls[0].x + 
                    Math.pow(t, 2) * end.x;
                y = Math.pow(1-t, 2) * start.y + 
                    2 * (1-t) * t * controls[0].y + 
                    Math.pow(t, 2) * end.y;
                break;
                
            case 2: // 三次贝塞尔
                x = Math.pow(1-t, 3) * start.x + 
                    3 * Math.pow(1-t, 2) * t * controls[0].x + 
                    3 * (1-t) * Math.pow(t, 2) * controls[1].x + 
                    Math.pow(t, 3) * end.x;
                y = Math.pow(1-t, 3) * start.y + 
                    3 * Math.pow(1-t, 2) * t * controls[0].y + 
                    3 * (1-t) * Math.pow(t, 2) * controls[1].y + 
                    Math.pow(t, 3) * end.y;
                break;
                
            default: // 线性(无控制点)
                x = start.x + (end.x - start.x) * t;
                y = start.y + (end.y - start.y) * t;
        }
        
        return new Vec3(x, y, start.z);
    }

    /**
     * 应用缓动函数
     */
    private applyEasing(t: number): number {
        switch(this.easingType) {
            case EasingType.SINE_IN: return this.sineIn(t);
            case EasingType.SINE_OUT: return this.sineOut(t);
            case EasingType.SINE_IN_OUT: return this.sineInOut(t);
            case EasingType.QUAD_IN: return this.quadIn(t);
            case EasingType.QUAD_OUT: return this.quadOut(t);
            case EasingType.QUAD_IN_OUT: return this.quadInOut(t);
            case EasingType.CUBIC_IN: return this.cubicIn(t);
            case EasingType.CUBIC_OUT: return this.cubicOut(t);
            case EasingType.CUBIC_IN_OUT: return this.cubicInOut(t);
            default: return t; // LINEAR
        }
    }

    /**
     * 获取缓动函数
     */
    private getEasingFunction(): string {
        switch(this.easingType) {
            case EasingType.SINE_IN: return 'sineIn';
            case EasingType.SINE_OUT: return 'sineOut';
            case EasingType.SINE_IN_OUT: return 'sineInOut';
            case EasingType.QUAD_IN: return 'quadIn';
            case EasingType.QUAD_OUT: return 'quadOut';
            case EasingType.QUAD_IN_OUT: return 'quadInOut';
            case EasingType.CUBIC_IN: return 'cubicIn';
            case EasingType.CUBIC_OUT: return 'cubicOut';
            case EasingType.CUBIC_IN_OUT: return 'cubicInOut';
            default: return 'linear';
        }
    }

    // 以下是各种缓动函数的实现
    private sineIn(t: number): number { return 1 - Math.cos((t * Math.PI) / 2); }
    private sineOut(t: number): number { return Math.sin((t * Math.PI) / 2); }
    private sineInOut(t: number): number { return -(Math.cos(Math.PI * t) - 1) / 2; }
    private quadIn(t: number): number { return t * t; }
    private quadOut(t: number): number { return 1 - (1 - t) * (1 - t); }
    private quadInOut(t: number): number { return t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2; }
    private cubicIn(t: number): number { return t * t * t; }
    private cubicOut(t: number): number { return 1 - Math.pow(1 - t, 3); }
    private cubicInOut(t: number): number { return t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2; }
}