import { _decorator, Component, Node } from 'cc';
import { tween } from 'cc';
const { ccclass, property } = _decorator;

@ccclass('ShakeTween')
export class ShakeTween extends Component {
    @property({
        tooltip: '晃动幅度（角度）'
    })
    shakeAngle: number = 10;

    @property({
        tooltip: '单次晃动时间（秒）'
    })
    shakeDuration: number = 0.5;

    @property({
        tooltip: '是否持续晃动'
    })
    enableShake: boolean = true;

    private shakeTween: any = null;
    private originalAngle: number = 0;

    onLoad() {
        this.originalAngle = this.node.angle;
    }

    start() {
        if (this.enableShake) {
            this.startShake();
        }
    }

    private startShake() {
        // 停止已存在的晃动动画
        this.stopShake();

        // 创建左右晃动动画
        this.shakeTween = tween(this.node)
            .repeatForever(
                tween()
                    .to(this.shakeDuration / 2, { angle: this.originalAngle + this.shakeAngle })
                    .to(this.shakeDuration, { angle: this.originalAngle - this.shakeAngle })
                    .to(this.shakeDuration / 2, { angle: this.originalAngle })
            )
            .start();
    }

    // 停止晃动
    stopShake() {
        if (this.shakeTween) {
            this.shakeTween.stop();
            this.shakeTween = null;
        }
        // 重置角度到原始角度
        this.node.angle = this.originalAngle;
    }

    // 暂停晃动
    pauseShake() {
        if (this.shakeTween) {
            this.shakeTween.pause();
        }
    }

    // 恢复晃动
    resumeShake() {
        if (this.shakeTween) {
            this.shakeTween.resume();
        }
    }

    // 刷新晃动动画（参数改变时调用）
    refreshShake() {
        if (this.enableShake) {
            this.startShake();
        } else {
            this.stopShake();
        }
    }

    onDestroy() {
        this.stopShake();
    }
}