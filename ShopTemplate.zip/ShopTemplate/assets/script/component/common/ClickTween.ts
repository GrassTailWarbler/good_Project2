import { Tween, Vec3, tween } from 'cc';
import { _decorator, Component, Node } from 'cc';
const { ccclass, property } = _decorator;

@ccclass('ClickTween')
export class ClickTween extends Component {

    private pressTween: Tween<Node> | null = null; // 按压动画的Tween实例

    @property({
        type: Node,
        tooltip: '按压节点'
    })
    pressNode: Node | null = null;

    @property({

        tooltip: '初始缩放'
    })
    originalScale: Vec3 = new Vec3(1.2, 1.2, 1);

    @property({

        tooltip: '按压时的缩放'
    })
    pressScale: Vec3 = new Vec3(1, 1, 1);

    @property({
        tooltip: '第一次按压时间'
    })
    firstPressDuration: number = 0.1;

    @property({
        tooltip: '第一次恢复时间'
    })
    firstRecoverDuration: number = 0.1;

    @property({
        tooltip: '第一次按压后短暂停顿时间'
    })
    firstDelay: number = 0.1;

    @property({
        tooltip: '第二次按压时间'
    })
    secondPressDuration: number = 0.1;

    @property({
        tooltip: '第二次恢复时间'
    })
    secondRecoverDuration: number = 0.1;

    @property({
        tooltip: '第二次按压后长暂停顿时间'
    })
    secondDelay: number = 0.6;

    @property({
        tooltip: '是否一开始自动播放'
    })
    isAutoPlay: boolean = false;

    protected start(): void {
        this.isAutoPlay && this.startPressAnimation();
    }

    // 开始按压动画
    startPressAnimation() {
        // 先停止之前的动画
        this.stopPressAnimation();

        const bodyNode = this.pressNode;
        if (!bodyNode) return;

        this.pressTween = tween(bodyNode)
            .repeatForever(
                tween()
                    // 第一次按压
                    .to(this.firstPressDuration, { scale: this.pressScale })
                    .call(() => {
                        // 播放按压特效

                    })
                    .to(this.firstRecoverDuration, { scale: this.originalScale })
                    .delay(this.firstDelay) // 短暂停顿

                    // 第二次按压
                    .to(this.secondPressDuration, { scale: this.pressScale })
                    .call(() => {
                        // 再次播放按压特效

                    })
                    .to(this.secondRecoverDuration, { scale: this.originalScale })
                    .delay(this.secondDelay) // 更长的停顿
            )
            .start();
    }

    // 停止按压动画
    stopPressAnimation() {
        if (this.pressTween) {
            this.pressTween.stop();
            this.pressTween = null;

            // 恢复原始大小
            const bodyNode = this.pressNode;
            if (bodyNode) {
                bodyNode.scale = new Vec3(1, 1, 1);
            }
        }
    }
}