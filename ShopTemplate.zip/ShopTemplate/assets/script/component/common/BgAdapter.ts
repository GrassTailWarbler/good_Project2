import { view } from 'cc';
import { _decorator, Component, Node } from 'cc';
import { UITransform } from 'cc';
import { Constant } from '../../framework/Constant';
const { ccclass, property } = _decorator;
const ratio = 1.34;
@ccclass('BgAdapter')
export class BgAdapter extends Component {

    protected onLoad(): void {
        view.on(Constant.EVENT_TYPE.ON_CANVAS_RESIZE, this.setAdapter, this);
    }
    protected start(): void {
        this.setAdapter();
    }

    setAdapter() {
        let visibleSize = view.getVisibleSize();

        if (visibleSize.height > visibleSize.width) { // 竖屏
            /*   let bgSize = this.node.getComponent(UITransform).contentSize.clone();
              let scale = visibleSize.height / bgSize.height;
              console.log('竖屏',scale)
              this.node.setScale(scale, scale, 1); */
            const r = visibleSize.height / visibleSize.width;

            if (r < ratio) {//平板 
                let bgSize = this.node.getComponent(UITransform).contentSize.clone();
                let scale = visibleSize.width / bgSize.width;
                this.node.setScale(scale, scale, 1);

            } else {//普通手机
                let bgSize = this.node.getComponent(UITransform).contentSize.clone();
                let scale = visibleSize.height / bgSize.height;
                this.node.setScale(scale, scale, 1);
            }
        } else { // 横屏
            /*  let bgSize = this.node.getComponent(UITransform).contentSize.clone();
             let scale = visibleSize.width / bgSize.width;
             console.log('横屏',scale)
             this.node.setScale(scale, scale, 1); */
            const r = visibleSize.width / visibleSize.height;
            //console.log(r)
            if (r < ratio) {//平板
                let bgSize = this.node.getComponent(UITransform).contentSize.clone();
                let scale = visibleSize.height / bgSize.height;
                this.node.setScale(scale, scale, 1);
            }
            else {//普通手机

                let bgSize = this.node.getComponent(UITransform).contentSize.clone();
                let scale = visibleSize.width / bgSize.width;
                this.node.setScale(scale, scale, 1);
            }

        }

    }
}


