import { _decorator, Component, Node } from 'cc';
import { tween } from 'cc';
const { ccclass, property } = _decorator;

@ccclass('RotateTweenComponent')
export class RotateTweenComponent extends Component {
    @property({
        tooltip: '旋转一圈所需时间（秒）'
    })
    duration: number = 2;

    @property({
        tooltip: '旋转方向（true为顺时针，false为逆时针）'
    })
    clockwise: boolean = true;

    @property({
        tooltip: '是否持续旋转'
    })
    enableRotation: boolean = true;

    private rotateTween: any = null;

    start() {
        if (this.enableRotation) {
            this.startRotation();
        }
    }

    private startRotation() {
        // 停止已存在的旋转动画
        this.stopRotation();

        // 确定旋转角度（顺时针为负，逆时针为正）
        const targetAngle = this.clockwise ? -360 : 360;

        // 创建无限循环旋转动画
        this.rotateTween = tween(this.node)
            .by(this.duration, { angle: targetAngle })
            .union()
            .repeatForever()
            .start();
    }

    // 停止旋转
    stopRotation() {
        if (this.rotateTween) {
            this.rotateTween.stop();
            this.rotateTween = null;
        }
    }

    // 暂停旋转
    pauseRotation() {
        if (this.rotateTween) {
            this.rotateTween.pause();
        }
    }

    // 恢复旋转
    resumeRotation() {
        if (this.rotateTween) {
            this.rotateTween.resume();
        }
    }

    // 刷新旋转动画（参数改变时调用）
    refreshRotation() {
        if (this.enableRotation) {
            this.startRotation();
        } else {
            this.stopRotation();
        }
    }

    onDestroy() {
        this.stopRotation();
    }
}