import { _decorator, Component, Node, Button, tween, Vec3 } from 'cc';
import { SDKManager } from './SDKManager';
import { AudioManager } from '../../framework/AudioManager';
import { Constant } from '../../framework/Constant';

const { ccclass, property } = _decorator;

@ccclass('TweenBtnBreath')
export class TweenBtnBreath extends Component {

    @property(Node)
    shopBtn: Node = null;

    // 添加呼吸动画属性
    @property({ tooltip: "呼吸动画放大比例" })
    breathScale: number = 1.1; // 默认放大到1.1倍

    @property({ tooltip: "呼吸动画周期（秒）" })
    breathDuration: number = 1.0; // 默认1秒完成一个呼吸周期

    start() {
        this.shopBtn.on(Button.EventType.CLICK, this.onClick, this);
        this.startBreathAnimation();
    }

    // 开始呼吸动画
    private startBreathAnimation() {
        if (!this.shopBtn || !this.shopBtn.isValid) return;

        // 保存原始大小
        const originalScale = this.shopBtn.scale.clone();

        // 创建呼吸动画（放大再缩小）
        tween(this.shopBtn)
            .to(this.breathDuration, {
                scale: new Vec3(
                    originalScale.x * this.breathScale,
                    originalScale.y * this.breathScale,
                    originalScale.z
                )
            }, {
                easing: 'sineOut' // 放大时先快后慢
            })
            .to(this.breathDuration, {
                scale: originalScale
            }, {
                easing: 'sineIn' // 缩小时先慢后快
            })
            .union() // 合并为一个序列
            .repeatForever() // 无限循环
            .start();
    }

    onClick() {
        AudioManager.inst.playOneShot(Constant.AUDIO_TYPE.CLICK);
        SDKManager.instance.clickDown();
    }
}


