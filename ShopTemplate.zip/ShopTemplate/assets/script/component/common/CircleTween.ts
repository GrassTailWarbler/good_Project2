import { _decorator, Component, Node, tween, UIOpacity, Vec3 } from 'cc';
const { ccclass, property } = _decorator;

@ccclass('CircleTween')
export class CircleTween extends Component {
    // 动画持续时间（秒）
    @property({ tooltip: "动画持续时间（秒）" })
    animationDuration: number = 1.5;
    
    // 最小缩放比例
    @property({ tooltip: "最小缩放比例" })
    minScale: number = 0.5;
    
    // 最大缩放比例
    @property({ tooltip: "最大缩放比例" })
    maxScale: number = 1.5;
    
    // 是否自动开始动画
    @property({ tooltip: "是否自动开始动画" })
    autoStart: boolean = true;
    
    // 开始动画前的延迟时间（秒）
    @property({ tooltip: "开始动画前的延迟时间（秒）" })
    startDelay: number = 0;
    
    // 循环间隔时间（秒）
    @property({ tooltip: "循环间隔时间（秒）" })
    loopInterval: number = 0.5;
    
    private opacityComp: UIOpacity | null = null;
    private isAnimating: boolean = false;
    
    protected start(): void {
        this.opacityComp = this.node.getComponent(UIOpacity) || this.node.addComponent(UIOpacity);
        
        if (this.autoStart) {
            this.scheduleOnce(() => this.startAnimation(), this.startDelay);
        }
    }
    
    public startAnimation() {
        if (!this.opacityComp || this.isAnimating) return;
        this.isAnimating = true;
        
        // 重置初始状态
        this.node.setScale(this.minScale, this.minScale, this.minScale);
        this.opacityComp.opacity = 255;
        
        // 创建并行动画：缩放和透明度同时变化
        tween(this.node)
            .parallel(
                // 缩放动画
                tween().to(this.animationDuration, 
                    { scale: new Vec3(this.maxScale, this.maxScale, this.maxScale) },
                    { easing: 'sineOut' }
                ),
                // 透明度动画
                tween(this.opacityComp).to(this.animationDuration, 
                    { opacity: 0 },
                    { easing: 'sineOut' }
                )
            )
            .call(() => {
                this.isAnimating = false; // 重置状态
                
                // 安排重启
                this.scheduleOnce(() => {
                    if (this.isValid) {
                        this.startAnimation(); // 安全重启
                    }
                }, this.loopInterval);
            })
            .start();
    }
    
    public stopAnimation() {
        this.isAnimating = false;
        tween(this.node).stop();
        if (this.opacityComp) {
            tween(this.opacityComp).stop();
        }
    }
    
    protected onDestroy(): void {
        this.stopAnimation();
    }
}