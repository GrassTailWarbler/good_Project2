export enum CLOTH_TYPE {
    NONE = 0,
    CLOTH_1 = 1,
    CLOTH_2 = 2,
    CLOTH_3 = 3,
    CLOTH_4 = 4,
    CLOTH_5 = 5,
    CLOTH_6 = 6,
    CLOTH_7 = 7,
    CLOTH_8 = 8,
    CLOTH_9 = 9,
    CLOTH_10 = 10,

}