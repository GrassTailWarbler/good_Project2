
export class Constant {
    public static GAME_NAME = 'CastleCrashers';//游戏名称
    public static GAME_VERSION = '1.0.0';//游戏版本
    public static GAME_FRAME = 61;      //游戏当前帧率
    public static GAME_INIT_FRAME = 61; //游戏开发基础帧率
    public static GAME_NAME_CH = "城堡毁灭者";//游戏中文名称

    //打包类型
    public static PACK_TYPE = {
        PACK_NONE: 0,
        PACK_MIP: 1,
        PACK_SIP: 2
    }

    /* 游戏状态 */
    public static GAME_STATUS = {
        GAME_OVER: 0,
        GAME_PAUSE: 1,
        GAME_START: 2,
        NONE: 3
    }

    /**事件名字 */
    public static EVENT_TYPE = {
        ON_CANVAS_RESIZE: 'canvas-resize',
        ON_CANVAS_RESIZE_COMPLETE: 'canvas-resize-complete',
    }

    /**面板名字 */
    public static PANEL_TYPE = {
        MUTE_PANEL: 'common/MutePanel',//静音界面
        GUID_PANEL: 'guid/GuidPanel',//引导界面
        DONWLOAD_PANEL: 'download/DownloadPanel',//下载界面
    }

    /**提示名字 */
    public static TIP_TYPE = {
        FLOAT_TIP: 'common/FloatTip',//飘字提示

    }

    /**音频名字 */
    public static AUDIO_TYPE = {
        BGM: 'audio/bgm',
        CLICK: 'audio/click',
        DOG: 'audio/dog',
        DONWLOAD: 'audio/download',
        FOOD: 'audio/food',
        ELI: 'audio/eliminate',
        DESTROY: 'audio/destroy',
        SUCCESS: 'audio/success',
        FAIL: 'audio/fail',

    }

    public static PARTICLE_NAME = {
        STAR: 'star',
        DESTROY: 'destroy',
    }




}
