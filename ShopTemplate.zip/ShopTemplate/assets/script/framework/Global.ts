import { GameMain } from "../game/GameMain";
import { Constant } from "./Constant";

export class Global {
    /**开发模式 */
    static debug: boolean = false;
    /**游戏状态 */
    static gameStatus = Constant.GAME_STATUS.GAME_PAUSE;
    /**包切换 */
    static packToggle = Constant.PACK_TYPE.PACK_NONE;
    /**主游戏引用 */
    static gameMain: GameMain = null;
    /**是否是ipad 设备 */
    static isIpad: boolean = false;

}

globalThis && (globalThis.Global = Global); // 挂载到全局作用域

