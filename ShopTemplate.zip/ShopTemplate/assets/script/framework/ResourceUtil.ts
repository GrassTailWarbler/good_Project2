import { _decorator, Prefab, Node, SpriteComponent, SpriteFrame, ImageAsset, resources, error, Texture2D, instantiate, isValid, assetManager } from "cc";
const { ccclass } = _decorator;

@ccclass("ResourceUtil")
export class ResourceUtil {
    /**
 * 加载资源
 * @param url   资源路径
 * @param type  资源类型
 * @param cb    回调
 * @method loadRes
 */
    public static loadRes(url: string, type: any, cb: Function = () => { }) {
        resources.load(url, (err: any, res: any) => {
            if (err) {
                error(err.message || err);
                cb(err, res);
                return;
            }

            cb && cb(null, res);
        })
    }


    /**
     * 加载资源
     * @param url   资源路径
     * @param type  资源类型
     * @method loadRes
     */
    public static loadResType(url: string, type: any) {
        return new Promise((resolve, reject) => {
            resources.load(url, type, (err: any, res: any) => {
                if (err) {
                    error(err.message || err);
                    reject && reject(err)
                    return;
                }

                resolve && resolve(res);
            })
        })
    }

    /**
     * 获取特效prefab
     * @param modulePath 路径
     * @returns 
     */
    public static loadEffectRes(modulePath: string) {
        return new Promise((resolve, reject) => {
            this.loadRes(`prefab/effect/${modulePath}`, Prefab, (err: any, prefab: Prefab) => {
                if (err) {
                    console.error('effect load failed', modulePath);
                    reject && reject();
                    return;
                }

                resolve && resolve(prefab);
            })
        })
    }

    

    /**
     * 获取多模型数据
     * @param path 资源路径
     * @param arrName 资源名称
     * @param progressCb 过程回调函数
     * @param completeCb 完成回调函数
     */
    public static loadModelResArr(path: string, arrName: Array<string>, progressCb: any, completeCb: any) {
        let arrUrls = arrName.map((item) => {
            return `${path}/${item}`;
        })

        resources.load(arrUrls, Prefab, progressCb, completeCb);
    }

    /**
     * 获取贴图资源
     * @param path 贴图路径
     * @returns 
     */
    public static loadSpriteFrameRes(path: string) {
        return new Promise((resolve, reject) => {
            this.loadRes(path, SpriteFrame, (err: any, img: ImageAsset) => {
                if (err) {
                    console.error('spriteFrame load failed!', path, err);
                    reject && reject();
                    return;
                }

                let texture = new Texture2D();
                texture.image = img;

                let sf = new SpriteFrame();
                sf.texture = texture;

                resolve && resolve(sf);
            })
        })
    }

    /**
     * 获取贴图资源
     * @param path 贴图路径
     * @returns 
     */
    public static loadSpriteFrameURL(url: string, sprite: SpriteComponent) {
        assetManager.loadRemote(url, (err: any, img: ImageAsset) => {
            if (err) {
                console.error('spriteFrame load failed!', url, err);
                return;
            }

            let texture = new Texture2D();
            texture.image = img;

            let sf = new SpriteFrame();
            sf.texture = texture;
            sprite.spriteFrame = sf;
        })
    }

    /**
     * 获取UI prefab
     * @param prefabPath prefab路径 
     * @param cb 回调函数
     */
    public static getUIPrefabRes(prefabPath: string, cb?: Function) {
        this.loadRes("prefab/ui/" + prefabPath, Prefab, cb);
    }

    /**
     * 创建ui界面
     * @param path ui路径
     * @param cb 回调函数
     * @param parent 父节点
     */
    public static createUI(path: string, parent: Node, cb?: Function) {
        this.getUIPrefabRes(path, function (err: {}, prefab: Prefab) {
            if (err) return;
            let node: Node = instantiate(prefab);
            node.setPosition(0, 0, 0);
            parent.addChild(node);
            cb && cb(null, node);
        });
    }

    /**
     * 设置精灵贴图
     * @param path 资源路径
     * @param sprite 精灵
     * @param cb 回调函数
     */
    public static setSpriteFrame(path: string, sprite: SpriteComponent, cb: Function) {
        this.loadRes(path + '/spriteFrame', SpriteFrame, (err: any, spriteFrame: SpriteFrame) => {
            if (err) {
                console.error('set sprite frame failed! err:', path, err);
                cb && cb(err);
                return;
            }

            if (sprite && isValid(sprite)) {
                sprite.spriteFrame = spriteFrame;
                cb && cb(null);
            }
        });
    }

    public static getEffectPrefab(effectName: string, cb: Function) {
        this.loadRes(`prefab/effect/${effectName}/${effectName}`, Prefab, cb);
    }

}
