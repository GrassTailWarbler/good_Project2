import { Prefab, _decorator, Node, instantiate, NodePool } from "cc";
const { ccclass } = _decorator;

@ccclass("PoolManager")
export class PoolManager {

    private _dictPool: any = {}
    private _dictPrefab: any = {}

    static _instance: PoolManager;

    static get instance() {
        if (this._instance) {
            return this._instance;
        }

        this._instance = new PoolManager();
        return this._instance;
    }

    /**
     * 根据预设从对象池中获取对应节点
     */
    public getNode(prefab: Prefab, parent: Node) {
        let name = prefab.name;
        //@ts-ignore
        if (!prefab.position) {
            //@ts-ignore
            name = prefab.data.name;
        }

        this._dictPrefab[name] = prefab;
        let node: Node = null!;
        if (this._dictPool.hasOwnProperty(name)) {
            //已有对应的对象池
            let pool = this._dictPool[name];
            if (pool.size() > 0) {
                node = pool.get();
            } else {
                node = instantiate(prefab);
            }
        } else {
            //没有对应对象池，创建他！
            let pool = new NodePool();
            this._dictPool[name] = pool;

            node = instantiate(prefab);
        }
       
        node.parent = parent;
        node.active = true;
        return node;
    }

    /**
     * 将对应节点放回对象池中
     */
    public putNode(node: Node) {
        if (!node) {
            return;
        }
        let name = node.name;
        let pool: NodePool = null;
        if (this._dictPool.hasOwnProperty(name)) {
            //已有对应的对象池
            pool = this._dictPool[name];
        } else {
            //没有对应对象池，创建他！
            pool = new NodePool();
            this._dictPool[name] = pool;
        }

        pool.put(node);
        //console.log(this._dictPool)
    }

    /**
     * 根据名称，清除对应对象池
     */
    public clearPool(name: string) {
        if (this._dictPool.hasOwnProperty(name)) {
            let pool = this._dictPool[name];
            pool.clear();
        }
    }

    /**
     * 清除对象池
     */
    public clearAllPool() {
        for (let k in this._dictPool) {
            if (this._dictPool.hasOwnProperty(k)) {
                let pool = this._dictPool[k];
                pool.clear();
            }
        }
    }

    /**
    * 预生成对象池
    * @param prefab 
    * @param nodeNum 
    * 使用——PoolManager.instance.prePool(prefab, 40);
    */
    public prePool(prefab: Prefab, nodeNum: number) {
        const name = prefab.name;

        let pool = new NodePool();
        this._dictPool[name] = pool;

        for (let i = 0; i < nodeNum; i++) {
            const node = instantiate(prefab);
            pool.put(node);
        }
    }
}
