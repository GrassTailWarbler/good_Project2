
import { _decorator, Component, Node } from 'cc';
import { Constant } from '../../framework/Constant';
import { Vec3, view, UITransform } from 'cc';
import { Global } from '../../framework/Global';
import { tween } from 'cc';
import { Tween } from 'cc';
import { UIManager } from '../../framework/UIManager';

const { ccclass, property } = _decorator;

@ccclass('GuidPanel')
export class GuidPanel extends Component {
    private static _instance: GuidPanel = null;
    public static get instance() {
        return this._instance;
    }

    @property(Node)
    uiHand: Node = null; // 引导手节点

    @property(Node)
    guidMask: Node = null; // 遮罩序列父节点

    private currentStep = 0;
    private guideSequence: number[] = []; // 引导序列 [0, 5] 表示先点第0张，再点第5张
    private isGuiding = false;
    private guidShadowWorldPosition: Vec3 = new Vec3(0, 0);

    protected onLoad(): void {
        if (!GuidPanel.instance) {
            GuidPanel._instance = this;
        } else {
            this.destroy();
            return;
        }
        view.on(Constant.EVENT_TYPE.ON_CANVAS_RESIZE, this.setAdapter, this);
    }


    show() {
        this.isGuiding = true;
        this.setAdapter();
        // 设置引导序列（第一对牌的位置）
        const guideSequence = [0, 1]; // 引导点击第0张和第1张牌
        this.startGuide(guideSequence);
    }

    setAdapter() {

        //if (Global.gameStatus !== Constant.GAME_STATUS.GAME_START) return;
        const viewSize = view.getVisibleSize();
        this.guidShadowWorldPosition.set(viewSize.width / 2, viewSize.height / 2);

        const targetIndex = this.guideSequence[this.currentStep];
        const target = Global.gameMain.getTargetByIndex(targetIndex);

        if (target) {
            // 定位引导手到卡片位置
            const worldPos = target.getWorldPosition();
            const localPos = this.node.getComponent(UITransform)!.convertToNodeSpaceAR(worldPos);

            this.uiHand.setPosition(localPos);
            this.uiHand.active = true;

            this.guidMask.setPosition(localPos);
            this.guidMask.active = true;

            const localPos2 = this.guidMask.getComponent(UITransform)!.convertToNodeSpaceAR(this.guidShadowWorldPosition);
            this.guidMask.getChildByName('shadow').setPosition(localPos2.x, localPos2.y);

            // 启动按压动画
            this.startPressAnimation();
        }

    }

    // 初始化引导
    startGuide(sequence: number[]) {
        this.guideSequence = sequence;
        this.currentStep = 0;
        this.node.active = true;
        this.guidMask.active = true;
        this.uiHand.active = true;
        this.showCurrentStep();
    }

    // 显示当前引导步骤
    private showCurrentStep() {
        if (this.currentStep >= this.guideSequence.length) {
            this.endGuide();
            return;
        }

        const viewSize = view.getVisibleSize();
        this.guidShadowWorldPosition.set(viewSize.width / 2, viewSize.height / 2);

        const targetIndex = this.guideSequence[this.currentStep];
        //console.log(targetIndex)
        const target = Global.gameMain.getTargetByIndex(targetIndex);

        if (target) {
            // 定位引导手到卡片位置
            const worldPos = target.getWorldPosition();
            const localPos = this.node.getComponent(UITransform)!.convertToNodeSpaceAR(worldPos);

            this.uiHand.setPosition(localPos);
            this.uiHand.active = true;

            this.guidMask.setPosition(localPos);
            this.guidMask.active = true;

            const localPos2 = this.guidMask.getComponent(UITransform)!.convertToNodeSpaceAR(this.guidShadowWorldPosition);
            this.guidMask.getChildByName('shadow').setPosition(localPos2);
            // 启动按压动画
            this.startPressAnimation();
        }
    }

    // 开始按压动画
    private startPressAnimation() {
        // 先停止之前的动画
        this.stopPressAnimation();

        tween(this.uiHand)
            .to(0.3, { scale: new Vec3(1.2, 1.2, 1) }, { easing: 'sineOut' })
            .to(0.3, { scale: new Vec3(1, 1, 1) }, { easing: 'sineIn' })
            .union()
            .repeatForever()
            .start();
    }

    // 停止按压动画
    private stopPressAnimation() {
        Tween.stopAllByTarget(this.uiHand);
        this.uiHand.setScale(1, 1);
    }

    // 修改 onClick 方法
    onClick() {
        if (!this.isGuiding) return;
        // 停止当前按压动画
        this.stopPressAnimation();

        this.currentStep++;
        //console.log(this.currentStep)
        this.showCurrentStep();
    }

    // 结束引导
    endGuide() {
        this.stopPressAnimation();
        // 重置引导状态
        this.resetForNextGuide();
        // 通知 GameMain 引导已结束
        if (Global.gameMain) {
            Global.gameMain.setGuideFinished();
        }
    }

    public resetForNextGuide() {
        this.currentStep = 0;
        this.guideSequence = [];
        this.uiHand.active = false;
        this.guidMask.active = false;
        this.node.active = false;
        UIManager.instance.hideDialog(Constant.PANEL_TYPE.GUID_PANEL);
    }

}


