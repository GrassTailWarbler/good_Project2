import { _decorator, Component } from 'cc';
import { SDKManager } from '../../component/common/SDKManager';
import { Constant } from '../../framework/Constant';
import { AudioManager } from '../../framework/AudioManager';
import { Global } from '../../framework/Global';
import { CCFloat, Vec3, tween } from 'cc';
const { ccclass, property } = _decorator;

@ccclass('DownloadPanel')
export class DownloadPanel extends Component {

    // 添加缩放动画时长属性
    @property({ type: CCFloat, tooltip: "缩放动画时长（秒）" })
    scaleDuration: number = 0.3;
    onLoad() {
        if (Global.packToggle === Constant.PACK_TYPE.PACK_SIP) {
            AudioManager.inst.isMute = true;
        }
    }

    show() {

        // 确保节点激活
        this.node.active = true;
        const bounceNode = this.node.getChildByName("bounce");
        // 保存原始大小
        const originalScale = bounceNode.scale.clone();

        // 设置初始缩放为0
        bounceNode.setScale(new Vec3(0, 0, 1));

        // 播放从小到大的缩放动画（带弹性效果）
        tween(bounceNode)
            .to(this.scaleDuration, {
                scale: originalScale
            }, {
                easing: 'backOut', // 弹性效果
                onComplete: () => {
                    // 动画完成后可添加额外逻辑

                }
            })
            .start();
    }

    onClickDown() {
        SDKManager.instance.clickDown();
        AudioManager.inst.playOneShot(Constant.AUDIO_TYPE.CLICK);
    }

}


