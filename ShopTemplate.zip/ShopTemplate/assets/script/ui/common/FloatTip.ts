import { _decorator, Component, Label, Animation } from 'cc';
import { PoolManager } from '../../framework/PoolManager';

const { ccclass, property } = _decorator;

@ccclass('FloatTip')
export class FloatTip extends Component {
    @property(Label)
    lbTips: Label = null!;

    private _callback: Function = null!;

    start() {
        let animation: Animation = this.node.getComponent(Animation);

        animation.on(Animation.EventType.FINISHED, () => {
            this._callback && this._callback();
            PoolManager.instance.putNode(this.node);
        }, this)

    }

    show(content: string, callback?: Function) {

        this.lbTips.string = content;
        this._callback = callback;
        this.node.getComponent(Animation).play();

    }

}
