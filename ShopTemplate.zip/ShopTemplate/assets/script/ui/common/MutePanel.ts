import { EventTouch, Node } from 'cc';
import { Constant } from '../../framework/Constant';
import { Global } from '../../framework/Global';
import { SDKManager } from '../../component/common/SDKManager';
import { AudioManager } from '../../framework/AudioManager';
import { _decorator, Component } from 'cc';

const { ccclass } = _decorator;

@ccclass('MutePanel')
export class MutePanel extends Component {
    show() {
        Global.debug && console.log("MutePanel show");
        this.autoMute();
    }

    hide(arg: any) {
        Global.debug && console.log("MutePanel hide", arg);
    }

    autoMute() {
        AudioManager.inst.isMute = true;//静音
        if (Global.packToggle === Constant.PACK_TYPE.PACK_SIP) {
            this.node.on(Node.EventType.TOUCH_START, () => {
                SDKManager.instance.clickDown();
            })
        } else {
            this.node.once(Node.EventType.TOUCH_START, (event: EventTouch) => {
                event.preventSwallow = true;
                AudioManager.inst.isMute = false;//取消静音
                AudioManager.inst.play(Constant.AUDIO_TYPE.BGM, 0.5);
                this.node.destroy();
            })
        }
    }
}


