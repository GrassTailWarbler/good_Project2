import { _decorator, Component, game, Node } from 'cc';
import { Constant } from '../framework/Constant';
import { UIManager } from '../framework/UIManager';
import { Global } from '../framework/Global';
import { GuidPanel } from '../ui/guid/GuidPanel';
import { SpriteFrame } from 'cc';

const { ccclass, property } = _decorator;

@ccclass('GameMain')
export class GameMain extends Component {

    /* 强制引导 */
    private isGuideFinished: boolean = false; // 引导是否结束
    private guideTarget: Node[] = [];

    /* 无操作检测逻辑 */
    isGuiding = false;
    idleTimer: number = 0;
    timeThreshold: number = 3;

    @property([Node])
    guideTargets: Node[] = [];

    @property(Node)
    guidHand: Node = null;

    onLoad() {
        this.gameInit();

    }

    start() {

        UIManager.instance.showDialog(Constant.PANEL_TYPE.MUTE_PANEL);
        //UIManager.instance.showDialog(Constant.PANEL_TYPE.GUID_PANEL);
        //UIManager.instance.showDialog(Constant.PANEL_TYPE.DONWLOAD_PANEL);
        this.guideTarget = this.guideTargets;

    }

    gameInit() {
        game.frameRate = Constant.GAME_INIT_FRAME;
        Global.gameStatus = Constant.GAME_STATUS.GAME_PAUSE;
        //主游戏引用
        Global.gameMain = this;

    }



    getTargetByIndex(index: number) {
        //根据索引值找到对应的目标
        return this.guideTarget[index];
    }

    // 添加设置引导结束的方法
    setGuideFinished() {
        this.isGuideFinished = true;
    }

    guidClickTest() {
        GuidPanel.instance.onClick();
    }


    protected update(dt: number): void {
        if (Global.gameStatus === Constant.GAME_STATUS.GAME_OVER) return;
        // 无操作检测逻辑
        if (!this.isGuiding) {
            this.idleTimer += dt;
            if (this.idleTimer >= this.timeThreshold) { // 3秒无操作
                this.showGuidance();
                this.idleTimer = 0; // 重置计时器
            }
        }
    }

    // 添加新方法：显示引导
    private showGuidance() {
        if (this.isGuiding) return;
        if (this.guidHand) {
            this.guidHand.active = true;
        }

        this.isGuiding = true;

    }

    hideGuid() {
        if (this.isGuiding) {
            this.isGuiding = false;
            if (this.guidHand) {
                this.guidHand.active = false;
            }

            this.idleTimer = 0;
        }
    }





}


