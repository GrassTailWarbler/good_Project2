import { director, macro } from 'cc';
import { _decorator, Component, Node } from 'cc';
import { StateController } from '../component/uicontrol/StateController';
import { Constant } from '../framework/Constant';
import { view } from 'cc';
import { Global } from '../framework/Global';
const { ccclass, property } = _decorator;

@ccclass('GameUIController')
export class GameUIController extends Component {

    private _stateController: StateController = null;
    get stateController() {
        return this._stateController;
    }
    set stateController(value: StateController) {
        this._stateController = value;
    }

    @property
    needAutoAdjust: boolean = false;
    protected onLoad(): void {
        this.stateController = this.node.getComponent(StateController);
        director.on(Constant.EVENT_TYPE.ON_CANVAS_RESIZE_COMPLETE, this.adjustGameContent, this);
    }
    start() {
        Global.gameStatus = Constant.GAME_STATUS.GAME_START;
        if (this.needAutoAdjust) {
            this.setAdapter();
        }

    }

    setAdapter() {
        let visibleSize = view.getVisibleSize();

        if (visibleSize.height > visibleSize.width) { // 竖屏
            this.adjustGameContent(macro.ORIENTATION_PORTRAIT);
        } else { // 横屏
            this.adjustGameContent(macro.ORIENTATION_LANDSCAPE);
        }
    }

    adjustGameContent(orientation: number) {
        if (orientation === macro.ORIENTATION_PORTRAIT) {
            this.stateController.selectPageByIndex(0);
        } else {
            this.stateController.selectPageByIndex(1);
        }
        if (Global.gameStatus !== Constant.GAME_STATUS.GAME_START) return;
        Global.gameMain.hideGuid();
    }
}


