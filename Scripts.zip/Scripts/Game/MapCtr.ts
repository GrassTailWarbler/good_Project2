import { _decorator, Component, Node, SphereLight, tween, v3, Vec3 } from 'cc';
import { BuildingType, CommonEvent, EffectType, GameResult } from '../common/CommonEnum';
const { ccclass, property } = _decorator;

@ccclass('MapCtr')
export class MapCtr extends Component {
}


