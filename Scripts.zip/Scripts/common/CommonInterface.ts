import { Node } from "cc";
export interface DamageData {
    damage: number;
    damageSource: Node;
}